> 中国读者先核对[身份与适用路径](CHINESE-READERS.md)，再使用以下清单或模板；临时签证者与游客不要直接照搬居民项目的申请步骤。

<a id="start-here-one-useful-move-at-a-time"></a>

# 从这里开始：一次一个有用的动作

你不需要优化你的整个生活。使用此页面选择一个值得解决的问题，然后在下一步行动明确时停止。本指南中的时间估计是编辑估计，而不是衡量的承诺。

<a id="if-something-is-urgent"></a>

## 如果有紧急事情

直接危险或严重的医疗症状：**911**。自杀或心理健康危机支持：**致电或发短信 988**。可能中毒：**1-800-222-1222**。请遵循经过培训的响应人员的指示。请参阅[紧急情况](guide/03-emergencies.md) 和[心理健康支持](guide/02-mental-health.md)。

法庭文件、驱逐通知、福利拒绝、关闭通知或保险上诉可能有截止日期。在花费数小时研究整个主题之前，对其进行拍照或扫描，确定回复日期并找到正确的帮助。 [从法律帮助和截止日期开始](guide/17-legal-and-consumer-problems.md#171-find-the-right-legal-help-and-identify-the-next-deadline)； [尽早寻求住房援助](guide/14-job-loss-and-assistance.md#145-seek-housing-help-while-you-still-have-time-to-act)。

<a id="choose-by-the-pressure-you-feel"></a>

## 根据你感受到的压力来选择

|你的约束|有用的第一步|留待以后做什么 |
| ---| ---| ---|
|本周资金短缺| [保护住房、食品、公用事业、药品和基本交通](guide/08-debt-scams-setbacks.md#081-protect-essentials-when-there-is-not-enough-money) |投资优化|
|您有十分钟空闲时间 | [在一个地方收集下一个截止日期](guide/40-time-decisions-and-follow-through.md#405-keep-a-small-household-administration-file) |重建千家万户系统|
|账单混乱| [将发薪日与账单匹配](guide/07-cash-flow-banking-credit.md#071-put-paydays-and-bills-on-one-calendar) 和[查看医疗费用](guide/04-health-insurance.md#044-request-bill-review-and-financial-assistance-before-borrowing) |购买复杂的预算产品|
|健康感觉被忽视| [选择适合年龄和风险的预防](guide/01-prevention.md#014-choose-preventive-care-for-your-age-and-risks) |没有明确目的的广泛测试包 |
|你感到不知所措| [制定未来几天的最低计划](guide/27-grief-burnout-setbacks.md#272-make-a-minimum-plan-for-the-next-few-days) |重大的不可逆转的决定可以安全地等待|
|重大变革即将来临 | [使用匹配清单](SCENARIOS.md) |假设去年的规则仍然适用 |

<a id="your-30-day-reset"></a>

## 您的 30 天重置

这是一个可选的序列。跳过任何已经处理过的事情；更改实际截止日期和访问需求的顺序。

<a id="week-1--protect-the-essentials"></a>

### 第 1 周 — 保护必需品

- [ ] 保存紧急联系人并告诉一位信任的人重要信息的保存位置。
- [ ] 列出接下来两个发薪日之前到期的账单。找出任何不足之处。
- [ ] 保护您的主要电子邮件和财务帐户；保留可用的恢复方法。 [账户清单](guide/18-accounts-identity-and-privacy.md#181-secure-important-accounts-and-preserve-a-recovery-path)。
- [ ] 选择一种可以重复的简单健康习惯。 [运动](guide/01-prevention.md#011-build-movement-into-an-ordinary-week) · [睡眠](guide/01-prevention.md#012-protect-a-realistic-sleep-window)。

<a id="week-2--find-one-avoidable-expense"></a>

### 第 2 周 — 找到一项可以避免的开支

- [ ] 仔细阅读一份声明或账单，并在需要时请求更正。
- [ ] 使用总账单和退出条款比较一项定期服务。 [家庭服务](guide/31-repairs-utilities-contracts.md)。
- [ ]查看收入变化后的相关帮助。 [粮食、健康和能源援助](guide/14-job-loss-and-assistance.md#143-check-food-health-and-energy-help-together)。
- [ ] 在致电之前向临床医生、保险公司、贷方或雇主写一个问题。 [复制脚本](TEMPLATES.md)。

<a id="week-3--make-the-next-decision-clearer"></a>

### 第 3 周 — 使下一个决定更加清晰

- [ ] 分别使用金钱、时间和风险来比较一项即将到来的承诺。 【判定方法】(guide/40-time-decisions-and-follow-through.md#402-compare-a-purchase-in-money-time-and-risk-separately)。
- [ ] 确认可能改变答案的承保范围、资格规则或截止日期。
- [ ] 收集缺失的记录：租赁、福利摘要、药物清单或受益人信息。
- [ ] 进行一次有关金钱或护理的实际对话。 [家庭决定](guide/19-relationships-and-family.md)。

<a id="week-4--keep-only-what-helped"></a>

### 第 4 周 — 只保留有帮助的内容

- [ ] 回顾一个小实验。保留它，改变它，或者停止它。 [设置停止规则](guide/40-time-decisions-and-follow-through.md#404-set-a-review-date-and-a-stop-rule-for-experiments)。
- [ ] 对任何未解决的请求设置审核日期。
- [ ] 保存两个相关条目供以后使用。
- [ ] 与真正需要的人分享一个条目，而不透露他们的私人情况。

<a id="read-the-labels-correctly"></a>

## 正确阅读标签

**从这里开始**意味着广泛有用的保护或基础步骤。 **构建下一个**意味着在涵盖紧急基础知识时很有用。 **相关时**意味着特定事件或资格条件触发它。您的情况的紧迫性凌驾于标签之上。

**规则** 确定政策或法律要求； **指南** 确定了所引用组织的建议； **实践**确定编辑工作流程。混合标签意味着条目包含不止一种声明。请参阅[方法](METHODOLOGY.md)。

[返回剧本](README.md)