<a id="04-health-insurance-and-medical-bills"></a>

# 04. 医疗保险与医疗账单

在美国，根据您的计划、提供者和文书工作，相同的护理可能会产生截然不同的账单。了解您的实际承保范围并保留相应决定的记录。

<a id="041-compare-a-full-year-of-costs-before-choosing-a-plan"></a>

## 04.1 选医保先比较全年总成本

**中国读者怎么用：** 定居：公民、绿卡及其他身份分别核对参保、补贴与州项目资格。 签证：先比学校或雇主计划，再按身份核对Marketplace。 游客：以访客/旅行医疗保障与自付预算为起点，不把居民项目当旅行保险。详见[身份与医保入口](../CHINESE-READERS.md)。

使用每个计划的福利和承保范围摘要比较年度保费、免赔额、共付额、按比例自付（coinsurance）和自付费用最高限额。估计普通年份和有大量承保护理的年份。在选择之前，请检查您的医生、医院和处方。保费、非承保服务和一些网络外费用通常超出自付费用限额。仅当该计划也适合您的护理需求和可用现金时，低保费才有用。

- **成本与投入：** 计划估计：注册期间 60-90 分钟；收集去年的使用情况和当前的药物清单。
- **预期收益：** 帮助您选择可以使用的保险范围和预算，而不是假设最便宜的保费意味着最便宜的护理。
- **优先级：** 按需处理。
- **依据：**规则；实践。 [HealthCare.gov：比较总医疗费用](https://www.healthcare.gov/choose-a-plan/your-total-costs/)。

<a id="042-check-enrollment-options-when-life-changes"></a>

## 04.2 生活变化后核对特别投保资格

**中国读者怎么用：** 定居：公民、绿卡及其他身份分别核对参保、补贴与州项目资格。 签证：先比学校或雇主计划，再按身份核对Marketplace。 游客：以访客/旅行医疗保障与自付预算为起点，不把居民项目当旅行保险。详见[身份与医保入口](../CHINESE-READERS.md)。

**本条资格重点：** Marketplace参保、补贴、Medicaid与CHIP是不同资格审查，不能凭“合法签证”一并推断。新年度续保前重新核对[移民医保规则](https://www.healthcare.gov/immigrants/lawfully-present-immigrants/)，该页已列出2027年起部分补贴资格变化。

失去保险、搬家、结婚或生孩子后，请立即检查您是否有资格享受特殊投保期。资格、文件和截止日期取决于触发事件及保险渠道。 Medicaid 和 CHIP 全年接受申请，并具有各州特定的资格规则。在取消现有承保之前，先从 HealthCare.gov 或您所在州的官方市场开始协调生效日期。由于计划、价格和家庭情况发生变化，请重新考虑续约时的选择。

- **成本与投入：** 规划估算：初步申请审核需要 30-60 分钟；收集文件和确定资格可能需要更长的时间。
- **预期收益：** 有助于防止可避免的保险空档和错失援助机会。
- **优先级：** 按需处理。
- **依据：**规则；实践。 [HealthCare.gov：特殊注册期](https://www.healthcare.gov/coverage-outside-open-enrollment/special-enrollment-period/)。 [HealthCare.gov：医疗补助和 CHIP](https://www.healthcare.gov/medicaid-chip/getting-medicaid-chip/)。

<a id="043-confirm-the-network-and-expected-charges-before-planned-care"></a>

## 04.3 非急诊就医前核对保险网络与费用

**中国读者怎么用：** 定居：公民、绿卡及其他身份分别核对参保、补贴与州项目资格。 签证：先比学校或雇主计划，再按身份核对Marketplace。 游客：以访客/旅行医疗保障与自付预算为起点，不把居民项目当旅行保险。详见[身份与医保入口](../CHINESE-READERS.md)。

在进行非紧急护理之前，请向保险公司和提供者询问您的确切计划、临床医生、设施以及任何单独的实验室或影像服务。记录姓名、日期和参考号。询问事先授权和书面成本估算。如果没有保险或自费，请检查您对定期护理进行善意估算的权利。联邦意外账单保护也有例外，包括许多地面救护车账单；查看适用的规则，而不是假设每项费用都受到保护。

- **成本与投入：** 计划估算：简单服务需要 15-30 分钟；复杂的过程可能需要多次电话确认。
- **预期收益：** 帮助识别可避免的账单意外，并在发生承保纠纷时创建记录。
- **优先级：** 按需处理。
- **依据：**规则；实践。 [HealthCare.gov：确认您的提供者](https://www.healthcare.gov/using-marketplace-coverage/getting-medical-care/)。 [CMS：医疗账单权利](https://www.cms.gov/initiatives/your-patient-rights/medical-bill-rights)。

<a id="044-request-bill-review-and-financial-assistance-before-borrowing"></a>

## 04.4 借钱付医药费之前先申请账单复核

**中国读者怎么用：** 定居：公民、绿卡及其他身份分别核对参保、补贴与州项目资格。 签证：先比学校或雇主计划，再按身份核对Marketplace。 游客：以访客/旅行医疗保障与自付预算为起点，不把居民项目当旅行保险。详见[身份与医保入口](../CHINESE-READERS.md)。

将提供商的逐项账单与保险公司对福利的解释进行比较，并质疑重复或不熟悉的费用。向医院询问其财务援助政策、申请、截止日期以及涵盖哪些临床医生。免税医院必须有此类政策，但资格和纳入的医疗服务提供者各不相同。在审核申请时请求暂停计费，并以书面形式确认任何安排。在将医疗债务转入信用卡之前，请考虑援助和负担得起的付款方式。

- **成本与投入：** 规划估算：一小时收集账单并开始申请；随访时间各不相同。
- **预期收益：** 可以纠正错误或减少符合条件的费用，并帮助您避免在考虑援助之前借款。
- **优先级：** 按需处理。
- **依据：**规则；实践。 [国税局：医院财务援助政策](https://www.irs.gov/charities-non-profits/financial-assistance-policies-faps)。 [CFPB：审查和解决医疗费用](https://www.consumerfinance.gov/archive/blog/seven-ways-to-keep-medical-debt-in-check/)。

<a id="045-appeal-a-denial-using-the-reason-and-deadline"></a>

## 04.5 按拒赔原因和期限提出申诉

**中国读者怎么用：** 定居：公民、绿卡及其他身份分别核对参保、补贴与州项目资格。 签证：先比学校或雇主计划，再按身份核对Marketplace。 游客：以访客/旅行医疗保障与自付预算为起点，不把居民项目当旅行保险。详见[身份与医保入口](../CHINESE-READERS.md)。

阅读拒绝通知并确定确切原因：信息缺失、承保范围排除、医疗必要性或其他问题。向临床医生办公室索取相关记录，并通过计划规定的流程提交内部上诉。保留一份副本和提交证明。如果延误会严重损害您的健康，请询问加急审核。如果拒绝成立，请检查独立外部审查的资格；私人计划、医疗保险和医疗补助的流程有所不同。

- **成本与投入：** 规划估算：整理首次申诉材料需要一到三个小时；医疗记录和额外审查可能需要更长时间。
- **预期收益：** 对有争议的决定进行书面审查，而不假设第一次拒绝是最终的。
- **优先级：** 按需处理。
- **依据：**规则；实践。 [HealthCare.gov：对保险公司的决定提出上诉](https://www.healthcare.gov/appeal-insurance-company-decision/)。

