<a id="09-retirement-and-long-term-investing"></a>

# 09. 退休账户与长期投资

投资从目标、时间范围和预算空间开始。账户税收规则和投资选择是单独的决定。这些步骤都不能保证回报或避免市场损失。

<a id="091-read-the-employer-match-before-setting-contributions"></a>

## 09.1 先看懂雇主配比再决定退休供款

**中国读者怎么用：** 定居：先确认雇主计划、合格收入、税务身份及账户条件。 签证：跨境搬迁、离美提取和税收协定可能改变结果，应先核对。 游客：本条主要是长期账户知识；不要只为旅游开设退休账户。参见[税务入口](../CHINESE-READERS.md)。

获取您的工作场所计划的概要计划说明并确定资格、匹配公式、缴款截止日期、费用和雇主供款权益归属（vesting）时间表。如果现金流允许，请考虑缴纳足够的供款来获得可用的匹配。之后确认实际工资扣除和投资选择。您自己的缴款通常是您自己的，但雇主缴款可能会随着时间的推移而归属。在换工作或大幅改变供款之前，请询问管理员该计划如何对待您的情况；雇主计划的效果并不完全相同。

- **成本与投入：** 估计需要 30-60 分钟来阅读和确认设置。缴款会减少可用的实得工资，并且通常面临退休账户提款限制。
- **预期收益：** 帮助您获得您可能已经有资格获得的福利，并了解您可以保留哪些雇主缴款。
- **优先级：** 随后完善。
- **依据：**规则；指导。 [劳工部：了解您的退休计划](https://www.dol.gov/sites/dolgov/files/ebsa/about-ebsa/our-activities/resource-center/publications/your-retirement-benefits.pdf)。

<a id="092-compare-broad-funds-by-holdings-and-fees"></a>

## 09.2 按持仓和费用比较广泛分散的基金

**中国读者怎么用：** 定居：先确认雇主计划、合格收入、税务身份及账户条件。 签证：跨境搬迁、离美提取和税收协定可能改变结果，应先核对。 游客：本条主要是长期账户知识；不要只为旅游开设退休账户。参见[税务入口](../CHINESE-READERS.md)。

对于长期资金，请比较您的计划或经纪业务中可用的多元化基金。阅读招股说明书，了解持股、费用比率、销售费用和其他账户成本。广泛的指数基金可能是一个有用的候选者，但“指数”一词并不能保证低费用或广泛的多元化。目标日期基金可以逐步调整资产配置，但相同日期的基金可能承担不同的风险。选择您理解的组合并避免重复持仓导致风险过度集中。

- **成本与投入：** 研究是免费的；最初估计一小时。基金费用和账户费用持续存在，投资价值可能会下降。
- **预期收益：** 帮助您选择可理解的风险敞口，并保留更多扣除费用后的回报；更便宜的基金并不一定适合。
- **优先级：** 随后完善。
- **依据：** 指导；实践。 [Investor.gov：指数基金](https://www.investor.gov/introduction-investing/investing-basics/investment-products/mutual-funds-and-exchange-traded-4)，[Investor.gov：目标日期基金](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins/target-date-funds-investor-bulletin)。

<a id="093-match-investment-risk-to-when-you-need-the-money"></a>

## 09.3 按用钱时间选择投资风险

**中国读者怎么用：** 定居：先确认雇主计划、合格收入、税务身份及账户条件。 签证：跨境搬迁、离美提取和税收协定可能改变结果，应先核对。 游客：本条主要是长期账户知识；不要只为旅游开设退休账户。参见[税务入口](../CHINESE-READERS.md)。

写下每个目标、它的截止日期，以及你可以忍受多少损失而不放弃它。即将到来的账单或近期购买的资金通常需要与几十年后退休时不同的方法。选择适合您承担风险的能力和意愿的资产配置。定期或在生活发生重大变化后进行回顾。多元化可以降低集中度风险，但不能保证在市场下跌时盈利或防止损失。

- **成本与投入：** 免费规划；最初估计 30-45 分钟，然后定期回顾。交易、税收和建议可能涉及费用，具体取决于您的账户。
- **预期收益：** 减少市场低迷迫使您在固定期限内需要现金时出售投资的机会。
- **优先级：** 随后完善。
- **依据：** 指导；实践。 [Investor.gov：资产配置和多元化](https://www.investor.gov/introduction-investing/getting-started/asset-allocation)。

<a id="094-check-ira-tax-treatment-before-contributing-or-rolling-over"></a>

## 09.4 供款或转存前核对IRA税务处理

**中国读者怎么用：** 定居：先确认雇主计划、合格收入、税务身份及账户条件。 签证：跨境搬迁、离美提取和税收协定可能改变结果，应先核对。 游客：本条主要是长期账户知识；不要只为旅游开设退休账户。参见[税务入口](../CHINESE-READERS.md)。

比较传统IRA与Roth IRA的资格、当年供款上限、抵扣规则和提取税务。雇主退休计划与收入会影响可选方式；开了IRA账户也不等于资金已经投资。转移旧雇主账户前，比较两边的费用、投资及保护。决定转存时向两家机构询问直接转存流程。把税前资金转入Roth账户可能产生应税收入；复杂情况先寻求合格税务帮助。对将离美的中国籍读者，还应询问海外地址、提款和跨境申报的后续要求。

- **成本与投入：** 估计一到两个小时进行比较和启动。转账、投资和税务建议可能会产生费用；在授权转换之前确认税收影响。
- **预期收益：** 有助于保留退休储蓄并避免可预防的预扣税、展期错误或意外税单。
- **优先级：** 按需处理。
- **依据：**规则；指导。 [IRS：传统 IRA 和 Roth IRA](https://www.irs.gov/retirement-plans/traditional-and-roth-iras)，[IRS：退休计划和 IRA 滚存](https://www.irs.gov/retirement-plans/plan-participant-employee/rollovers-of-retirement-plan-and-ira-distributions)。

<a id="095-confirm-hsa-eligibility-before-treating-it-as-savings"></a>

## 09.5 使用HSA前确认资格与保单条件

**中国读者怎么用：** 定居：先确认雇主计划、合格收入、税务身份及账户条件。 签证：跨境搬迁、离美提取和税收协定可能改变结果，应先核对。 游客：本条主要是长期账户知识；不要只为旅游开设退休账户。参见[税务入口](../CHINESE-READERS.md)。

询问您的保险公司或福利管理员，您的承保范围是否支持根据现行规则进行 HSA 缴款。检查其他承保范围、医疗保险登记、家属身份和适用的年度限额，包括雇主缴款。资格范围将于 2026 年扩大，因此旧的高免赔额计划清单可能不完整。保留合格医疗费用的收据和足够的可用现金以用于即将进行的护理。仅在账户允许并且您的医疗预算可以承受市场损失和账户费用的情况下投资 HSA 资金。

- **成本与投入：** 估计需要 30-60 分钟来验证资格和费用，然后保留记录。供款会占用可动用现金；州税收待遇可能与联邦税收待遇不同。
- **预期收益：** 正确使用可用的医疗税收优惠，同时降低超额供款或需要为支付医疗费用而被迫出售投资的风险。
- **优先级：** 按需处理。
- **依据：**规则；实践。 [IRS：HSA 资格和合格费用](https://www.irs.gov/publications/p969)，[IRS：扩展 HSA 资格指南](https://www.irs.gov/newsroom/treasury-irs-provide-guidance-on-new-tax-benefits-for-health-savings-account-participants-under-the-one-big-beautiful-bill)。