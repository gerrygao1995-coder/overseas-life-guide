> 中国读者先核对[身份与适用路径](CHINESE-READERS.md)，再使用以下清单或模板；临时签证者与游客不要直接照搬居民项目的申请步骤。

<a id="twelve-situations-twelve-action-checklists"></a>

# 十二种情况，十二项行动清单

这些列表组织了指南。它们不是额外编号的比赛，也不会产生资格或延长截止日期。使用条件和来源的链接条目。遇到紧急危险请拨打 911；如需自杀或心理健康危机支持，请致电或发短信 988。

<a id="1-i-lost-my-job"></a>

## 1.我失业了

- [ ] 保存工资单、福利信息、离职日期和您自己的合法记录。不要拿走雇主的机密文件。
- [ ] 通过相关州失业系统申请并阅读报告说明。 [失业](guide/14-job-loss-and-assistance.md#141-apply-for-unemployment-through-the-correct-state)。
- [ ] 比较更换覆盖范围和注册窗口。 [健康保险](guide/14-job-loss-and-assistance.md#142-compare-health-coverage-before-the-enrollment-window-closes)。
- [ ] 优先考虑必要的账单；检查食品、健康和能源援助。 [必需品](guide/08-debt-scams-setbacks.md#081-protect-essentials-when-there-is-not-enough-money) · [辅助](guide/14-job-loss-and-assistance.md#143-check-food-health-and-energy-help-together)。
- [ ] 在签署前审查任何遣散协议；日历实际的截止日期。 [遣散费](guide/14-job-loss-and-assistance.md#144-save-separation-records-before-reviewing-a-severance-agreement)。
- [ ] 更新一份简历并重新与有用的联系人联系。 [求职工具包](guide/33-career-growth-and-negotiation.md#335-keep-a-job-search-kit-ready-while-you-are-employed)。

<a id="2-i-received-a-large-medical-bill"></a>

## 2. 我收到了一大笔医疗费用

**[打开互动医疗账单复核工具](https://gerrygao1995-coder.github.io/the-american-life-playbook/medical-bills/)**，查看四种处理路径、可打印清单、沟通模板与虚构示例。

- [ ] 将账单与保险公司的福利解释进行比较；它们是不同的文件。
- [ ] 请求逐项审查并检查患者详细信息、服务、调整和付款。
- [ ] 在使用昂贵的信贷之前询问财务援助和申请截止日期。 [账单审核](guide/04-health-insurance.md#044-request-bill-review-and-financial-assistance-before-borrowing)。
- [ ] 如果承保被拒绝，请说明原因和上诉截止日期。 [保险申诉](guide/04-health-insurance.md#045-appeal-a-denial-using-the-reason-and-deadline)。
- [ ] 保留任何付款安排的姓名、日期、参考号、副本和书面确认。
- [ ] 使用[账单审核脚本](TEMPLATES.md#1-medical-bill-review)。请求不会自动停止收集或保留上诉截止日期。

<a id="3-i-am-comparing-job-offers"></a>

## 3. 我正在比较工作机会

- [ ] 写下基本工资、可变工资条件、时间表、地点和通勤。
- [ ] 请求福利费用、承保开始日期、休假期限、退休匹配和归属。 [补偿总额](guide/13-work-pay-and-benefits.md#135-compare-offers-using-a-full-compensation-worksheet)。
- [ ] 检查该工作是否需要许可证或实际可以获得的证书。
- [ ] 研究当地市场的可比工作。 [付费研究](guide/33-career-growth-and-negotiation.md#331-research-the-pay-range-for-the-work-you-actually-do)。
- [ ] 要求具体调整并以书面形式获得最终条款。 [洽谈](guide/33-career-growth-and-negotiation.md#332-make-a-specific-compensation-request-before-accepting)。
- [ ] 比较税后和新开支后的家庭预算，尤其是在搬家的情况下。 [动作比较](guide/30-major-decisions-moving.md#302-compare-a-move-using-take-home-pay-and-actual-expenses)。

<a id="4-i-am-moving-or-choosing-a-home"></a>

## 4. 我要搬家或选择住所

- [ ] 比较每月总成本和预付现金，包括交通、公用事业和押金。 [住房预算](guide/11-renting-buying-home.md#111-set-a-housing-budget-that-survives-the-move)。
- [ ] 阅读租赁或购买条款；记录条件和责任。 [出租记录](guide/11-renting-buying-home.md#112-read-the-lease-and-document-the-condition)。
- [ ] 在投保前对相关保险进行定价。 [灾害报道](guide/11-renting-buying-home.md#115-price-disaster-coverage-before-committing-to-a-home)。
- [ ] 验证州际搬家公司并获得明确的书面条款。 [搬家服务](guide/30-major-decisions-moving.md#303-verify-an-interstate-mover-before-paying-a-deposit)。
- [ ] 计划公用事业变更、重要邮件、药物获取以及家庭之间的差距。
- [ ] 审查受新地点影响的注册、保险和福利。 [身份和公民文书](guide/36-adult-life-and-civic-paperwork.md)。

<a id="5-we-are-having-a-baby"></a>

## 5.我们要生孩子了

- [ ] 与临床医生一起安排产前护理并审查药物。 [产前护理](guide/06-pregnancy-infancy.md#061-arrange-prenatal-care-and-review-medicines-early)。
- [ ] 确认预期分娩覆盖范围和新生儿登记流程。 [覆盖范围](guide/06-pregnancy-infancy.md#062-plan-coverage-for-delivery-and-enroll-the-newborn-promptly)。
- [ ] 单独询问有关受保护休假、带薪休假和残疾福利的信息。 [离开](guide/13-work-pay-and-benefits.md#132-ask-about-protected-leave-before-using-up-your-options)。
- [ ] 准备合适的汽车座椅和安全、独立的睡眠空间。 [汽车座椅](guide/06-pregnancy-infancy.md#064-install-the-car-seat-and-check-its-fit-before-the-first-ride) · [婴儿睡眠](guide/06-pregnancy-infancy.md#063-set-up-an-empty-separate-sleep-space)。
- [ ] 分配实用的产后帮助并了解警告标志。 [产后计划](guide/06-pregnancy-infancy.md#065-make-postpartum-support-and-warning-signs-part-of-the-plan)。
- [ ] 在返回工作日期之前比较儿童保育和可能的援助。 [儿童护理](guide/20-children-and-education.md#201-compare-child-care-with-assistance-included)。

<a id="6-i-received-a-chronic-condition-diagnosis"></a>

## 6. 我收到慢性病诊断

- [ ] 询问诊断意味着什么，现在需要采取什么行动，以及下次就诊应该解决什么问题。
- [ ] 制定一份药物清单，包括非处方产品和补充剂。 【用药安全】(guide/05-chronic-illness.md#051-keep-one-medication-list-and-check-changes)。
- [ ] 索要一份简短的书面护理计划，其中包含需要紧急关注的症状。 [护理计划](guide/05-chronic-illness.md#053-turn-a-chronic-condition-plan-into-a-short-checklist)。
- [ ] 比较适当的药物选择和实际自付费用。 [药品价格](guide/05-chronic-illness.md#052-ask-about-an-appropriate-generic-and-the-actual-price)。
- [ ] 如果需要，检查承保范围和工作安排。 [计划护理](guide/04-health-insurance.md#043-confirm-the-network-and-expected-charges-before-planned-care) · [住宿](guide/13-work-pay-and-benefits.md#134-request-accommodations-and-track-discrimination-deadlines)。
- [ ] 避免仅仅因为在线推荐听起来令人信服而做出重大治疗改变。 [评估健康声明](guide/28-health-claims.md)。

<a id="7-i-think-i-was-scammed"></a>

## 7. 我想我被骗了

- [ ] 使用经过验证的号码快速联系支付提供商；解释付款方式以及发生的情况。无法保证康复。 [诈骗响应](guide/08-debt-scams-setbacks.md#085-interrupt-a-scam-and-act-quickly-after-a-loss)。
- [ ] 通过官方恢复流程，从电子邮件和财务开始，保护受影响的帐户。
- [ ] 保留消息、收据、日期和交易参考。
- [ ] 如果身份信息泄露，请使用官方恢复流程并考虑信用冻结。 [身份盗窃](guide/18-accounts-identity-and-privacy.md#183-start-an-identity-theft-recovery-file-immediately) · [信用冻结](guide/18-accounts-identity-and-privacy.md#182-freeze-credit-when-you-are-not-applying-for-it)。
- [ ] 通过适当的官方渠道举报；不要向承诺保证康复的陌生人付款。
- [ ] 告诉值得信赖的人这是否有助于您采取行动。羞耻感会延迟有用的步骤。

<a id="8-disability-is-changing-my-work-or-daily-life"></a>

## 8. 残疾正在改变我的工作或日常生活

- [ ] 记录功能限制和所需的支持以及医疗信息。
- [ ] 询问具体的工作场所或服务安排。 [工作](guide/13-work-pay-and-benefits.md#134-request-accommodations-and-track-discrimination-deadlines) · [访问](guide/22-disability-and-independent-living.md#223-request-the-access-you-need-in-concrete-terms)。
- [ ] 分别检查 SSDI、SSI 和适用的状态程序。 [收入支持](guide/22-disability-and-independent-living.md#221-ask-about-both-ssdi-and-ssi-when-disability-limits-work)。
- [ ] 询问家庭和社区护理、候补名单和临时选项。 [居家护理](guide/22-disability-and-independent-living.md#222-ask-your-state-about-care-at-home-before-assuming-an-institution-is-required)。
- [ ] 在更改收入或转移储蓄之前，请获取福利指导。 [使用福利](guide/22-disability-and-independent-living.md#225-explore-work-support-without-guessing-what-earnings-will-do-to-benefits) · [ABLE 帐户](guide/22-disability-and-independent-living.md#224-check-able-eligibility-before-building-savings-in-the-wrong-account)。
- [ ] 保留每个上诉或报告截止日期的所有通知和日历。

<a id="9-my-parent-needs-more-care"></a>

## 9. 我的父母需要更多照顾

- [ ] 询问日常活动需要什么帮助以及此人想要什么。
- [ ] 审查健康保险并单独规划监护护理。 [长期护理](guide/21-aging-care-and-end-of-life.md#213-budget-for-everyday-care-separately-from-medicare)。
- [ ] 确定合法授权可帮助做出医疗和财务决策的人员。 [决策者](guide/21-aging-care-and-end-of-life.md#214-choose-decision-makers-while-you-can-express-your-wishes)。
- [ ] 在适当的帮助下审查药物和跌倒风险。 [药物清单](guide/05-chronic-illness.md#051-keep-one-medication-list-and-check-changes) · [跌倒预防](guide/05-chronic-illness.md#055-reduce-fall-risks-before-an-injury-limits-independence)。
- [ ] 询问公共家庭护理支持和护理人员救济（如果有）。 [上门服务](guide/22-disability-and-independent-living.md#222-ask-your-state-about-care-at-home-before-assuming-an-institution-is-required)。
- [ ] 分配现实的职责；在护理人员下班前检查休假选项。 [受保护休假](guide/13-work-pay-and-benefits.md#132-ask-about-protected-leave-before-using-up-your-options)。

<a id="10-i-am-starting-adult-life"></a>

## 10.我即将开始成年生活

- [ ] 找到身份证明文件并安全地保存副本。 [文档文件夹](guide/36-adult-life-and-civic-paperwork.md#362-build-a-secure-identity-document-folder-before-an-appointment)。
- [ ] 通过学校或工作过渡确认健康保险。 [覆盖范围](guide/36-adult-life-and-civic-paperwork.md#361-confirm-health-coverage-through-each-life-transition)。
- [ ] 使用经过验证的第一份工作入职渠道。 [文书工作](guide/36-adult-life-and-civic-paperwork.md#365-complete-first-job-paperwork-only-through-verified-onboarding)。
- [ ] 将银行账户与您的现金流和费用相匹配。 [银行](guide/07-cash-flow-banking-credit.md#073-make-your-checking-account-fit-your-habits)。
- [ ] 使用实际成本和结果比较学校、转学路线和带薪学徒期。 [教育培训](guide/15-education-and-student-loans.md)。
- [ ] 检查您的官方选举办公室的注册规则（如果符合资格），并根据您所在州的流程指定一名医疗决策者。 [投票](guide/36-adult-life-and-civic-paperwork.md#363-check-voter-registration-through-your-official-election-office) · [医疗权威](guide/36-adult-life-and-civic-paperwork.md#364-name-a-medical-decision-maker-before-an-emergency)。

<a id="11-someone-in-my-family-died"></a>

## 11. 我家里有人去世了

- [ ] 如果死亡是意外或情况紧急，请联系紧急服务部门。对于临终关怀下的预期死亡，请遵循护理团队的指示。
- [ ] 向殡葬服务提供者询问死亡证明及其处理哪些通知。索取详细价格表。 【丧葬费】(guide/21-aging-care-and-end-of-life.md#215-ask-for-itemized-funeral-prices-before-choosing-a-package)。
- [ ] 找到遗嘱并确定具有合法权力管理遗产的人。不要仅仅因为您知道密码就分发财产或使用该人的帐户。
- [ ] 将账单和财务记录放在一起。在同意亲自偿还遗产债务之前征求建议；共同签署、共同债务和州配偶规则可以改变责任。
- [ ] 使用[官方通知清单](https://www.usa.gov/report-a-death) 和[FTC 关于已故亲属债务的指导](https://consumer.ftc.gov/articles/debts-and-deceased-relatives)。州遗嘱认证程序决定接下来的法律步骤。
- [ ] 将文书工作分为紧急期限和可以等待的决定。 [悲伤和重大挫折](guide/27-grief-burnout-setbacks.md)。

<a id="12-a-storm-heat-wave-or-wildfire-is-approaching"></a>

## 12. 风暴、热浪或野火即将来临

- [ ] 遵循当地当前的紧急指示，包括疏散命令。
- [ ] 安排交通、目的地、药物获取以及包括宠物和获取需求的联系计划。
- [ ] 准备饮用水和必需品。 [家庭准备](guide/24-travel-and-emergency-preparation.md#241-start-emergency-supplies-with-drinking-water-and-a-household-plan)。
- [ ] 将发电机放置在室外并远离开口；检查一氧化碳警报器。 [一氧化碳安全](guide/24-travel-and-emergency-preparation.md#242-install-working-carbon-monoxide-alarms-and-keep-generators-outside)。
- [ ] 适当准备冷却或清洁的室内空气。 [热度](guide/38-food-home-and-climate-safety.md#384-arrange-cooling-before-a-heat-wave) · [野火烟雾](guide/38-food-home-and-climate-safety.md#385-prepare-a-cleaner-indoor-room-for-wildfire-smoke)。
- [ ] 确保保单和理赔联系信息易于访问；仅在安全的情况下记录损坏情况。 [覆盖差距](guide/29-insurance-large-losses.md#294-identify-flood-and-earthquake-gaps-before-a-disaster)。

[返回剧本](README.md)