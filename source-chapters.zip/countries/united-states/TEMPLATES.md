> 中国读者先核对[身份与适用路径](CHINESE-READERS.md)，再使用以下清单或模板；临时签证者与游客不要直接照搬居民项目的申请步骤。

<a id="ten-scripts-for-the-first-conversation"></a>

# 第一次对话的十个脚本

用你的事实替换括号。这些只是对话的开始，而不是法律文件、医疗命令或所需表格的替代品。发送前验证收件人。不要将帐号、医疗详细信息、身份证件和其他私人信息公开。消息本身不会暂停收集、保留合法权利或延长截止日期。

<a id="1-medical-bill-review"></a>

## 1.医疗账单审核

> 我正在审查[服务日期]的账单。请发送一份详细说明并解释[具体费用或不匹配]。有哪些经济援助可用、如何申请以及截止日期是什么时候？请告诉我在审核或申请等待期间是否可以暂停收集，并以书面形式确认任何安排。

记录帐单参考、所需文件和回复日期。 [阅读条件](guide/04-health-insurance.md#044-request-bill-review-and-financial-assistance-before-borrowing)。

<a id="2-insurance-denial-clarification"></a>

## 2. 保险拒绝澄清

> 我收到了日期为 [日期] 的拒绝通知，参考号为 [编号]。使用的具体原因和计划条款是什么？请发送申诉说明、提交地址、截止日期以及所需文件。我的情况是否可以使用加急流程？我的临床医生必须提交什么？请确认收到我发送的任何上诉。

使用正式的上诉程序；仅此一项调查可能不能算作上诉。 [阅读条件](guide/04-health-insurance.md#045-appeal-a-denial-using-the-reason-and-deadline)。

<a id="3-planned-care-estimate"></a>

## 3. 计划护理估算

> 我正在考虑在 [日期] 进行 [服务]。请确定预期的服务和计费提供商并给我一个估计。哪些费用是分开的？我还将与我的保险公司确认承保范围和网络状态。什么可能会改变金额？如果最终账单有所不同，我应该联系谁？

估价和网络目录列表并不是付款的保证。 [阅读条件](guide/04-health-insurance.md#043-confirm-the-network-and-expected-charges-before-planned-care)。

<a id="4-creditor-hardship-request"></a>

## 4.债权人困难请求

> 我的情况发生了变化，因为[简要说明]。扣除基本费用后，我目前可以负担[实际金额]。有哪些困难选择？请解释利息、费用、信用报告、期限长度以及最后会发生什么。在我同意之前我想要书面条款。

避免在不了解的情况下承诺无法支付的付款或授权提款。 [优先要点](guide/08-debt-scams-setbacks.md#081-protect-essentials-when-there-is-not-enough-money) · [比较合格帮助](guide/08-debt-scams-setbacks.md#084-compare-qualified-help-before-buying-debt-relief)。

<a id="5-collection-verification-inquiry"></a>

## 5. 收款验证查询

> 我收到了您日期为 [日期] 的通知。请注明原始债权人、逐项金额、当前所有者，以及对该债务提出争议或要求核实的流程和截止日期。请通过[适当的验证渠道]发送信息。我正在审查索赔，尚未同意付款安排。

如果您对债务有争议，请遵循通知中合法适用的争议程序和时间安排。此一般询问不是法庭答复。 [验证催收要求](guide/08-debt-scams-setbacks.md#083-verify-collection-demands-before-paying) · [认可传票](guide/17-legal-and-consumer-problems.md#172-distinguish-a-collection-notice-from-a-court-summons)。

<a id="6-rental-repair-request"></a>

## 6. 租赁维修请求

> 我正在报告 [单位] 于 [日期] 首次发现的 [问题]。它影响[特定使用或安全问题]。附上[照片或之前的消息]。请确认收货、后续步骤以及预计的维修时间。我可以在 [选项] 讨论无障碍安排。请以书面形式通知我最新情况。

遵循租赁和当地通知程序。在扣留租金或安排扣除之前，请咨询当地法律援助。 [保留租赁记录](guide/11-renting-buying-home.md#112-read-the-lease-and-document-the-condition) · [寻求法律帮助](guide/17-legal-and-consumer-problems.md#171-find-the-right-legal-help-and-identify-the-next-deadline)。

<a id="7-workplace-accommodation-request"></a>

## 7. 工作场所住宿要求

> 我想讨论一下影响[工作任务]的限制的解决方案。诸如[具体调整]之类的改变可能会帮助我完成这项工作。请解释该流程、适当的保密联系方式以及任何必要的文件。我愿意讨论有效的替代方案。

通过适当的保密渠道提供信息。资格、文件和雇主的义务取决于适用的法律。 [阅读条件](guide/13-work-pay-and-benefits.md#134-request-accommodations-and-track-discrimination-deadlines)。

<a id="8-job-offer-negotiation"></a>

## 8. 工作机会谈判

> 感谢您提供[角色]。基于[相关经验、职责和市场信息]，我想讨论[具体基本工资或其他条款]。 [具体贡献]与角色特别相关。我们可以在[决定日期]之前对此进行审查吗？另请以书面形式发送福利费用和最终条款。

使用真实的证据和明确的要求；给雇主留下回应的空间。 [谈判玩法](guide/33-career-growth-and-negotiation.md#332-make-a-specific-compensation-request-before-accepting)。

<a id="9-contractor-scope-clarification"></a>

## 9. 承包商范围澄清

> 在我签字之前，请指定材料、任务、排除情况、许可责任、付款里程碑、预计时间、清理和保修条款。变更将如何获得批准和定价？请提供我可以验证并确定谁将执行这项工作的许可证和保险详细信息。

通过有关当局和保险公司核实；徽标或屏幕截图是不够的。 [承包商检查](guide/31-repairs-utilities-contracts.md#311-verify-the-contractor-and-permit-requirements-yourself) · [书面范围](guide/31-repairs-utilities-contracts.md#312-put-the-scope-and-changes-in-writing)。

<a id="10-consumer-complaint-escalation"></a>

## 10. 消费者投诉升级

> 在 [日期]，我以 [金额] 购买了 [产品或服务]。问题是[具体差异]。我于[日期]联系[部门]，参考号[号码]。我请求[具体合理的补救措施]。附相关记录。请在[合理请求日期]之前回复，或告诉我哪个部门可以解决此问题。

请求的日期不会改变法定期限。针对该问题选择正确的企业、监管机构、卡纠纷或法庭程序。 [升级](guide/35-travel-and-consumer-disputes.md#355-escalate-with-a-clear-record-and-a-specific-requested-remedy) · [账单争议](guide/35-travel-and-consumer-disputes.md#353-preserve-the-credit-card-billing-dispute-deadline)。

[返回剧本](README.md)