# 按生活场景选择行动顺序

以下顺序属于原作者的编辑建议，请一并阅读各条目的适用条件和注意事项。

## 收集新地点的医疗和紧急联系信息

在您生病之前，轮到您检查一下您通常去哪里就医以及在紧急情况下该去哪里。

1. 通过医疗信息网查找可以就诊的医疗机构。
2. 请咨询您潜在的家庭医生，了解如何进行检查。
3. 保存当地的紧急电话号码和接待时间。
4. 整理用药信息，并确认病情突然变化时应向 119 告知的内容。

### 相关指南

- [使用医疗信息网查找医院。](book/02-healthcare.md#healthcare-02)（healthcare-02）
- [寻找您附近的家庭医生](book/02-healthcare.md#healthcare-01)（healthcare-01）
- [当您不确定是否要去看医生时，请检查#7119](book/05-emergency.md#emergency-02)（emergency-02）
- [一次性向诊所和药房传达药品信息](book/07-medicine.md#medicine-01)（medicine-01）
- [如果您突然出现呼吸困难或一侧瘫痪，请立即拨打 119。](book/05-emergency.md#emergency-01)（emergency-01）

---

## 从疲惫的一周中恢复过来

从短暂的休息开始，如果问题仍然存在，请继续进行咨询。

1. 查看您的身体状况，选择压力较小的休息方式。
2. 反思您的睡眠和休息感觉。
3. 简要写下您的担忧并组织您想要谈论的内容。
4. 如果日常生活继续受到干扰，请联系咨询中心或医疗机构。

### 相关指南

- [疲劳时根据身体状况选择自我保健](book/03-mental.md#mental-01)（mental-01）
- [谈到睡眠，不仅要看时间长短，还要看休息的感觉。](book/01-health.md#health-02)（health-02）
- [把烦恼写成只给自己看的笔记](book/03-mental.md#mental-02)（mental-02）
- [选择一个您可以轻松交谈的方式进行心理健康咨询。](book/03-mental.md#mental-04)（mental-04）
- [向“心理之耳”咨询工作的困扰](book/03-mental.md#mental-05)（mental-05）

---

## 周末回顾一下你家的备灾情况

检查完您所在地区的危险后，准备好您的家并进行储存。

1. 检查危险地图以了解必要的疏散情况。
2. 检查睡眠区和出口周围的家具。
3. 检查食物和便携式厕所是否短缺。
4. 与家人分享有关如何疏散和目的地的信息。

### 相关指南

- [查看您的家庭和工作区域的危险地图](book/06-disaster.md#disaster-01)（disaster-01）
- [防止家具危及睡眠区域和出口](book/06-disaster.md#disaster-03)（disaster-03）
- [通过轮换您每天使用的物品来准备食物。](book/06-disaster.md#disaster-02)（disaster-02）
- [准备一个移动厕所，以防停水](book/06-disaster.md#disaster-06)（disaster-06）
- [暴雨避难不要只等警戒级别发布](book/06-disaster.md#disaster-04)（disaster-04）

---

## 当你开始担心父母的生活时

在听取患者的意愿的同时，我们确认饮食和生活方式的变化以及咨询地点。

1. 询问对方饮食和日常生活方面的问题。
2. 请咨询区域综合支持中心。
3. 如果您需要护理，请查看申请认证的流程。
4. 一起讨论家里的安全问题，例如洗澡，以及您将来想要什么医疗和护理。

### 相关指南

- [想想当食物量减少时可以轻松添加的菜肴。](book/08-aging.md#aging-03)（aging-03）
- [尚未需要长期护理时，就可联系地区综合支援中心](book/08-aging.md#aging-01)（aging-01）
- [如果您需要护理，请咨询我们有关申请认证的事宜。](book/08-aging.md#aging-02)（aging-02）
- [冬季洗澡兼顾温度与家人提醒](book/08-aging.md#aging-05)（aging-05）
- [当谈到紧急医疗护理时，谈论重要的事情。](book/08-aging.md#aging-06)（aging-06）

---

## 当您收到体检信息时，请安排好时间，直到收到为止。

这是您检查可以参加哪些体检、检查结果以及连接必要的体检的顺序。

1. 根据您的保险和工作场所信息检查您的访问地点和费用。
2. 预约并安排一天以在预约后查看结果。
3. 如需详细检查或治疗，请联系医疗机构。
4. 如果您有资格获得健康指导，请检查如何使用该设备，并在预约医生时携带您的进展摘要。

### 相关指南

- [了解哪里可以获取体检信息](book/10-screening.md#screening-01)（screening-01）
- [体检结果提示需就诊时，及时预约后续诊疗](book/10-screening.md#screening-02)（screening-02）
- [具体健康指导信息可用于生活方式咨询。](book/10-screening.md#screening-03)（screening-03）
- [通过“何时、何地以及如何变化？”来讲述症状。](book/02-healthcare.md#healthcare-07)（healthcare-07）

---

## 一旦开始糖尿病治疗，就要为困难的日子做好准备。

除了日常治疗外，还应向医生咨询是否存在低血糖、身体状况不佳以及外出准备等情况。

1. 总结您的药物和联系信息。
2. 检查您的治疗是否需要为低血糖做好准备。
3. 写下发烧或无法进食的日子里您会做什么。
4. 安排眼科检查，并确保在旅行前携带和使用药物。

### 相关指南

- [一次性向诊所和药房传达药品信息](book/07-medicine.md#medicine-01)（medicine-01）
- [了解如何根据您的药物治疗低血糖做好准备](book/14-chronic.md#chronic-03)（chronic-03）
- [写下如果您患有糖尿病，在发烧或无法进食的日子里该怎么办。](book/14-chronic.md#chronic-04)（chronic-04）
- [糖尿病患者不要仅凭视力感受决定是否看眼科](book/14-chronic.md#chronic-02)（chronic-02）
- [旅行前检查您的糖尿病用品](book/14-chronic.md#chronic-05)（chronic-05）

---

## 为残疾人在社区生活提供支持

从人们想要的生活方式出发，讨论如何获得帮助、设备和信息。

1. 在咨询支援台，可以解决当事人的愿望和烦恼。
2. 检查您在家中需要的帮助以及您可以使用的服务的条件。
3. 在购买和使用辅助设备和通信支持之前，请咨询我们。
4. 具体决定发生灾难时的疏散地点以及需要哪些支持。

### 相关指南

- [在选择福利服务之前使用咨询支持](book/15-accessibility.md#accessibility-02)（accessibility-02）
- [咨询家庭护理人员的家务和个人协助](book/15-accessibility.md#accessibility-03)（accessibility-03）
- [在购买或维修辅助器具之前，请检查辅助器具的支付系统。](book/15-accessibility.md#accessibility-12)（accessibility-12）
- [研究沟通支持，例如手语翻译和摘要写作。](book/15-accessibility.md#accessibility-15)（accessibility-15）
- [与地方政府和支持者一起制定个人疏散计划](book/15-accessibility.md#accessibility-16)（accessibility-16）

---

## 夏季到来之前，先给家里降温，准备出门。

检查您的健康状况和居住地，以便您可以在酷热的日子里改变您的计划。

1. 检查空调并继续正常的日常活动。
2. 确定如何检查室温以及重新考虑在炎热天气外出的标准。
3. 了解您可以入住哪些设施以及无法使用空调时的出行方式。
4. 如果怀疑中暑，请与家人联系以了解降温和紧急呼叫的情况。

### 相关指南

- [在天气变热之前做好合理的活动和空调的准备。](book/16-climate.md#climate-09)（climate-09）
- [检查空调的室温，而不仅仅是设定温度。](book/16-climate.md#climate-02)（climate-02）
- [通过高温指数和警报调整您当天的日程安排](book/16-climate.md#climate-01)（climate-01）
- [检查避暑场所位置和开放时间](book/16-climate.md#climate-04)（climate-04）
- [决定没有空调时去哪里](book/16-climate.md#climate-10)（climate-10）
- [炎热天气出现问题时的降温和救援](book/05-emergency.md#emergency-05)（emergency-05）

---

## 离职或考虑离职

一是组织办理短期保险和补助收入转换手续。

1. 在离职前检查您的健康保险选项和申请截止日期。
2. 检查您的离职通知，如果您能够工作，请前往 Hello Work。因病等原因无法工作时，请咨询延长领取期限的事宜。
3. 确认养老金和国民健康保险负担的减轻并保存必要的文件。
4. 生活安定下来后，我会考虑退税和再就业研究。

### 相关指南

- [在离职前比较您的下一个健康保险计划](book/19-pension.md#pension-05)（pension-05）
- [离职后，检查离职表格的内容并前往Hello Work。](book/21-unemployment.md#unemployment-01)（unemployment-01）
- [如果无法缴纳国民年金，请咨询减免/缓缴事宜。](book/19-pension.md#pension-02)（pension-02）
- [检查失业后国民健康保险费减免资格](book/21-unemployment.md#unemployment-06)（unemployment-06）
- [检查未进行年终调整的年份是否可以退款。](book/18-tax.md#tax-03)（tax-03）
- [考虑开展公共职业培训再就业学习](book/22-learning.md#learning-02)（learning-02）

---

## 我想重建我的每月计划

看到支出的整体情况导致合同安排和协商。

1. 从报表中整理您的收入和支出以及年度支出。
2. 检查未使用的正在进行的合同和分期付款的余额。
3. 如果情况没有改善，请联系家庭财务或债务咨询中心。
4. 如果您急需生活费或住房，无需等待整理家庭财务，就可以向公众咨询中心咨询。

### 相关指南

- [先用一张表理清“每月能剩下多少钱”](book/17-money.md#money-01)（money-01）
- [确认订阅直至取消完成](book/23-consumer.md#consumer-04)（consumer-04）
- [对于分期付款，请同时查看每月金额和付款总额。](book/17-money.md#money-03)（money-03）
- [如果您对家庭财务或保险有任何疑问，请联系我们获取免费咨询。](book/17-money.md#money-05)（money-05）
- [如果您发现还款困难，请在增加贷方数量之前咨询我们。](book/17-money.md#money-06)（money-06）
- [如果您在日常生活中遇到任何问题，请咨询独立咨询支持组织。](book/21-unemployment.md#unemployment-04)（unemployment-04）

---

## 我想在工作的同时思考我的下一个职业。

选择您需要从职业研究中学习的内容并组织您的经验。

1. 找出您感兴趣的工作的实际职责和条件。
2. 通过免费咨询写下您的经历并整理您的希望。
3. 在签订合同之前检查课程的费用、时间和福利条件。
4. 比较您所申请的地方的工作条件，并决定它是否适合您的整体生活方式。

### 相关指南

- [不要仅根据职位名称来选择新工作；还要研究工作细节。](book/22-learning.md#learning-03)（learning-03）
- [通过工作卡将您的经验转化为文字](book/22-learning.md#learning-04)（learning-04）
- [如果您不确定自己的职业方向，请使用我们的免费职业咨询服务](book/22-learning.md#learning-05)（learning-05）
- [报名课程前，查清教育训练补助](book/22-learning.md#learning-01)（learning-01）
- [重新学习时，不仅要比较学费，还要比较时间表和完成要求。](book/22-learning.md#learning-06)（learning-06）
- [加入前保存并查看工作条件](book/20-work.md#work-01)（work-01）

---

## 我想安心地使用智能手机和网络支付

一次性组织认证、续订和邮购合同确认。

1. 为电子邮件和付款帐户设置密码和附加身份验证。
2. 检查设备更新和数据备份。
3. 查看官方应用程序的通知并保存订单条件。
4. 了解官方联系点和消费者事务咨询联系方式，以防出现问题。

### 相关指南

- [停止重复使用重要帐户的密码](book/24-digital.md#digital-01)（digital-01）
- [启用多重身份验证并保留恢复选项](book/24-digital.md#digital-02)（digital-02）
- [自动执行设备更新并不时检查是否完成](book/24-digital.md#digital-04)（digital-04）
- [单独备份照片和重要文档](book/24-digital.md#digital-05)（digital-05）
- [从官方应用程序而不是电子邮件链接中查看](book/24-digital.md#digital-03)（digital-03）
- [保存在线订单的最终确认屏幕](book/23-consumer.md#consumer-03)（consumer-03）

---

## 接副业之前，先把条件准备好

先准备合同、实际收入和税务安排，再开始工作。

1. 确认实际工作方式和合同条件属于雇佣还是业务委托。
2. 把工作范围、验收、报酬和手续费写成文字。
3. 确认是否需要发票制度登记，以及交易数据如何保存。
4. 招揽者要求高额预付款或借款时，先咨询，不急于开工。

### 相关指南

- [即使合同名称是“外包”，也要检查实际的工作方式。](book/29-sidework.md#sidework-01)（sidework-01）
- [在接受工作之前收到书面条款和条件](book/29-sidework.md#sidework-02)（sidework-02）
- [不仅确定交货日期，还确定验收标准和期限。](book/29-sidework.md#sidework-03)（sidework-03）
- [根据费用和故障排除情况选择中介站点。](book/29-sidework.md#sidework-08)（sidework-08）
- [登记发票时，请检查消费税申报负担。](book/29-sidework.md#sidework-10)（sidework-10）
- [通过电子邮件收到的发票必须以电子方式存储。](book/29-sidework.md#sidework-11)（sidework-11）
- [介绍副业时让你远程操作借款，应立即停止](book/32-fraud.md#fraud-13)（fraud-13）

---

## 已经看不清还款前景

增加借款之前，先整理合同与家庭收支，再寻求咨询。

1. 保留显示债权人、余额及还款日期的资料。
2. 梳理包括生活费在内的收支，联系公共咨询窗口。
3. 也确认是否适用助学贷款等各项制度的减负措施。
4. 不要搁置催款或法院文件；在继续借款或接受个人贷款前先咨询。

### 相关指南

- [带上贷款人名单来进行还款咨询。](book/25-debt.md#debt-01)（debt-01）
- [再融资时，不仅要比较利率，还要比较还款总额。](book/25-debt.md#debt-02)（debt-02）
- [对于循环付款，检查余额和本金如何减少。](book/25-debt.md#debt-03)（debt-03）
- [核查助学贷款能否申请减少每期还款额](book/25-debt.md#debt-04)（debt-04）
- [如果您无法偿还奖学金，请申请还款宽限期。](book/25-debt.md#debt-05)（debt-05）
- [如果您担心律师费，请查看 Houterasu 的法律援助。](book/25-debt.md#debt-07)（debt-07）
- [不要向社交平台“个人借贷”对象发送证件与个人信息](book/32-fraud.md#fraud-08)（fraud-08）

---

## 想决定职场问题向谁咨询

先保障安全与健康，再选择公司内部咨询或外部解决支援。

1. 有迫近危险或严重不适时，先确保安全、就医等，再制作记录。
2. 整理事件与希望获得的合理便利，确认咨询渠道及信息共享范围。
3. 咨询后出现的不利待遇也要记录，并向劳动局等外部窗口咨询。
4. 协商没有进展时，确认斡旋、劳动审判等的条件和费用。

### 相关指南

- [工作场所存在暴力或威胁时，先离开并前往安全地点](book/30-harassment.md#harassment-01)（harassment-01）
- [当涉及骚扰时，记录事件并分开接触点。](book/20-work.md#work-06)（work-06）
- [骚扰咨询时，确认分享范围和今后的应对措施。](book/30-harassment.md#harassment-02)（harassment-02）
- [单独记录并讨论咨询后出现的任何骚扰或不利之处。](book/30-harassment.md#harassment-12)（harassment-12）
- [对于讨论没有进展的劳工问题，请向劳工局寻求解决支持。](book/30-harassment.md#harassment-13)（harassment-13）
- [如果您正在考虑使用劳工法庭，请在提交请愿书之前准备好材料和问题。](book/30-harassment.md#harassment-14)（harassment-14）

---

## 提前准备家人的财务手续

尊重本人意愿，整理资产、保险与银行联系方式。

1. 在本人同意共享的范围内，整理资产及合同所在处和联系方式。
2. 核对保险联系方式、受益人及代理申请安排。
3. 向银行咨询指定代理手续和所需文件。
4. 不以共享密码或认证码替代正式手续；确定资料保存地点和复核时间。

### 相关指南

- [把资产与借款列在同一张表中](book/17-money.md#money-16)（money-16）
- [结婚、离婚、死亡后确认保险金受益人](book/27-insurance.md#insurance-07)（insurance-07）
- [确定指定的代理索赔人并通知该人。](book/27-insurance.md#insurance-08)（insurance-08）
- [如果您不了解家人的人寿保险，请查看合同查询。](book/27-insurance.md#insurance-15)（insurance-15）
- [如果该人无法前往银行，请咨询该人有关程序。](book/26-banking.md#banking-15)（banking-15）

---

## 已经决定搬家了

从确认合同到变更地址，顺序都是先定时间表。

1. 检查合同类型、总金额和取消条件。
2. 安排运输、收集不需要的物品以及生命线计划。
3. 准备市政和邮政通知并记录入住时的情况。
4. 入住及变更合同地址后办理柜台手续。

### 相关指南

- [不要只看月租，应比较整个居住期间的总费用](book/33-housing.md#housing-01)（housing-01）
- [在定期租房时，请考虑合同结束后您将住在哪里。](book/33-housing.md#housing-04)（housing-04）
- [比较搬家估算，包括工作范围和额外费用。](book/34-moving.md#moving-05)（moving-05）
- [打包前请预约大件垃圾和家电处理。](book/34-moving.md#moving-03)（moving-03）
- [用一张表安排水、电、燃气和通信服务的启停](book/34-moving.md#moving-04)（moving-04）
- [如果您在日本境内搬家，请确认您可以在线提交搬家通知。](book/34-moving.md#moving-01)（moving-01）
- [申请邮件转寄，并向重要寄件方更新地址](book/34-moving.md#moving-02)（moving-02）
- [放入行李前记录房间状况。](book/33-housing.md#housing-02)（housing-02）
- [要更改驾驶执照上的地址，请检查您持卡的方式和预设。](book/34-moving.md#moving-06)（moving-06）

---

## 开始为怀孕和分娩做准备

我们将为您安排产后体检、申请和可以依靠的地方的补贴。

1. 查看怀孕通知和健康检查补贴。
2. 检查咨询支持和福利程序。
3. 了解如何分配家务和使用产后护理。
4. 检查出生后的子女抚养费以及休假支持情况。

### 相关指南

- [确认怀孕后，联系母子健康手册及产检补助窗口](book/35-parenting.md#parenting-01)（parenting-01）
- [查看当地政府为孕妇提供的支持福利和咨询。](book/35-parenting.md#parenting-02)（parenting-02）
- [研究产后护理，咨询有关产后休息和育儿的问题。](book/35-parenting.md#parenting-05)（parenting-05）
- [划分家务时，不仅要写下任务，还要写下步骤。](book/37-relationship.md#relationship-01)（relationship-01）
- [分娩或搬入时，还要检查儿童津贴的申请。](book/35-parenting.md#parenting-03)（parenting-03）
- [临时有事之前，先了解临时托儿服务的使用方式](book/35-parenting.md#parenting-06)（parenting-06）

---

## 我开始担心父母的生活。

倾听当事人的意愿，并为他们提供支持，而不是让家人独自承担。

1. 倾听这个人正在挣扎的事情以及他们想要的生活。
2. 如有必要，请咨询区域综合支持中心并申请认证。
3. 同时检查与工作、服务和成本的兼容性。
4. 如果您对资金管理或交通有疑问，请咨询专家。

### 相关指南

- [护理的切入点是患者居住地的综合支援中心。](book/36-care.md#care-01)（care-01）
- [使用护理服务前，请先申请认证及咨询。](book/36-care.md#care-02)（care-02）
- [在决定离职接受护理之前，研究休假和工作场所制度。](book/36-care.md#care-05)（care-05）
- [使用已发布的信息和实际参观来比较护理设施。](book/36-care.md#care-03)（care-03）
- [如果护理费用高的话，查看一下高额的护理服务费。](book/36-care.md#care-04)（care-04）
- [如果您发现日常管理资金有困难，请联系社会福利理事会。](book/36-care.md#care-06)（care-06）
- [如果您对驾驶有疑问，您和您的家人应该咨询专家。](book/38-mobility.md#mobility-04)（mobility-04）

---

## 创办小型企业

整理出您想要出售的商品，并按顺序检查费用、许可证和合同。

1. 在 Yorozu 支持中心整理问题和联系信息。
2. 在您的创业计划中指定客户、成本和资金。
3. 检查您所在行业所需的许可证并开始记账。
4. 记录交易条款并准备必要的电子文件。

### 相关指南

- [将创业的烦恼交给Yorozu支援中心](book/39-business.md#business-01)（business-01）
- [在购买设备之前将您的商业计划转化为数字](book/39-business.md#business-02)（business-02）
- [如果您出售食品，请在签署财产或设备合同之前联系公共卫生中心。](book/39-business.md#business-05)（business-05）
- [商业交易从第一笔交易开始记录。](book/39-business.md#business-03)（business-03）
- [外包工作时，记录工作内容和付款日期。](book/39-business.md#business-04)（business-04）
- [如果您打算使用电子申请，请尽早准备您的G Biz ID。](book/39-business.md#business-06)（business-06）

---

## 准备升学费用与学习环境

整理家庭负担与本人意愿，寻找适合所处学段的支援。

1. 分别确认入学费用及通学、教材等费用。
2. 查询适合学段的给付与学费支援的申请机关及期限。
3. 家庭收支突变时，在普通申请之外另行咨询。
4. 向学校咨询窗口讨论本人所需的合理便利。

### 相关指南

- [咨询学校或市/区/镇/村您是否有资格获得学费援助。](book/41-education.md#education-01)（education-01）
- [有关高中学费资助的信息，请在入学后查看信息。](book/41-education.md#education-02)（education-02）
- [材料费等请另外确认高中生奖学金等。](book/41-education.md#education-03)（education-03）
- [检查您要就读的学校是否有资格获得教育支持。](book/41-education.md#education-04)（education-04）
- [如果您的家庭经济状况突然发生变化，请咨询申请临时奖学金。](book/41-education.md#education-05)（education-05）
- [在学校咨询中，提供必要考虑因素的具体例子。](book/41-education.md#education-07)（education-07）
- [申请大学残障学生支援，可在入学前开始咨询](book/41-education.md#education-15)（education-15）

---

## 接宠物回家前后要做的事

把是否饲养的决定与登记、日常管理、防灾准备连接起来。

1. 考虑终身费用和照护安排，并确认居住环境允许饲养。
2. 了解领养等选项，核对必要登记和信息变更。
3. 确定常去的动物医院，整理健康记录及储备物资。
4. 查询避难地点条件，以及难以继续饲养时的咨询渠道。

### 相关指南

- [在领养之前讨论日常护理和终身费用。](book/43-pets.md#pets-01)（pets-01）
- [把领养列为选择，并查阅地方自治体的信息](book/43-pets.md#pets-02)（pets-02）
- [管理犬只登记和疫苗接种记录](book/43-pets.md#pets-03)（pets-03）
- [将微芯片名称更改为您自己](book/43-pets.md#pets-04)（pets-04）
- [平时轮换使用宠物应急物资](book/43-pets.md#pets-07)（pets-07）
- [保留健康记录，并确定常去的动物医院](book/43-pets.md#pets-11)（pets-11）
- [确认随行撤离人员的目的地和接受条件。](book/43-pets.md#pets-06)（pets-06）
- [在饲养宠物变得困难之前询问替代护理。](book/43-pets.md#pets-14)（pets-14）

---

## 为长期使用住房做好准备

保存记录，并确定安全检查与维修的优先顺序。

1. 汇总设备说明书和工程记录。
2. 在安全可及的范围内检查火灾警报器、通风、水路等。
3. 咨询抗震性能及需要专业检查的部位。
4. 比较工程内容与报价，在签约前核对补助制度条件。

### 相关指南

- [将房屋图纸和维修历史记录保存在一处](book/44-homecare.md#homecare-01)（homecare-01）
- [检查住宅火灾警报器的运行情况以及何时更换它们。](book/44-homecare.md#homecare-07)（homecare-07）
- [检查通风设备过滤器和进气口](book/44-homecare.md#homecare-08)（homecare-08）
- [如果用水量突然增加，则怀疑漏水。](book/44-homecare.md#homecare-09)（homecare-09）
- [寒潮到来前，检查外露水管的保温](book/44-homecare.md#homecare-12)（homecare-12）
- [对于抗震改造，首先检查诊断和当地支持。](book/44-homecare.md#homecare-04)（homecare-04）
- [核对装修报价中“一式包价”的具体内容](book/44-homecare.md#homecare-02)（homecare-02）
- [如需窗户和热水器方面的帮助，请在签署合同前阅读当年的条款和条件。](book/45-environment.md#environment-06)（environment-06）

---

## 亲近的人去世了

优先办理事发后的申报，在核查给付与继承时也给自己安排休息。

1. 向市区町村及有关人员确认死亡申报和火化许可。
2. 使用丧事办理指南，整理家属自己的保险和养老金等事务。
3. 尽早确认遗嘱、包括债务在内的财产，以及是否申报和相应期限。
4. 难以独自承受痛苦时，联系遗属支援或咨询渠道。

### 相关指南

- [检查谁可以提交死亡通知以及在哪里提交。](book/48-bereavement.md#bereavement-01)（bereavement-01）
- [连接火葬场安排及火葬许可证申请](book/48-bereavement.md#bereavement-02)（bereavement-02）
- [通过丧事综合窗口梳理需要办理的手续](book/48-bereavement.md#bereavement-03)（bereavement-03）
- [供养自己的人去世后，确认自己的医疗保险](book/48-bereavement.md#bereavement-06)（bereavement-06）
- [分别检查养老金死亡通知和未支付金额索赔](book/48-bereavement.md#bereavement-04)（bereavement-04）
- [葬礼结束后，检查您的保险承保的丧葬费用。](book/48-bereavement.md#bereavement-05)（bereavement-05）
- [如果您在家中找到遗嘱，请检查它是否需要遗嘱认证。](book/48-bereavement.md#bereavement-08)（bereavement-08）
- [查询遗嘱是否已存入法务局。](book/48-bereavement.md#bereavement-09)（bereavement-09）
- [如果您正在考虑放弃继承权，请先检查截止日期和财产调查。](book/40-endoflife.md#endoflife-04)（endoflife-04）
- [核查逝者的所得税是否需要办理准确定申报](book/48-bereavement.md#bereavement-13)（bereavement-13）
- [如果您无法独自处理悲伤，请找人倾诉。](book/48-bereavement.md#bereavement-16)（bereavement-16）
