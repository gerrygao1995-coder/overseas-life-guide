# 日本篇来源索引

共 646 个不同来源 URL；逐条沿用日本原版，未把翻译日期写成重新核查日期。各条目的原文核查日期保留在正文。资料可能由日本中央部门、地方自治体或有关机构发布，请按具体适用范围阅读。

## 2023 年健康促进体力活动/锻炼指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[2023 年健康促进体力活动/锻炼指南](https://www.mhlw.go.jp/content/001194020.pdf?content_id=58)
- 相关条目：[health-01](book/01-health.md#health-01)

## 2023年健康促进睡眠指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[2023年健康促进睡眠指南](https://www.mhlw.go.jp/content/10904750/001222166.pdf)
- 相关条目：[health-02](book/01-health.md#health-02)

## 牙科检查（检查）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[牙科检查（检查）](https://kennet.mhlw.go.jp/information/information/dictionary/teeth/yh-039)
- 相关条目：[health-03](book/01-health.md#health-03)

## 戒烟支持

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[戒烟支持](https://kennet.mhlw.go.jp/information/information/tobacco-summaries/t-06.html)
- 相关条目：[health-04](book/01-health.md#health-04)

## 健康饮酒指南（概述）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[健康饮酒指南（概述）](https://www.mhlw.go.jp/content/001680137.pdf)
- 相关条目：[health-05](book/01-health.md#health-05)

## 高血压：预防和改善的生活习惯

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[高血压：预防和改善的生活习惯](https://kennet.mhlw.go.jp/information/information/metabolic/m-05-003)
- 相关条目：[health-06](book/01-health.md#health-06)

## 如何寻找和寻找“家庭医生”

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[如何寻找和寻找“家庭医生”](https://kakarikata.mhlw.go.jp/kakaritsuke/mitsukeru.html)
- 相关条目：[healthcare-01](book/02-healthcare.md#healthcare-01)

## 医疗信息网(Navi)的使用方法

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[医疗信息网(Navi)的使用方法](https://kakarikata.mhlw.go.jp/kakaritsuke/nabii.html)
- 相关条目：[healthcare-02](book/02-healthcare.md#healthcare-02)、[healthcare-08](book/02-healthcare.md#healthcare-08)

## 致所有利用高额医疗费制度的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[致所有利用高额医疗费制度的人](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/iryouhoken/juuyou/kougakuiryou/index.html?hl=ja-JP)
- 相关条目：[healthcare-03](book/02-healthcare.md#healthcare-03)

## 高额医疗费用制度涵盖的费用（指导材料）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[高额医疗费用制度涵盖的费用（指导材料）](https://www.mhlw.go.jp/content/000333280.pdf)
- 相关条目：[healthcare-03](book/02-healthcare.md#healthcare-03)

## 遇到这种情况，请不要犹豫，拨打119。

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[遇到这种情况，请不要犹豫，拨打119。](https://kakarikata.mhlw.go.jp/kakaritsuke/urgency.html)
- 相关条目：[healthcare-03](book/02-healthcare.md#healthcare-03)、[healthcare-06](book/02-healthcare.md#healthcare-06)、[mental-03](book/03-mental.md#mental-03)、[emergency-01](book/05-emergency.md#emergency-01)、[emergency-02](book/05-emergency.md#emergency-02)、[emergency-03](book/05-emergency.md#emergency-03)、[medicine-01](book/07-medicine.md#medicine-01)、[medicine-02](book/07-medicine.md#medicine-02)、[health-10](book/01-health.md#health-10)、[healthcare-07](book/02-healthcare.md#healthcare-07)、[healthcare-09](book/02-healthcare.md#healthcare-09)、[healthcare-14](book/02-healthcare.md#healthcare-14)、[emergency-10](book/05-emergency.md#emergency-10)、[disaster-10](book/06-disaster.md#disaster-10)、[disaster-13](book/06-disaster.md#disaster-13)、[medicine-08](book/07-medicine.md#medicine-08)、[medicine-14](book/07-medicine.md#medicine-14)

## 癌症筛查

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[癌症筛查](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000059490.html)
- 相关条目：[healthcare-04](book/02-healthcare.md#healthcare-04)、[screening-02](book/10-screening.md#screening-02)、[screening-04](book/10-screening.md#screening-04)、[screening-05](book/10-screening.md#screening-05)、[screening-06](book/10-screening.md#screening-06)、[screening-07](book/10-screening.md#screening-07)、[screening-08](book/10-screening.md#screening-08)

## 医院“咨询柜台”

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[医院“咨询柜台”](https://kakarikata.mhlw.go.jp/consultation/)
- 相关条目：[healthcare-05](book/02-healthcare.md#healthcare-05)、[healthcare-15](book/02-healthcare.md#healthcare-15)、[healthcare-16](book/02-healthcare.md#healthcare-16)

## 就诊医疗机构时

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[就诊医疗机构时](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/iryou/jushin.html)
- 相关条目：[healthcare-06](book/02-healthcare.md#healthcare-06)、[medicine-01](book/07-medicine.md#medicine-01)、[healthcare-07](book/02-healthcare.md#healthcare-07)、[healthcare-09](book/02-healthcare.md#healthcare-09)、[healthcare-14](book/02-healthcare.md#healthcare-14)、[disaster-10](book/06-disaster.md#disaster-10)、[medicine-08](book/07-medicine.md#medicine-08)、[medicine-14](book/07-medicine.md#medicine-14)

## 如果您在用药过程中感觉异常

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[如果您在用药过程中感觉异常](https://www.pmda.go.jp/safety/consultation-for-patients/on-drugs/info/0001.html)
- 相关条目：[healthcare-06](book/02-healthcare.md#healthcare-06)、[healthcare-07](book/02-healthcare.md#healthcare-07)、[healthcare-09](book/02-healthcare.md#healthcare-09)、[healthcare-14](book/02-healthcare.md#healthcare-14)、[medicine-08](book/07-medicine.md#medicine-08)、[medicine-14](book/07-medicine.md#medicine-14)

## 自我照顾身心

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[自我照顾身心](https://www.mhlw.go.jp/kokoro/youth/stress/self/index.html)
- 相关条目：[mental-01](book/03-mental.md#mental-01)、[mental-16](book/03-mental.md#mental-16)

## 写下你现在的感受

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[写下你现在的感受](https://www.mhlw.go.jp/kokoro/youth/stress/self/self_02.html)
- 相关条目：[mental-02](book/03-mental.md#mental-02)

## 重复腹式呼吸

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[重复腹式呼吸](https://www.mhlw.go.jp/kokoro/youth/stress/self/self_03.html)
- 相关条目：[mental-03](book/03-mental.md#mental-03)

## 咨询地点一览

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[咨询地点一览](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/jisatsu/soudan_info.html)
- 相关条目：[mental-04](book/03-mental.md#mental-04)、[mental-15](book/03-mental.md#mental-15)

## 119紧急呼叫

- 发布机构：总务省消防厅
- 原始资料：[119紧急呼叫](https://www.fdma.go.jp/mission/enrichment/kyukyumusen_kinkyutuhou/119.html)
- 相关条目：[mental-04](book/03-mental.md#mental-04)、[emergency-01](book/05-emergency.md#emergency-01)、[health-10](book/01-health.md#health-10)、[mental-15](book/03-mental.md#mental-15)、[emergency-10](book/05-emergency.md#emergency-10)、[disaster-13](book/06-disaster.md#disaster-13)、[harassment-01](book/30-harassment.md#harassment-01)

## 面向上班族的“心耳电话咨询”

- 发布机构：厚生劳动省“心之咪咪”
- 原始资料：[面向上班族的“心耳电话咨询”](https://kokoro.mhlw.go.jp/tel-soudan/)
- 相关条目：[mental-05](book/03-mental.md#mental-05)

## 看门人培训文本：听力

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[看门人培训文本：听力](https://www.mhlw.go.jp/content/text3_05_10-18.pdf)
- 相关条目：[mental-06](book/03-mental.md#mental-06)

## 成为守门人！成人用

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[成为守门人！成人用](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/gatekeeper1.html)
- 相关条目：[mental-06](book/03-mental.md#mental-06)

## 家庭食物中毒预防

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[家庭食物中毒预防](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/syokuchu/01_00008.html)
- 相关条目：[food-01](book/04-food.md#food-01)、[food-02](book/04-food.md#food-02)、[food-08](book/04-food.md#food-08)、[food-14](book/04-food.md#food-14)、[food-15](book/04-food.md#food-15)

## 关于弯曲菌食物中毒的预防（Q&A）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于弯曲菌食物中毒的预防（Q&A）](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/syokuchu/campylobacterqa.html)
- 相关条目：[food-03](book/04-food.md#food-03)

## 食品标签标准问答：有效期显示

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[食品标签标准问答：有效期显示](https://www.caa.go.jp/policies/policy/food_labeling/food_labeling_act/assets/food_labeling_cms201_250328_1032.pdf)
- 相关条目：[food-04](book/04-food.md#food-04)

## 关于异尖线虫食物中毒的问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于异尖线虫食物中毒的问答](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/syokuchu/05107.html)
- 相关条目：[food-05](book/04-food.md#food-05)

## 保健食品（面向大众）

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[保健食品（面向大众）](https://www.caa.go.jp/policies/policy/consumer_safety/food_safety/food_safety_portal/health_food/)
- 相关条目：[food-06](book/04-food.md#food-06)

## 紧急救援中心的业务是什么（#7119）？

- 发布机构：总务省消防厅
- 原始资料：[紧急救援中心的业务是什么（#7119）？](https://www.fdma.go.jp/mission/enrichment/appropriate/appropriate007.html)
- 相关条目：[emergency-02](book/05-emergency.md#emergency-02)

## 关于儿童医疗电话咨询业务（#8000）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于儿童医疗电话咨询业务（#8000）](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/newpage_55223.html)
- 相关条目：[emergency-03](book/05-emergency.md#emergency-03)

## 面向公众的急救网络培训

- 发布机构：总务省消防厅
- 原始资料：[面向公众的急救网络培训](https://www.fdma.go.jp/relocation/kyukyukikaku/oukyu/pages/shinpai/shinpai_01.html)
- 相关条目：[emergency-04](book/05-emergency.md#emergency-04)

## 有关紧急/救援的问题

- 发布机构：总务省消防厅
- 原始资料：[有关紧急/救援的问题](https://www.fdma.go.jp/about/question/cat2/)
- 相关条目：[emergency-04](book/05-emergency.md#emergency-04)

## 急救网络课程：任何人都可以使用 AED

- 发布机构：总务省消防厅
- 原始资料：[急救网络课程：任何人都可以使用 AED](https://www.fdma.go.jp/relocation/kyukyukikaku/oukyu/05kobetsu/01/05_01_20.html)
- 相关条目：[emergency-04](book/05-emergency.md#emergency-04)

## 预防中暑

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[预防中暑](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000170795.html)
- 相关条目：[emergency-05](book/05-emergency.md#emergency-05)

## 住宅火灾报警常见问题解答

- 发布机构：总务省消防厅
- 原始资料：[住宅火灾报警常见问题解答](https://www.fdma.go.jp/relocation/html/life/yobou_contents/qa/index.html)
- 相关条目：[emergency-06](book/05-emergency.md#emergency-06)

## 如何使用危险地图门户网站

- 发布机构：地理测量研究所
- 原始资料：[如何使用危险地图门户网站](https://disaportal.gsi.go.jp/hazardmapportal/hazardmap/pamphlet/pamphlet.html)
- 相关条目：[disaster-01](book/06-disaster.md#disaster-01)、[disaster-11](book/06-disaster.md#disaster-11)

## 让我们从我们能做什么开始吧！防灾措施第3部分

- 发布机构：日本内阁府（内閣府）
- 原始资料：[让我们从我们能做什么开始吧！防灾措施第3部分](https://www.bousai.go.jp/kohou/kouhoubousai/h25/73/bousaitaisaku.html)
- 相关条目：[disaster-02](book/06-disaster.md#disaster-02)

## 如何防止地震导致家具倒塌：家具摆放

- 发布机构：总务省消防厅
- 原始资料：[如何防止地震导致家具倒塌：家具摆放](https://www.fdma.go.jp/publication/database/kagu/post7.html)
- 相关条目：[disaster-03](book/06-disaster.md#disaster-03)

## 关于新的防灾气象信息（令和 8 年起）

- 发布机构：日本气象厅
- 原始资料：[关于新的防灾气象信息（令和 8 年起）](https://www.jma.go.jp/jma/kishou/know/bosai/keiho-update2026/)
- 相关条目：[disaster-04](book/06-disaster.md#disaster-04)

## 为地震和海啸灾害做好准备

- 发布机构：日本气象厅福冈地方气象观测所
- 原始资料：[为地震和海啸灾害做好准备](https://www.data.jma.go.jp/fukuoka/jikazan/jikazan_sonae.html)
- 相关条目：[disaster-05](book/06-disaster.md#disaster-05)

## 存放应急厕所

- 发布机构：日本内阁府（内閣府）
- 原始资料：[存放应急厕所](https://www.bousai.go.jp/kohou/kouhoubousai/r05/108/news_09.html)
- 相关条目：[disaster-06](book/06-disaster.md#disaster-06)

## 使用市售药品时的注意事项

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[使用市售药品时的注意事项](https://www.pmda.go.jp/safety/consultation-for-patients/on-drugs/qa/0011.html)
- 相关条目：[medicine-01](book/07-medicine.md#medicine-01)、[medicine-03](book/07-medicine.md#medicine-03)、[disaster-10](book/06-disaster.md#disaster-10)

## 使用处方药时的注意事项

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[使用处方药时的注意事项](https://www.pmda.go.jp/safety/consultation-for-patients/on-drugs/qa/0001.html)
- 相关条目：[medicine-02](book/07-medicine.md#medicine-02)、[medicine-05](book/07-medicine.md#medicine-05)

## 每种严重副作用疾病的处理手册（针对患者和公众）

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[每种严重副作用疾病的处理手册（针对患者和公众）](https://www.pmda.go.jp/safety/info-services/drugs/adr-info/manuals-for-public/0001.html)
- 相关条目：[medicine-02](book/07-medicine.md#medicine-02)

## 吃药期间可以开车吗？

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[吃药期间可以开车吗？](https://www.pmda.go.jp/safety/consultation-for-patients/on-drugs/qa/0018.html)
- 相关条目：[medicine-04](book/07-medicine.md#medicine-04)

## PMDA 药品检索

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[PMDA 药品检索](https://www.pmda.go.jp/okusuri_search/)
- 相关条目：[medicine-06](book/07-medicine.md#medicine-06)

## 社区综合照护体系：社区综合支持中心

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[社区综合照护体系：社区综合支持中心](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/kaigo_koureisha/chiiki-houkatsu/)
- 相关条目：[aging-01](book/08-aging.md#aging-01)、[aging-04](book/08-aging.md#aging-04)、[aging-16](book/08-aging.md#aging-16)、[care-01](book/36-care.md#care-01)

## 关于护理保险制度：如何利用护理服务

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于护理保险制度：如何利用护理服务](https://www.mhlw.go.jp/content/12300000/001238058.pdf?1784936840590=)
- 相关条目：[aging-02](book/08-aging.md#aging-02)、[aging-10](book/08-aging.md#aging-10)、[aging-11](book/08-aging.md#aging-11)、[aging-12](book/08-aging.md#aging-12)

## 健康饮食并预防虚弱

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[健康饮食并预防虚弱](https://kayoinoba.mhlw.go.jp/article/002/)
- 相关条目：[aging-03](book/08-aging.md#aging-03)

## 预防衰弱的 3 个要点

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[预防衰弱的 3 个要点](https://www.mhlw.go.jp/content/000620854.pdf)
- 相关条目：[aging-04](book/08-aging.md#aging-04)

## 让我们大家了解并预防涉及老年人的事故。

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[让我们大家了解并预防涉及老年人的事故。](https://www.caa.go.jp/policies/policy/consumer_safety/caution/caution_009)
- 相关条目：[aging-05](book/08-aging.md#aging-05)、[aging-07](book/08-aging.md#aging-07)

## 老年人意外事故的数据和建议

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[老年人意外事故的数据和建议](https://www.caa.go.jp/policies/policy/consumer_safety/caution/caution_055/assets/caution_055_211208_0002.pdf)
- 相关条目：[aging-05](book/08-aging.md#aging-05)、[aging-07](book/08-aging.md#aging-07)

## “人生大会”，助你活出自己的样子

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[“人生大会”，助你活出自己的样子](https://www.mhlw.go.jp/web_magazine/feature/20260601.html)
- 相关条目：[aging-06](book/08-aging.md#aging-06)

## 急性呼吸道感染防治问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[急性呼吸道感染防治问答](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/infulenza/QA2025.html)
- 相关条目：[health-07](book/01-health.md#health-07)、[health-09](book/01-health.md#health-09)、[health-10](book/01-health.md#health-10)、[healthcare-08](book/02-healthcare.md#healthcare-08)、[medicine-10](book/07-medicine.md#medicine-10)、[screening-15](book/10-screening.md#screening-15)

## 咳嗽礼仪

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[咳嗽礼仪](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000187997.html)
- 相关条目：[health-08](book/01-health.md#health-08)

## 致所有育儿一代：被动吸烟

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[致所有育儿一代：被动吸烟](https://jyudokitsuen.mhlw.go.jp/people/kosodate/)
- 相关条目：[health-11](book/01-health.md#health-11)

## 关于耳机听力损失

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于耳机听力损失](https://kennet.mhlw.go.jp/information/information/sensory-organ/s-002)
- 相关条目：[health-12](book/01-health.md#health-12)

## 信息设备作业职业健康管理指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[信息设备作业职业健康管理指南](https://telework.mhlw.go.jp/kagayakutelework/seminar/2019/pdf/tokyo03/kataoka190917.pdf)
- 相关条目：[health-13](book/01-health.md#health-13)、[health-14](book/01-health.md#health-14)

## 动物源性传染病

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[动物源性传染病](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou18/index.html)
- 相关条目：[health-15](book/01-health.md#health-15)

## 蜱传感染

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[蜱传感染](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000164495.html)
- 相关条目：[health-16](book/01-health.md#health-16)

## 如何识别和处理健康和医疗信息

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[如何识别和处理健康和医疗信息](https://www.ejim.mhlw.go.jp/guidance/health-info.html)
- 相关条目：[healthcare-10](book/02-healthcare.md#healthcare-10)、[healthcare-13](book/02-healthcare.md#healthcare-13)

## 如何确认资格

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[如何确认资格](https://www.mhlw.go.jp/stf/newpage_50657.html)
- 相关条目：[healthcare-11](book/02-healthcare.md#healthcare-11)、[healthcare-12](book/02-healthcare.md#healthcare-12)

## 压力检查系统相关Q&A

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[压力检查系统相关Q&A](https://kokoro.mhlw.go.jp/etc/kaiseianeihou/qa/)
- 相关条目：[mental-07](book/03-mental.md#mental-07)

## 工作场所的心理健康措施

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[工作场所的心理健康措施](https://www.mhlw.go.jp/stf/newpage_71447.html)
- 相关条目：[mental-08](book/03-mental.md#mental-08)、[mental-09](book/03-mental.md#mental-09)

## 求职者压力检查及邮件咨询业务

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[求职者压力检查及邮件咨询业务](https://kyushokustress-mailsoudan.mhlw.go.jp/)
- 相关条目：[mental-10](book/03-mental.md#mental-10)

## 成瘾措施

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[成瘾措施](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000070789.html)
- 相关条目：[mental-11](book/03-mental.md#mental-11)

## 对于那些想了解更多关于成瘾的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[对于那些想了解更多关于成瘾的人](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000149274.html)
- 相关条目：[mental-12](book/03-mental.md#mental-12)

## 对于那些在家庭中与药物问题作斗争的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[对于那些在家庭中与药物问题作斗争的人](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/iyakuhin/yakubuturanyou/other/kazoku_dokuhon.html)
- 相关条目：[mental-13](book/03-mental.md#mental-13)

## 婴幼儿健康检查项目实践指南

- 发布机构：日本国立成育医疗研究中心发布资料
- 原始资料：[婴幼儿健康检查项目实践指南](https://www.ncchd.go.jp/center/activity/kokoro_jigyo/guide.pdf)
- 相关条目：[mental-14](book/03-mental.md#mental-14)

## 制作便当盒防止食物中毒

- 发布机构：日本农林水产省（農林水産省）
- 原始资料：[制作便当盒防止食物中毒](https://www.maff.go.jp/j/syouan/seisaku/foodpoisoning/lunchbox.html?a8=um8TvmNQ)
- 相关条目：[food-07](book/04-food.md#food-07)

## 食物中毒原因（细菌除外）：诺如病毒

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[食物中毒原因（细菌除外）：诺如病毒](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/syokuchu/03.html)
- 相关条目：[food-09](book/04-food.md#food-09)、[food-10](book/04-food.md#food-10)

## 1岁以后就可以喝蜂蜜了

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[1岁以后就可以喝蜂蜜了](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000161461.html)
- 相关条目：[food-11](book/04-food.md#food-11)

## 食物中毒

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[食物中毒](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/syokuchu/index.html)
- 相关条目：[food-12](book/04-food.md#food-12)

## 李斯特菌引起的食物中毒

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[李斯特菌引起的食物中毒](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000055260.html)
- 相关条目：[food-13](book/04-food.md#food-13)

## 预防外卖和送货过程中的食物中毒

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[预防外卖和送货过程中的食物中毒](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/syokuchu/01_00003.html)
- 相关条目：[food-16](book/04-food.md#food-16)

## 第 11 章 急救：止血与烧伤的应急处理

- 发布机构：东京消防署
- 原始资料：[第 11 章 急救：止血与烧伤的应急处理](https://www.tfd.metro.tokyo.lg.jp/ts/bfc_manual/instructor/cp11.html)
- 相关条目：[emergency-07](book/05-emergency.md#emergency-07)、[emergency-08](book/05-emergency.md#emergency-08)

## 儿童事故预防手册

- 发布机构：消费者厅/儿童家庭厅
- 原始资料：[儿童事故预防手册](https://www.caa.go.jp/policies/council/csic/report/report_025/assets/csic_cms201_260424_01.pdf)
- 相关条目：[emergency-09](book/05-emergency.md#emergency-09)、[emergency-12](book/05-emergency.md#emergency-12)、[emergency-13](book/05-emergency.md#emergency-13)

## 儿童事故预防调查：误食

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[儿童事故预防调查：误食](https://www.caa.go.jp/policies/future/project/project_005/investigation/)
- 相关条目：[emergency-10](book/05-emergency.md#emergency-10)

## 防止纽扣电池被意外吞食

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[防止纽扣电池被意外吞食](https://www.caa.go.jp/policies/policy/consumer_safety/child/project_001/mail/20210318/)
- 相关条目：[emergency-11](book/05-emergency.md#emergency-11)

## 外出时请小心儿童发生水事故。

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[外出时请小心儿童发生水事故。](https://www.caa.go.jp/policies/policy/consumer_safety/caution/caution_051)
- 相关条目：[emergency-14](book/05-emergency.md#emergency-14)

## 如何保护自己免受雷击

- 发布机构：日本气象厅
- 原始资料：[如何保护自己免受雷击](https://www.jma.go.jp/jma/kishou/know/toppuu/thunder4-3.html)
- 相关条目：[emergency-15](book/05-emergency.md#emergency-15)

## 谨防停电时发电机引起的一氧化碳中毒和恢复供电后因电引起的火灾。

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[谨防停电时发电机引起的一氧化碳中毒和恢复供电后因电引起的火灾。](https://www.caa.go.jp/policies/policy/consumer_safety/caution/caution_070/)
- 相关条目：[emergency-16](book/05-emergency.md#emergency-16)、[disaster-15](book/06-disaster.md#disaster-15)

## 您做好应对自然灾害的充分准备了吗？

- 发布机构：日本内阁府（内閣府）
- 原始资料：[您做好应对自然灾害的充分准备了吗？](https://www.bousai.go.jp/kyoiku/hokenkyousai/check.html)
- 相关条目：[disaster-07](book/06-disaster.md#disaster-07)

## 特色：全家防灾

- 发布机构：日本内阁府（内閣府）
- 原始资料：[特色：全家防灾](https://www.bousai.go.jp/kohou/kouhoubousai/h23/66/special_01.html)
- 相关条目：[disaster-08](book/06-disaster.md#disaster-08)、[disaster-09](book/06-disaster.md#disaster-09)、[disaster-10](book/06-disaster.md#disaster-10)、[disaster-16](book/06-disaster.md#disaster-16)

## 关于您当地的疏散中心

- 发布机构：日本内阁府（内閣府）
- 原始资料：[关于您当地的疏散中心](https://www.bousai.go.jp/taisaku/hinanjo/pdf/leaflet.pdf?ver=1753843742060)
- 相关条目：[disaster-11](book/06-disaster.md#disaster-11)、[disaster-12](book/06-disaster.md#disaster-12)、[disaster-13](book/06-disaster.md#disaster-13)

## 预防经济舱综合症

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[预防经济舱综合症](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000212521_00001.html)
- 相关条目：[disaster-14](book/06-disaster.md#disaster-14)

## 防灾特辑：灾害发生时的应对措施

- 发布机构：政府公共关系在线
- 原始资料：[防灾特辑：灾害发生时的应对措施](https://www.gov-online.go.jp/tokusyu/bousai/disaster.html)
- 相关条目：[disaster-16](book/06-disaster.md#disaster-16)

## 你应该知道的医学故事

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[你应该知道的医学故事](https://www.pmda.go.jp/files/000226365.pdf)
- 相关条目：[medicine-07](book/07-medicine.md#medicine-07)、[medicine-09](book/07-medicine.md#medicine-09)

## 个人进口存在风险隐患

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[个人进口存在风险隐患](https://www.yakubutsu.mhlw.go.jp/individualimport/)
- 相关条目：[medicine-11](book/07-medicine.md#medicine-11)

## 药物副作用缓解系统

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[药物副作用缓解系统](https://www.pmda.go.jp/kenkouhigai_camp/)
- 相关条目：[medicine-12](book/07-medicine.md#medicine-12)

## 患者的药物副作用报告

- 发布机构：药品和医疗器械管理局 (PMDA)
- 原始资料：[患者的药物副作用报告](https://www.pmda.go.jp/safety/reports/patients/0024.html)
- 相关条目：[medicine-13](book/07-medicine.md#medicine-13)

## 请从包装纸中取出药物并饮用。

- 发布机构：药品医疗器械管理局 (PMDA) 出版的材料
- 原始资料：[请从包装纸中取出药物并饮用。](https://www.pmda.go.jp/files/000144217.pdf)
- 相关条目：[medicine-15](book/07-medicine.md#medicine-15)

## 怀孕和药物信息中心

- 发布机构：国家儿童健康与发展中心
- 原始资料：[怀孕和药物信息中心](https://www.ncchd.go.jp/kusuri/)
- 相关条目：[medicine-16](book/07-medicine.md#medicine-16)

## 母乳喂养期间的药物咨询

- 发布机构：国家儿童健康与发展中心
- 原始资料：[母乳喂养期间的药物咨询](https://www.ncchd.go.jp/kusuri/lactation/sodan_junyu.html)
- 相关条目：[medicine-16](book/07-medicine.md#medicine-16)

## 福利设备/房屋改造

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[福利设备/房屋改造](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000212398.html)
- 相关条目：[aging-08](book/08-aging.md#aging-08)、[aging-09](book/08-aging.md#aging-09)、[care-07](book/36-care.md#care-07)、[care-08](book/36-care.md#care-08)

## 痴呆症相关咨询

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[痴呆症相关咨询](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000076236_00003.html)
- 相关条目：[aging-13](book/08-aging.md#aging-13)、[aging-14](book/08-aging.md#aging-14)、[care-13](book/36-care.md#care-13)、[care-14](book/36-care.md#care-14)

## 日常生活独立支援项目

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[日常生活独立支援项目](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/chiiki-fukusi-yougo/index.html)
- 相关条目：[aging-15](book/08-aging.md#aging-15)、[care-06](book/36-care.md#care-06)

## 如何选择和使用牙刷和牙膏

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[如何选择和使用牙刷和牙膏](https://iiha.mhlw.go.jp/column20241129.html)
- 相关条目：[dental-01](book/09-dental.md#dental-01)、[dental-03](book/09-dental.md#dental-03)

## 牙缝清洁（牙线/牙缝刷）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[牙缝清洁（牙线/牙缝刷）](https://kennet.mhlw.go.jp/information/information/teeth/h-03-008.html)
- 相关条目：[dental-02](book/09-dental.md#dental-02)

## 含氟牙膏

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[含氟牙膏](https://kennet.mhlw.go.jp/information/information/teeth/h-02-007)
- 相关条目：[dental-03](book/09-dental.md#dental-03)

## 牙齿健康指导手册

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[牙齿健康指导手册](https://www.mhlw.go.jp/content/001712214.pdf)
- 相关条目：[dental-04](book/09-dental.md#dental-04)、[dental-12](book/09-dental.md#dental-12)、[dental-13](book/09-dental.md#dental-13)、[dental-14](book/09-dental.md#dental-14)

## 根据生命阶段的蛀牙特征

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[根据生命阶段的蛀牙特征](https://kennet.mhlw.go.jp/information/information/teeth/h-02-003.html)
- 相关条目：[dental-05](book/09-dental.md#dental-05)

## 牙周病的主观症状及自查

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[牙周病的主观症状及自查](https://kennet.mhlw.go.jp/information/information/teeth/h-03-003)
- 相关条目：[dental-06](book/09-dental.md#dental-06)、[dental-13](book/09-dental.md#dental-13)

## 口腔功能改善手册等

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[口腔功能改善手册等](https://www.mhlw.go.jp/content/001489487.pdf)
- 相关条目：[dental-07](book/09-dental.md#dental-07)、[dental-08](book/09-dental.md#dental-08)、[dental-09](book/09-dental.md#dental-09)、[dental-11](book/09-dental.md#dental-11)

## 口腔功能对健康的影响

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[口腔功能对健康的影响](https://kennet.mhlw.go.jp/information/information/teeth/h-08-001)
- 相关条目：[dental-08](book/09-dental.md#dental-08)、[dental-09](book/09-dental.md#dental-09)、[dental-10](book/09-dental.md#dental-10)

## PMTC（去除牙垢/清洁牙齿表面）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[PMTC（去除牙垢/清洁牙齿表面）](https://kennet.mhlw.go.jp/information/information/teeth/h-03-009.html)
- 相关条目：[dental-15](book/09-dental.md#dental-15)

## 口臭的治疗和预防

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[口臭的治疗和预防](https://kennet.mhlw.go.jp/information/information/teeth/h-07-002)
- 相关条目：[dental-16](book/09-dental.md#dental-16)

## 关于特定体检和特定健康指导

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于特定体检和特定健康指导](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000161103.html)
- 相关条目：[screening-01](book/10-screening.md#screening-01)、[screening-02](book/10-screening.md#screening-02)、[screening-03](book/10-screening.md#screening-03)

## 关于HPV疫苗的问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于HPV疫苗的问答](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou/hpv_qa.html)
- 相关条目：[screening-07](book/10-screening.md#screening-07)、[screening-11](book/10-screening.md#screening-11)

## 肝炎病毒检测

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[肝炎病毒检测](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/kanen/kangan/hepatitis_kensa.html)
- 相关条目：[screening-09](book/10-screening.md#screening-09)

## HIV检测事实

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[HIV检测事实](https://www.mhlw.go.jp/hivkensa/knowledge/mame/)
- 相关条目：[screening-10](book/10-screening.md#screening-10)

## 关于风疹的问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于风疹的问答](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/rubella_qa.html)
- 相关条目：[screening-12](book/10-screening.md#screening-12)

## 带状疱疹疫苗

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[带状疱疹疫苗](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/yobou-sesshu/vaccine/shingles/index.html)
- 相关条目：[screening-13](book/10-screening.md#screening-13)

## 老年人肺炎球菌疫苗

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[老年人肺炎球菌疫苗](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/yobou-sesshu/vaccine/pneumococcus-senior/)
- 相关条目：[screening-14](book/10-screening.md#screening-14)

## 65 岁及以上人群的疫苗接种

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[65 岁及以上人群的疫苗接种](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou/yobou-sesshu/vaccine/years-65.html)
- 相关条目：[screening-15](book/10-screening.md#screening-15)、[screening-16](book/10-screening.md#screening-16)

## 膳食平衡指南中的适当数量和食物类别

- 发布机构：日本农林水产省（農林水産省）
- 原始资料：[膳食平衡指南中的适当数量和食物类别](https://www.maff.go.jp/j/syokuiku/kenzensyokuseikatsu/about_b_guide.html)
- 相关条目：[nutrition-01](book/11-nutrition.md#nutrition-01)、[nutrition-03](book/11-nutrition.md#nutrition-03)、[nutrition-04](book/11-nutrition.md#nutrition-04)、[nutrition-05](book/11-nutrition.md#nutrition-05)、[nutrition-07](book/11-nutrition.md#nutrition-07)、[nutrition-10](book/11-nutrition.md#nutrition-10)

## 关于饮食指南

- 发布机构：日本农林水产省（農林水産省）
- 原始资料：[关于饮食指南](https://www.maff.go.jp/j/syokuiku/shishinn.html)
- 相关条目：[nutrition-02](book/11-nutrition.md#nutrition-02)、[nutrition-03](book/11-nutrition.md#nutrition-03)、[nutrition-05](book/11-nutrition.md#nutrition-05)、[nutrition-09](book/11-nutrition.md#nutrition-09)、[nutrition-10](book/11-nutrition.md#nutrition-10)、[nutrition-11](book/11-nutrition.md#nutrition-11)

## 饮食预防骨质疏松

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[饮食预防骨质疏松](https://kennet.mhlw.go.jp/information/information/food/e-02-007.html)
- 相关条目：[nutrition-06](book/11-nutrition.md#nutrition-06)

## 膳食纤维

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[膳食纤维](https://kennet.mhlw.go.jp/information/information/dictionary/food/ye-016)
- 相关条目：[nutrition-07](book/11-nutrition.md#nutrition-07)

## 关于营养信息显示

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[关于营养信息显示](https://www.caa.go.jp/policies/policy/food_labeling/nutrient_declearation)
- 相关条目：[nutrition-08](book/11-nutrition.md#nutrition-08)、[nutrition-09](book/11-nutrition.md#nutrition-09)

## 食物过敏标签信息

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[食物过敏标签信息](https://www.caa.go.jp/policies/policy/food_labeling/food_sanitation/allergy/)
- 相关条目：[nutrition-12](book/11-nutrition.md#nutrition-12)

## 关于外出就餐或熟食时的食物过敏

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[关于外出就餐或熟食时的食物过敏](https://www.caa.go.jp/policies/policy/food_labeling/food_sanitation/allergy/efforts)
- 相关条目：[nutrition-13](book/11-nutrition.md#nutrition-13)

## 叶酸和补充剂

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[叶酸和补充剂](https://kennet.mhlw.go.jp/information/information/food/e-05-002)
- 相关条目：[nutrition-14](book/11-nutrition.md#nutrition-14)

## 母乳喂养和断奶支持指南

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[母乳喂养和断奶支持指南](https://www.cfa.go.jp/assets/contents/node/basic_page/field_ref_resources/ff38becb-bbd1-41f3-a95e-3a22ddac09d8/8ad42093/20230401_policies_boshihoken_123.pdf)
- 相关条目：[nutrition-15](book/11-nutrition.md#nutrition-15)

## 贫血

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[贫血](https://www.bosei-navi.mhlw.go.jp/health/anemia.html)
- 相关条目：[nutrition-16](book/11-nutrition.md#nutrition-16)

## 了解运动对女孩及女性益处的基础指南

- 发布机构：体育经纪公司
- 原始资料：[了解运动对女孩及女性益处的基础指南](https://www.mext.go.jp/sports/content/20240509-spt_kensport-000035813_02.pdf)
- 相关条目：[exercise-01](book/12-exercise.md#exercise-01)

## 慢性病患者身体活动要点

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[慢性病患者身体活动要点](https://kennet.mhlw.go.jp/information/information/exercise/s-00-007)
- 相关条目：[exercise-02](book/12-exercise.md#exercise-02)、[exercise-11](book/12-exercise.md#exercise-11)、[exercise-16](book/12-exercise.md#exercise-16)

## 2023 年体力活动/锻炼指南：老年版

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[2023 年体力活动/锻炼指南：老年版](https://kennet.mhlw.go.jp/information/information/exercise/s-00-004)
- 相关条目：[exercise-02](book/12-exercise.md#exercise-02)、[exercise-05](book/12-exercise.md#exercise-05)、[exercise-08](book/12-exercise.md#exercise-08)、[exercise-13](book/12-exercise.md#exercise-13)

## 生活方式改善领域推动的具体例子和效果

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[生活方式改善领域推动的具体例子和效果](https://kennet.mhlw.go.jp/information/information/policy/n-003)
- 相关条目：[exercise-03](book/12-exercise.md#exercise-03)、[exercise-04](book/12-exercise.md#exercise-04)、[exercise-14](book/12-exercise.md#exercise-14)

## 安全进行体力活动/锻炼的要点

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[安全进行体力活动/锻炼的要点](https://kennet.mhlw.go.jp/information/information/exercise/s-00-008.html)
- 相关条目：[exercise-03](book/12-exercise.md#exercise-03)、[exercise-04](book/12-exercise.md#exercise-04)、[exercise-06](book/12-exercise.md#exercise-06)、[exercise-08](book/12-exercise.md#exercise-08)、[exercise-09](book/12-exercise.md#exercise-09)、[exercise-10](book/12-exercise.md#exercise-10)、[exercise-16](book/12-exercise.md#exercise-16)

## 2023 年健康促进体力活动/锻炼指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[2023 年健康促进体力活动/锻炼指南](https://www.mhlw.go.jp/content/001194020.pdf)
- 相关条目：[exercise-05](book/12-exercise.md#exercise-05)、[exercise-12](book/12-exercise.md#exercise-12)

## 关于力量训练

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于力量训练](https://kennet.mhlw.go.jp/information/information/exercise/s-00-005.html)
- 相关条目：[exercise-06](book/12-exercise.md#exercise-06)

## 拉伸的现实

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[拉伸的现实](https://kennet.mhlw.go.jp/information/information/exercise/s-04-007.html)
- 相关条目：[exercise-07](book/12-exercise.md#exercise-07)

## 促进身体活动和锻炼

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[促进身体活动和锻炼](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/undou/index.html)
- 相关条目：[exercise-12](book/12-exercise.md#exercise-12)

## 安全进行体力活动时应注意的事项

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[安全进行体力活动时应注意的事项](https://www.mhlw.go.jp/stf/shingi/2r9852000002ygig-att/2r9852000002ygnd.pdf)
- 相关条目：[exercise-15](book/12-exercise.md#exercise-15)

## 良好睡眠指南成人版

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[良好睡眠指南成人版](https://www.mhlw.go.jp/content/001288005.pdf)
- 相关条目：[sleep-01](book/13-sleep.md#sleep-01)、[sleep-02](book/13-sleep.md#sleep-02)、[sleep-03](book/13-sleep.md#sleep-03)、[sleep-04](book/13-sleep.md#sleep-04)、[sleep-05](book/13-sleep.md#sleep-05)、[sleep-06](book/13-sleep.md#sleep-06)、[sleep-09](book/13-sleep.md#sleep-09)

## 良好的睡眠和生活习惯

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[良好的睡眠和生活习惯](https://kennet.mhlw.go.jp/information/information/heart/k-01-004.html)
- 相关条目：[sleep-01](book/13-sleep.md#sleep-01)、[sleep-04](book/13-sleep.md#sleep-04)、[sleep-05](book/13-sleep.md#sleep-05)、[sleep-06](book/13-sleep.md#sleep-06)

## 你的睡眠质量还好吗？

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[你的睡眠质量还好吗？](https://kennet.mhlw.go.jp/slp/event/sleep_quality/index.html)
- 相关条目：[sleep-02](book/13-sleep.md#sleep-02)

## 异态睡眠

- 发布机构：国家精神病学和神经病学中心
- 原始资料：[异态睡眠](https://www.ncnp.go.jp/nimh/sleep/sleep-medicine/parasomnia/index.html)
- 相关条目：[sleep-07](book/13-sleep.md#sleep-07)

## 失眠

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[失眠](https://kennet.mhlw.go.jp/information/information/heart/k-02-001.html)
- 相关条目：[sleep-08](book/13-sleep.md#sleep-08)、[sleep-10](book/13-sleep.md#sleep-10)、[sleep-15](book/13-sleep.md#sleep-15)

## 良好睡眠指南老年人版

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[良好睡眠指南老年人版](https://www.mhlw.go.jp/content/001288007.pdf)
- 相关条目：[sleep-08](book/13-sleep.md#sleep-08)

## 2023年健康促进睡眠指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[2023年健康促进睡眠指南](https://www.mhlw.go.jp/content/001305530.pdf)
- 相关条目：[sleep-09](book/13-sleep.md#sleep-09)、[sleep-13](book/13-sleep.md#sleep-13)

## 白天嗜睡——小心睡眠/觉醒障碍

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[白天嗜睡——小心睡眠/觉醒障碍](https://kennet.mhlw.go.jp/information/information/heart/k-02-002)
- 相关条目：[sleep-11](book/13-sleep.md#sleep-11)、[sleep-12](book/13-sleep.md#sleep-12)

## 轮班工作睡眠障碍

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[轮班工作睡眠障碍](https://kennet.mhlw.go.jp/information/information/dictionary/heart/yk-017.html)
- 相关条目：[sleep-13](book/13-sleep.md#sleep-13)

## 良好睡眠指南儿童版

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[良好睡眠指南儿童版](https://www.mhlw.go.jp/content/001288006.pdf)
- 相关条目：[sleep-14](book/13-sleep.md#sleep-14)

## 睡个好觉的技巧：睡个好觉所需的寝具条件

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[睡个好觉的技巧：睡个好觉所需的寝具条件](https://kennet.mhlw.go.jp/information/information/heart/k-01-003)
- 相关条目：[sleep-16](book/13-sleep.md#sleep-16)

## 足部护理

- 发布机构：国家健康风险管理研究所糖尿病信息中心
- 原始资料：[足部护理](https://dmic.jihs.go.jp/general/about-dm/040/070/11.html)
- 相关条目：[chronic-01](book/14-chronic.md#chronic-01)

## 视网膜病变

- 发布机构：国家健康风险管理研究所糖尿病信息中心
- 原始资料：[视网膜病变](https://dmic.jihs.go.jp/general/about-dm/060/050/01.html)
- 相关条目：[chronic-02](book/14-chronic.md#chronic-02)

## 低血糖

- 发布机构：国家健康风险管理研究所糖尿病信息中心
- 原始资料：[低血糖](https://dmic.jihs.go.jp/general/about-dm/040/050/05.html)
- 相关条目：[chronic-03](book/14-chronic.md#chronic-03)

## 病假

- 发布机构：国家健康风险管理研究所糖尿病信息中心
- 原始资料：[病假](https://dmic.jihs.go.jp/general/about-dm/040/060/06.html)
- 相关条目：[chronic-04](book/14-chronic.md#chronic-04)

## 糖尿病患者的旅行

- 发布机构：国家健康风险管理研究所糖尿病信息中心
- 原始资料：[糖尿病患者的旅行](https://dmic.jihs.go.jp/general/about-dm/080/010/10.html)
- 相关条目：[chronic-05](book/14-chronic.md#chronic-05)

## 高血压：适合在家测量血压的人

- 发布机构：国家脑心血管研究中心
- 原始资料：[高血压：适合在家测量血压的人](https://www.ncvc.go.jp/hospital/pub/knowledge/disease/hypertension-2/)
- 相关条目：[chronic-06](book/14-chronic.md#chronic-06)

## 关于饮食疗法

- 发布机构：国家脑心血管研究中心
- 原始资料：[关于饮食疗法](https://www.ncvc.go.jp/hospital/pub/knowledge/diet/diet02/)
- 相关条目：[chronic-07](book/14-chronic.md#chronic-07)

## 心力衰竭：日常自我管理

- 发布机构：国家脑心血管研究中心
- 原始资料：[心力衰竭：日常自我管理](https://www.ncvc.go.jp/hospital/pub/knowledge/disease/heart-failure/)
- 相关条目：[chronic-08](book/14-chronic.md#chronic-08)

## 哮喘和慢性阻塞性肺病视频集

- 发布机构：环境恢复和保护组织
- 原始资料：[哮喘和慢性阻塞性肺病视频集](https://www.erca.go.jp/yobou/zensoku/sukoyaka/movie/)
- 相关条目：[chronic-09](book/14-chronic.md#chronic-09)

## 发作时：哮喘行动计划

- 发布机构：环境恢复和保护组织
- 原始资料：[发作时：哮喘行动计划](https://www.erca.go.jp/yobou/zensoku/basic/adult/control/attack.html)
- 相关条目：[chronic-10](book/14-chronic.md#chronic-10)

## 处理容易导致呼吸短促的动作

- 发布机构：环境恢复和保护组织
- 原始资料：[处理容易导致呼吸短促的动作](https://www.erca.go.jp/yobou/zensoku/copd/life/06.html)
- 相关条目：[chronic-11](book/14-chronic.md#chronic-11)

## 癌症与工作：思考你的工作方式

- 发布机构：国家癌症中心
- 原始资料：[癌症与工作：思考你的工作方式](https://ganjoho.jp/public/support/work_care/index.html)
- 相关条目：[chronic-12](book/14-chronic.md#chronic-12)

## 慢性疼痛治疗指南

- 发布机构：厚生劳动省出版材料/慢性疼痛治疗指南创建工作组
- 原始资料：[慢性疼痛治疗指南](https://www.mhlw.go.jp/content/000350363.pdf)
- 相关条目：[chronic-13](book/14-chronic.md#chronic-13)

## 癫痫症

- 发布机构：国家精神病学和神经病学中心
- 原始资料：[癫痫症](https://kokoro.ncnp.go.jp/disease.php?%40uid=7tp2bnu63ESgWu5I)
- 相关条目：[chronic-14](book/14-chronic.md#chronic-14)

## 患有癫痫症

- 发布机构：国家精神病学和神经病学中心
- 原始资料：[患有癫痫症](https://www.ncnp.go.jp/press_search/images/movie_pdf/movie_pdf_JjpVMr23QBQ45nKn_1.pdf)
- 相关条目：[chronic-14](book/14-chronic.md#chronic-14)

## 食物过敏：紧急应对

- 发布机构：国家儿童健康与发展中心
- 原始资料：[食物过敏：紧急应对](https://www.ncchd.go.jp/hospital/sickness/children/allergy/food_allergy.html)
- 相关条目：[chronic-15](book/14-chronic.md#chronic-15)

## 家庭/食物过敏应急响应指南

- 发布机构：东京都保健所
- 原始资料：[家庭/食物过敏应急响应指南](https://www.hokeniryo1.metro.tokyo.lg.jp/allergy/measure/support_home.html)
- 相关条目：[chronic-15](book/14-chronic.md#chronic-15)

## 关于家庭氧疗期间火灾的处理

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于家庭氧疗期间火灾的处理](https://www.mhlw.go.jp/web/t_doc?dataId=00tb6164&dataType=1&pageNo=1)
- 相关条目：[chronic-16](book/14-chronic.md#chronic-16)

## 关于残疾证

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于残疾证](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/techou.html)
- 相关条目：[accessibility-01](book/15-accessibility.md#accessibility-01)

## 关于残障人士的咨询支援

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于残障人士的咨询支援](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/service/soudan_shien.html)
- 相关条目：[accessibility-02](book/15-accessibility.md#accessibility-02)

## 残疾人福利服务内容

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[残疾人福利服务内容](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/service/naiyou.html)
- 相关条目：[accessibility-03](book/15-accessibility.md#accessibility-03)、[accessibility-04](book/15-accessibility.md#accessibility-04)、[accessibility-08](book/15-accessibility.md#accessibility-08)、[accessibility-09](book/15-accessibility.md#accessibility-09)、[accessibility-10](book/15-accessibility.md#accessibility-10)

## 残疾用户负担

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[残疾用户负担](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/service/hutan1.html)
- 相关条目：[accessibility-03](book/15-accessibility.md#accessibility-03)、[accessibility-04](book/15-accessibility.md#accessibility-04)、[accessibility-06](book/15-accessibility.md#accessibility-06)、[accessibility-07](book/15-accessibility.md#accessibility-07)、[accessibility-08](book/15-accessibility.md#accessibility-08)、[accessibility-09](book/15-accessibility.md#accessibility-09)、[accessibility-10](book/15-accessibility.md#accessibility-10)

## 关于就业选择支持

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于就业选择支持](https://www.mhlw.go.jp/stf/newpage_56733.html)
- 相关条目：[accessibility-05](book/15-accessibility.md#accessibility-05)

## 残疾人就业支持措施现状

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[残疾人就业支持措施现状](https://www.mhlw.go.jp/stf/newpage_40524.html)
- 相关条目：[accessibility-06](book/15-accessibility.md#accessibility-06)、[accessibility-07](book/15-accessibility.md#accessibility-07)

## 独立支援医疗制度概要

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[独立支援医疗制度概要](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/jiritsu/gaiyo.html)
- 相关条目：[accessibility-11](book/15-accessibility.md#accessibility-11)

## 辅助器具费用支付系统概述

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[辅助器具费用支付系统概述](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/yogu/hosouguhisikyuuseido.html)
- 相关条目：[accessibility-12](book/15-accessibility.md#accessibility-12)

## 日常生活装备效益项目概况等

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[日常生活装备效益项目概况等](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/shougaishahukushi/yogu/seikatsu.html)
- 相关条目：[accessibility-13](book/15-accessibility.md#accessibility-13)

## 收集合理便利具体实例的数据等

- 发布机构：日本内阁府（内閣府）
- 原始资料：[收集合理便利具体实例的数据等](https://www8.cao.go.jp/shougai/suishin/jirei/)
- 相关条目：[accessibility-14](book/15-accessibility.md#accessibility-14)

## 通讯支持

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[通讯支持](https://www.mhlw.go.jp/bunya/shougaihoken/sanka/shien.html)
- 相关条目：[accessibility-15](book/15-accessibility.md#accessibility-15)

## 避难行动需要支援的人员名单/个人避难计划

- 发布机构：日本内阁府（内閣府）
- 原始资料：[避难行动需要支援的人员名单/个人避难计划](https://www.bousai.go.jp/taisaku/hisaisyagyousei/yoshiensha.html)
- 相关条目：[accessibility-16](book/15-accessibility.md#accessibility-16)

## 什么是中暑特别预警信息？

- 发布机构：日本环境省（環境省）
- 原始资料：[什么是中暑特别预警信息？](https://www.wbgt.env.go.jp/about_special_alert.php)
- 相关条目：[climate-01](book/16-climate.md#climate-01)、[climate-04](book/16-climate.md#climate-04)

## 关于热指数

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于热指数](https://neccyusho.mhlw.go.jp/heat_index/)
- 相关条目：[climate-01](book/16-climate.md#climate-01)、[climate-08](book/16-climate.md#climate-08)

## 避免中暑的预防措施

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[避免中暑的预防措施](https://www.mhlw.go.jp/seisakunitsuite/bunya/kenkou_iryou/kenkou/nettyuu/nettyuu_taisaku/prevent.html)
- 相关条目：[climate-02](book/16-climate.md#climate-02)、[climate-03](book/16-climate.md#climate-03)、[climate-07](book/16-climate.md#climate-07)

## 老年人防暑

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[老年人防暑](https://www.mhlw.go.jp/seisakunitsuite/bunya/kenkou_iryou/kenkou/nettyuu/nettyuu_taisaku/pdf/heatillness_leaflet_senior_2022.pdf)
- 相关条目：[climate-02](book/16-climate.md#climate-02)、[climate-03](book/16-climate.md#climate-03)、[climate-05](book/16-climate.md#climate-05)

## 让我们大家互相监督，防止孩子中暑。

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[让我们大家互相监督，防止孩子中暑。](https://www.cfa.go.jp/policies/child-safety-actions/cases/netchusho)
- 相关条目：[climate-06](book/16-climate.md#climate-06)

## 我们大家一起来预防吧！中暑

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[我们大家一起来预防吧！中暑](https://www.mhlw.go.jp/seisakunitsuite/bunya/kenkou_iryou/kenkou/nettyuu/nettyuu_taisaku/pdf/necchusho_syokuba.pdf)
- 相关条目：[climate-08](book/16-climate.md#climate-08)

## 中暑环境健康手册：中暑预防

- 发布机构：日本环境省（環境省）
- 原始资料：[中暑环境健康手册：中暑预防](https://www.wbgt.env.go.jp/pdf/manual/heatillness_manual_ov_03.pdf)
- 相关条目：[climate-09](book/16-climate.md#climate-09)

## 不能使用空调时的中暑对策

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[不能使用空调时的中暑对策](https://www.mhlw.go.jp/seisakunitsuite/bunya/kenkou_iryou/kenkou/nettyuu/nettyuu_taisaku/pdf/aircon.pdf)
- 相关条目：[climate-10](book/16-climate.md#climate-10)

## 关于大雪的信息

- 发布机构：日本气象厅
- 原始资料：[关于大雪的信息](https://www.jma.go.jp/jma/kishou/know/snow/snow.html)
- 相关条目：[climate-11](book/16-climate.md#climate-11)

## 除雪的10条安全规则

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[除雪的10条安全规则](https://www.mlit.go.jp/kokudoseisaku/chisei/kokudoseisaku_chisei_tk_000139.html)
- 相关条目：[climate-12](book/16-climate.md#climate-12)

## 参加除雪志愿工作注意事项

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[参加除雪志愿工作注意事项](https://www.mlit.go.jp/kokudoseisaku/chisei/kokudoseisaku_chisei_fr_000016.html)
- 相关条目：[climate-12](book/16-climate.md#climate-12)

## 险情：在结冰的道路上摔倒

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[险情：在结冰的道路上摔倒](https://anzeninfo.mhlw.go.jp/hiyari/hiy_0380.html)
- 相关条目：[climate-13](book/16-climate.md#climate-13)

## 与炉灶保持合理的距离很重要。

- 发布机构：国家技术与评估研究所 (NITE)
- 原始资料：[与炉灶保持合理的距离很重要。](https://www.nite.go.jp/jiko/chuikanki/press/2025fy/prs251030.html)
- 相关条目：[climate-14](book/16-climate.md#climate-14)

## 安全、正确使用热水袋

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[安全、正确使用热水袋](https://www.caa.go.jp/policies/policy/consumer_safety/caution/caution_045)
- 相关条目：[climate-15](book/16-climate.md#climate-15)

## 夏季和冬季舒适的家：家居装修指南

- 发布机构：国土交通省/高龄者住宅协会发行
- 原始资料：[夏季和冬季舒适的家：家居装修指南](https://www.satsuki-jutaku.mlit.go.jp/journal/article/p%3D780)
- 相关条目：[climate-16](book/16-climate.md#climate-16)

## 资产形成的基础知识

- 发布机构：日本金融厅（金融庁）
- 原始资料：[资产形成的基础知识](https://www.fsa.go.jp/policy/nisa2/invest/index.html)
- 相关条目：[money-01](book/17-money.md#money-01)、[money-04](book/17-money.md#money-04)、[money-07](book/17-money.md#money-07)

## 人生 100 年时代：开始做好财务准备

- 发布机构：财经教育推进机构 J-FLEC
- 原始资料：[人生 100 年时代：开始做好财务准备](https://www.j-flec.go.jp/materials/money-for-life/)
- 相关条目：[money-02](book/17-money.md#money-02)、[money-16](book/17-money.md#money-16)

## 系列教材 货币基础

- 发布机构：财经教育推进机构 J-FLEC
- 原始资料：[系列教材 货币基础](https://www.j-flec.go.jp/materials/series-okane-kihon/)
- 相关条目：[money-03](book/17-money.md#money-03)、[money-08](book/17-money.md#money-08)、[money-10](book/17-money.md#money-10)、[money-11](book/17-money.md#money-11)、[money-14](book/17-money.md#money-14)、[money-15](book/17-money.md#money-15)、[debt-02](book/25-debt.md#debt-02)、[banking-01](book/26-banking.md#banking-01)

## 了解 NISA

- 发布机构：日本金融厅（金融庁）
- 原始资料：[了解 NISA](https://www.fsa.go.jp/policy/nisa2/know/index.html)
- 相关条目：[money-04](book/17-money.md#money-04)

## 第一个金钱计划

- 发布机构：财经教育推进机构 J-FLEC
- 原始资料：[第一个金钱计划](https://www.j-flec.go.jp/feature/consult/)
- 相关条目：[money-05](book/17-money.md#money-05)

## 多重债务等的咨询

- 发布机构：日本金融厅（金融庁）
- 原始资料：[多重债务等的咨询](https://www.fsa.go.jp/receipt/soudansitu/advice04.html)
- 相关条目：[money-06](book/17-money.md#money-06)

## No.1120 何时支付医疗费（医疗费扣除）

- 发布机构：日本国税厅（国税庁）
- 原始资料：[No.1120 何时支付医疗费（医疗费扣除）](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1120.htm)
- 相关条目：[tax-01](book/18-tax.md#tax-01)

## 第1155号 故乡税（捐赠扣除）

- 发布机构：日本国税厅（国税庁）
- 原始资料：[第1155号 故乡税（捐赠扣除）](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1155.htm)
- 相关条目：[tax-02](book/18-tax.md#tax-02)

## No.2030 退款声明

- 发布机构：日本国税厅（国税庁）
- 原始资料：[No.2030 退款声明](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2030.htm)
- 相关条目：[tax-03](book/18-tax.md#tax-03)

## No.1900 需要提交年度纳税申报的工薪族

- 发布机构：日本国税厅（国税庁）
- 原始资料：[No.1900 需要提交年度纳税申报的工薪族](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1900.htm)
- 相关条目：[tax-04](book/18-tax.md#tax-04)

## 关于市税/县民税的申报

- 发布机构：横滨市
- 原始资料：[关于市税/县民税的申报](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/zeikin/y-shizei/kojin-shiminzei-kenminzei/kojin-shiminzei-shosai/shiminzei-shinkoku.html)
- 相关条目：[tax-04](book/18-tax.md#tax-04)

## 第1130号 社会保险费扣除

- 发布机构：日本国税厅（国税庁）
- 原始资料：[第1130号 社会保险费扣除](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1130.htm)
- 相关条目：[tax-05](book/18-tax.md#tax-05)

## 通过链接到 Mynaportal 自动输入

- 发布机构：日本国税厅（国税庁）
- 原始资料：[通过链接到 Mynaportal 自动输入](https://www.nta.go.jp/taxes/shiraberu/shinkoku/tokushu/mynaportal-jidou/)
- 相关条目：[tax-06](book/18-tax.md#tax-06)

## 通过Nenkin Net查看您自己的养老金记录

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[通过Nenkin Net查看您自己的养老金记录](https://www.nenkin.go.jp/denshibenri_kojin/n_net/introduction/confirmation.html)
- 相关条目：[pension-01](book/19-pension.md#pension-01)

## 国民年金保险费减免制度/缓缴制度

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[国民年金保险费减免制度/缓缴制度](https://www.nenkin.go.jp/service/kokunen/menjo/20150428.html)
- 相关条目：[pension-02](book/19-pension.md#pension-02)

## 关于学生特殊支付系统的信息

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[关于学生特殊支付系统的信息](https://www.nenkin.go.jp/tokusetsu/gakusei.html)
- 相关条目：[pension-03](book/19-pension.md#pension-03)

## 国民养老保险费滞纳制度

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[国民养老保险费滞纳制度](https://www.nenkin.go.jp/service/kokunen/menjo/20150331.html)
- 相关条目：[pension-04](book/19-pension.md#pension-04)

## 可选继续

- 发布机构：国民健康保险协会
- 原始资料：[可选继续](https://www.kyoukaikenpo.or.jp/benefit/voluntary_continuation/index.html)
- 相关条目：[pension-05](book/19-pension.md#pension-05)

## 伤害和疾病津贴

- 发布机构：国民健康保险协会
- 原始资料：[伤害和疾病津贴](https://www.kyoukaikenpo.or.jp/benefit/injury_and_sickness_allowance/)
- 相关条目：[pension-06](book/19-pension.md#pension-06)

## 关于医疗证明及各种证明（伤病津贴费用医生意见书示例）

- 发布机构：国立医院机构久里滨医疗中心
- 原始资料：[关于医疗证明及各种证明（伤病津贴费用医生意见书示例）](https://kurihama.hosp.go.jp/hospital/outpatient/certificate.html)
- 相关条目：[pension-06](book/19-pension.md#pension-06)

## 劳动合同

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[劳动合同](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/keiyaku/index.html)
- 相关条目：[work-01](book/20-work.md#work-01)、[work-10](book/20-work.md#work-10)

## 明确工作条件的规则

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[明确工作条件的规则](https://www.mhlw.go.jp/stf/newpage_32105.html)
- 相关条目：[work-01](book/20-work.md#work-01)

## 工资和工作时间措施

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[工资和工作时间措施](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/chingin/chingin-a.html)
- 相关条目：[work-02](book/20-work.md#work-02)

## 综合劳动咨询角信息

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[综合劳动咨询角信息](https://www.mhlw.go.jp/general/seido/chihou/kaiketu/soudan.html)
- 相关条目：[work-02](book/20-work.md#work-02)、[work-05](book/20-work.md#work-05)、[work-06](book/20-work.md#work-06)

## 带薪年假是什么样的制度？

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[带薪年假是什么样的制度？](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/faq/kijyunhou_6_00001.html)
- 相关条目：[work-03](book/20-work.md#work-03)

## 如何检查您的工资是否高于最低工资标准

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[如何检查您的工资是否高于最低工资标准](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/chingin/newpage_43899.html)
- 相关条目：[work-04](book/20-work.md#work-04)

## 担心骚扰的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[担心骚扰的人](https://www.no-harassment.mhlw.go.jp/target/worry/)
- 相关条目：[work-06](book/20-work.md#work-06)

## 全体职工问答（基本津贴、再就业津贴）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[全体职工问答（基本津贴、再就业津贴）](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000139508.html)
- 相关条目：[unemployment-01](book/21-unemployment.md#unemployment-01)、[unemployment-07](book/21-unemployment.md#unemployment-07)、[unemployment-09](book/21-unemployment.md#unemployment-09)

## 常见问题（有关就业保险）

- 发布机构：厚生劳动省/Hello Work
- 原始资料：[常见问题（有关就业保险）](https://www.hellowork.mhlw.go.jp/help/question05.html)
- 相关条目：[unemployment-02](book/21-unemployment.md#unemployment-02)

## 住房保障金申请/咨询窗口

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[住房保障金申请/咨询窗口](https://corona-support.mhlw.go.jp/jukyokakuhokyufukin/counter.html)
- 相关条目：[unemployment-03](book/21-unemployment.md#unemployment-03)

## 贫困人口自立支援体系

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[贫困人口自立支援体系](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000059425.html)
- 相关条目：[unemployment-03](book/21-unemployment.md#unemployment-03)、[unemployment-04](book/21-unemployment.md#unemployment-04)、[unemployment-11](book/21-unemployment.md#unemployment-11)、[unemployment-12](book/21-unemployment.md#unemployment-12)

## 对于那些想要申请福利的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[对于那些想要申请福利的人](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/seikatsuhogopage.html)
- 相关条目：[unemployment-05](book/21-unemployment.md#unemployment-05)

## 关于国民健康保险费和保险税

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于国民健康保险费和保险税](https://www.mhlw.go.jp/stf/newpage_21517.html)
- 相关条目：[unemployment-06](book/21-unemployment.md#unemployment-06)

## 教育和培训福利

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[教育和培训福利](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/kyouiku.html)
- 相关条目：[learning-01](book/22-learning.md#learning-01)

## 光环训练

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[光环训练](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/hellotraining_top.html)
- 相关条目：[learning-02](book/22-learning.md#learning-02)

## 求职支援系统信息

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[求职支援系统信息](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/kyushokusha_shien/index.html)
- 相关条目：[learning-02](book/22-learning.md#learning-02)、[unemployment-10](book/21-unemployment.md#unemployment-10)

## 如何使用职位标签

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[如何使用职位标签](https://shigoto.mhlw.go.jp/user/howto)
- 相关条目：[learning-03](book/22-learning.md#learning-03)、[learning-14](book/22-learning.md#learning-14)

## 了解您的工作卡

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[了解您的工作卡](https://www.job-card.mhlw.go.jp/guidance/know)
- 相关条目：[learning-04](book/22-learning.md#learning-04)

## 为个人提供免费职业咨询

- 发布机构：厚生劳动省委托项目
- 原始资料：[为个人提供免费职业咨询](https://carigaku.mhlw.go.jp/icc/)
- 相关条目：[learning-05](book/22-learning.md#learning-05)

## 马纳帕斯 查找课程

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[马纳帕斯 查找课程](https://manapass.mext.go.jp/portal/course/search/)
- 相关条目：[learning-06](book/22-learning.md#learning-06)

## 消费者热线

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[消费者热线](https://www.caa.go.jp/policies/policy/local_cooperation/local_consumer_administration/hotline/)
- 相关条目：[consumer-01](book/23-consumer.md#consumer-01)

## 冷却下来

- 发布机构：国家消费者事务中心
- 原始资料：[冷却下来](https://www.kokusen.go.jp/soudan_now/data/coolingoff.html)
- 相关条目：[consumer-02](book/23-consumer.md#consumer-02)、[consumer-07](book/23-consumer.md#consumer-07)

## 保存网上购物的最终确认屏幕

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[保存网上购物的最终确认屏幕](https://www.caa.go.jp/policies/policy/consumer_transaction/amendment/2021/notice04/index.html)
- 相关条目：[consumer-03](book/23-consumer.md#consumer-03)

## 仅删除订阅应用程序并不会取消订阅。

- 发布机构：国家消费者事务中心
- 原始资料：[仅删除订阅应用程序并不会取消订阅。](https://www.kokusen.go.jp/mimamori/mj_mailmag/mj-shinsen545.html)
- 相关条目：[consumer-04](book/23-consumer.md#consumer-04)

## 上门销售及维修供水相关问题

- 发布机构：国家消费者事务中心
- 原始资料：[上门销售及维修供水相关问题](https://www.kokusen.go.jp/t_box/data/t_box-faq_qa2012_52.html)
- 相关条目：[consumer-05](book/23-consumer.md#consumer-05)

## 跨境消费中心（CCJ）

- 发布机构：国家消费者事务中心
- 原始资料：[跨境消费中心（CCJ）](https://www.ccj.kokusen.go.jp/)
- 相关条目：[consumer-06](book/23-consumer.md#consumer-06)

## 10大信息安全威胁手册个人版

- 发布机构：信息技术振兴机构IPA
- 原始资料：[10大信息安全威胁手册个人版](https://www.ipa.go.jp/security/10threats/eid2eo0000005231-att/kaisetsu_2025_kojin.pdf)
- 相关条目：[digital-01](book/24-digital.md#digital-01)

## 未授权登录对策专题页面

- 发布机构：信息技术振兴机构IPA
- 原始资料：[未授权登录对策专题页面](https://www.ipa.go.jp/security/anshin/measures/account_security.html)
- 相关条目：[digital-02](book/24-digital.md#digital-02)

## 访问 URL 链接时要小心

- 发布机构：信息技术振兴机构IPA
- 原始资料：[访问 URL 链接时要小心](https://www.ipa.go.jp/security/anshin/attention/2021/mgdayori20210831.html)
- 相关条目：[digital-03](book/24-digital.md#digital-03)

## 使用最新版本提高您的体力：将您的操作系统和应用程序更新到最新版本

- 发布机构：信息技术振兴机构IPA
- 原始资料：[使用最新版本提高您的体力：将您的操作系统和应用程序更新到最新版本](https://www.ipa.go.jp/security/love_smartphone_life/mini_book/power.html)
- 相关条目：[digital-04](book/24-digital.md#digital-04)

## 关于终止对 Windows 10 的支持的警报

- 发布机构：信息技术振兴机构IPA
- 原始资料：[关于终止对 Windows 10 的支持的警报](https://www.ipa.go.jp/security/security-alert/2024/win10_eos.html)
- 相关条目：[digital-04](book/24-digital.md#digital-04)、[digital-10](book/24-digital.md#digital-10)

## 日常生活中的信息安全措施

- 发布机构：信息技术振兴机构IPA
- 原始资料：[日常生活中的信息安全措施](https://www.ipa.go.jp/security/anshin/measures/everyday.html)
- 相关条目：[digital-05](book/24-digital.md#digital-05)、[digital-07](book/24-digital.md#digital-07)、[digital-08](book/24-digital.md#digital-08)、[digital-12](book/24-digital.md#digital-12)、[digital-14](book/24-digital.md#digital-14)

## 勒索软件威胁及对策（备份时的注意事项）

- 发布机构：信息技术振兴机构IPA
- 原始资料：[勒索软件威胁及对策（备份时的注意事项）](https://www.ipa.go.jp/security/anshin/measures/ug65p9000000njuc-att/000057314.pdf)
- 相关条目：[digital-05](book/24-digital.md#digital-05)

## 9 网络安全措施

- 发布机构：信息技术振兴机构IPA
- 原始资料：[9 网络安全措施](https://www.ipa.go.jp/security/contest/2026-boshu/theme.html)
- 相关条目：[digital-06](book/24-digital.md#digital-06)

## 对于投资者

- 发布机构：证券交易监督委员会
- 原始资料：[对于投资者](https://www.fsa.go.jp/sesc/support/advice.html)
- 相关条目：[money-09](book/17-money.md#money-09)

## iDeCo的特点

- 发布机构：国民年金基金联合会
- 原始资料：[iDeCo的特点](https://www.ideco-koushiki.jp/guide/)
- 相关条目：[money-12](book/17-money.md#money-12)

## 学习金融的材料

- 发布机构：财经教育促进机构
- 原始资料：[学习金融的材料](https://www.j-flec.go.jp/materials/)
- 相关条目：[money-13](book/17-money.md#money-13)

## 对于那些接受住房贷款扣除的人

- 发布机构：日本国税厅（国税庁）
- 原始资料：[对于那些接受住房贷款扣除的人](https://www.nta.go.jp/taxes/shiraberu/shinkoku/tokushu/keisubetsu/juutaku.htm)
- 相关条目：[tax-07](book/18-tax.md#tax-07)

## 因灾害、盗窃等导致财产受损时

- 发布机构：日本国税厅（国税庁）
- 原始资料：[因灾害、盗窃等导致财产受损时](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1110.htm)
- 相关条目：[tax-08](book/18-tax.md#tax-08)

## 家属扣除

- 发布机构：日本国税厅（国税庁）
- 原始资料：[家属扣除](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1180.htm)
- 相关条目：[tax-09](book/18-tax.md#tax-09)

## 配偶扣除

- 发布机构：日本国税厅（国税庁）
- 原始资料：[配偶扣除](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1191.htm)
- 相关条目：[tax-10](book/18-tax.md#tax-10)

## 伤残扣除

- 发布机构：日本国税厅（国税庁）
- 原始资料：[伤残扣除](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1160.htm)
- 相关条目：[tax-11](book/18-tax.md#tax-11)

## 单亲扣除

- 发布机构：日本国税厅（国税庁）
- 原始资料：[单亲扣除](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1171.htm)
- 相关条目：[tax-12](book/18-tax.md#tax-12)

## 人寿保险保费扣除

- 发布机构：日本国税厅（国税庁）
- 原始资料：[人寿保险保费扣除](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1140.htm)
- 相关条目：[tax-13](book/18-tax.md#tax-13)

## 预计纳税额

- 发布机构：日本国税厅（国税庁）
- 原始资料：[预计纳税额](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2040.htm)
- 相关条目：[tax-14](book/18-tax.md#tax-14)

## 对于那些在截止日期前付款有困难的人

- 发布机构：日本国税厅（国税庁）
- 原始资料：[对于那些在截止日期前付款有困难的人](https://www.nta.go.jp/taxes/nozei/nofu_konnan.htm)
- 相关条目：[tax-15](book/18-tax.md#tax-15)

## 当您的纳税申报表出现错误时

- 发布机构：日本国税厅（国税庁）
- 原始资料：[当您的纳税申报表出现错误时](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2026.htm)
- 相关条目：[tax-16](book/18-tax.md#tax-16)

## 就业/换工作/离职

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[就业/换工作/离职](https://www.nenkin.go.jp/service/scenebetsu/shushoku.html)
- 相关条目：[pension-07](book/19-pension.md#pension-07)

## 什么是扩大社会保险覆盖面？

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[什么是扩大社会保险覆盖面？](https://www.mhlw.go.jp/tekiyoukakudai/seido/)
- 相关条目：[pension-08](book/19-pension.md#pension-08)

## 生育前后国民养老保险费减免制度

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[生育前后国民养老保险费减免制度](https://www.nenkin.go.jp/service/kokunen/menjo/20180810.html)
- 相关条目：[pension-09](book/19-pension.md#pension-09)

## 育儿假期间的福利年金保险费怎么办？

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[育儿假期间的福利年金保险费怎么办？](https://www.nenkin.go.jp/section/faq/kounen/hokenryo/20140912.html)
- 相关条目：[pension-10](book/19-pension.md#pension-10)

## 伤残抚恤金

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[伤残抚恤金](https://www.nenkin.go.jp/service/jukyu/seido/shougainenkin/jukyu-yoken/20150401-01.html)
- 相关条目：[pension-11](book/19-pension.md#pension-11)

## 领取养老金的人/领取养老金的人

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[领取养老金的人/领取养老金的人](https://www.nenkin.go.jp/service/riyoushabetsu/jukyu/)
- 相关条目：[pension-12](book/19-pension.md#pension-12)、[pension-13](book/19-pension.md#pension-13)

## Nenkin网概述

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[Nenkin网概述](https://www.nenkin.go.jp/denshibenri_kojin/n_net/introduction/summary.html)
- 相关条目：[pension-14](book/19-pension.md#pension-14)

## 推迟领取养老金

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[推迟领取养老金](https://www.nenkin.go.jp/service/jukyu/seido/roureinenkin/kuriage-kurisage/20140421-02.html)
- 相关条目：[pension-15](book/19-pension.md#pension-15)

## 转入/转出海外

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[转入/转出海外](https://www.nenkin.go.jp/service/scenebetsu/kaigai.html)
- 相关条目：[pension-16](book/19-pension.md#pension-16)

## 所有工人都应遵守的规则

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[所有工人都应遵守的规则](https://www.mhlw.go.jp/content/001707662.pdf)
- 相关条目：[work-07](book/20-work.md#work-07)

## 劳工标准法

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[劳工标准法](https://www.mhlw.go.jp/web/t_doc?dataId=73022000&dataType=0)
- 相关条目：[work-08](book/20-work.md#work-08)

## 工作时间/节假日

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[工作时间/节假日](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/roudouzikan/index.html)
- 相关条目：[work-09](book/20-work.md#work-09)

## 育儿及护理休假法概要

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[育儿及护理休假法概要](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/000103504.html)
- 相关条目：[work-11](book/20-work.md#work-11)

## 护理假（介護休暇）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[护理假（介護休暇）](https://www.mhlw.go.jp/seisakunitsuite/bunya/koyou_roudou/koyoukintou/ryouritsu/kaigo/shorttime-leave/)
- 相关条目：[work-12](book/20-work.md#work-12)

## 发生劳动事故时

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[发生劳动事故时](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/zigyonushi/rousai/index.html)
- 相关条目：[work-13](book/20-work.md#work-13)

## 引入远程办公时的劳动合同和工作规则

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[引入远程办公时的劳动合同和工作规则](https://telework.mhlw.go.jp/info/qa/002/)
- 相关条目：[work-14](book/20-work.md#work-14)

## 副业/副业

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[副业/副业](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000192188.html)
- 相关条目：[work-15](book/20-work.md#work-15)

## 职场信息综合网站食原房

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[职场信息综合网站食原房](https://shokuba.mhlw.go.jp/)
- 相关条目：[work-16](book/20-work.md#work-16)

## 离职后创业就业保险领取期限的特别规定

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[离职后创业就业保险领取期限的特别规定](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/newpage_26400.html)
- 相关条目：[unemployment-08](book/21-unemployment.md#unemployment-08)

## 常见问题/对于正在找工作的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[常见问题/对于正在找工作的人](https://www.hellowork.mhlw.go.jp/help/question02.html)
- 相关条目：[unemployment-13](book/21-unemployment.md#unemployment-13)

## 为求职者提供的服务信息

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[为求职者提供的服务信息](https://www.hellowork.mhlw.go.jp/member/mem_top.html)
- 相关条目：[unemployment-14](book/21-unemployment.md#unemployment-14)

## 如果您在缴税方面遇到困难，

- 发布机构：横滨市
- 原始资料：[如果您在缴税方面遇到困难，](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/zeikin/nouzei-soudan/nouzei-okomari/konnnann.html)
- 相关条目：[unemployment-15](book/21-unemployment.md#unemployment-15)

## 福利制度

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[福利制度](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/seikatuhogo/index.html)
- 相关条目：[unemployment-16](book/21-unemployment.md#unemployment-16)

## 与取得资格、提高技能和再学习相关的计划和措施

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[与取得资格、提高技能和再学习相关的计划和措施](https://www.mext.go.jp/a_menu/ikusei/manabinaoshi/1384494.htm)
- 相关条目：[learning-07](book/22-learning.md#learning-07)

## 在放送大学，从选修 1 门课程开始成为大学生。

- 发布机构：开放大学
- 原始资料：[在放送大学，从选修 1 门课程开始成为大学生。](https://www.ouj.ac.jp/lp/senior/)
- 相关条目：[learning-08](book/22-learning.md#learning-08)

## 调查/咨询（参考）

- 发布机构：国立国会图书馆
- 原始资料：[调查/咨询（参考）](https://www.ndl.go.jp/help/reference)
- 相关条目：[learning-09](book/22-learning.md#learning-09)

## 职业能力评价标准

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[职业能力评价标准](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/ability_skill/syokunou/index.html)
- 相关条目：[learning-10](book/22-learning.md#learning-10)

## 有关托儿服务的职业培训信息

- 发布机构：大阪劳动局/Hello Work
- 原始资料：[有关托儿服务的职业培训信息](https://jsite.mhlw.go.jp/osaka-hellowork/kyushokusha/hello-training/seido/takuji.html)
- 相关条目：[learning-11](book/22-learning.md#learning-11)

## 你好培训（残疾人培训）

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[你好培训（残疾人培训）](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/jinzaikaihatsu/shougaisha.html)
- 相关条目：[learning-12](book/22-learning.md#learning-12)

## 地方政府返乡支援制度

- 发布机构：日本学生支援机构
- 原始资料：[地方政府返乡支援制度](https://www.jasso.go.jp/shogakukin/chihoshien/sosei/seido/index.html)
- 相关条目：[learning-13](book/22-learning.md#learning-13)

## 著作权教材：令和 8 年度版

- 发布机构：文化厅
- 原始资料：[著作权教材：令和 8 年度版](https://www.bunka.go.jp/seisaku/chosakuken/seidokaisetsu/pdf/94383901_01.pdf)
- 相关条目：[learning-15](book/22-learning.md#learning-15)、[sidework-06](book/29-sidework.md#sidework-06)

## 职业大学/职业专科学校

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[职业大学/职业专科学校](https://www.mext.go.jp/a_menu/koutou/senmon/index.htm)
- 相关条目：[learning-16](book/22-learning.md#learning-16)

## 如何防止上门采购出现问题

- 发布机构：国家消费者事务中心
- 原始资料：[如何防止上门采购出现问题](https://www.kokusen.go.jp/t_box/data/t_box-faq_qa2017_26.html)
- 相关条目：[consumer-08](book/23-consumer.md#consumer-08)

## 您收到了一件您不认识的寄给您的产品。

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[您收到了一件您不认识的寄给您的产品。](https://www.caa.go.jp/policies/policy/consumer_transaction/amendment/2021/notice/index.html)
- 相关条目：[consumer-09](book/23-consumer.md#consumer-09)

## 上门销售

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[上门销售](https://www.no-trouble.caa.go.jp/what/doortodoorsales/index.html)
- 相关条目：[consumer-10](book/23-consumer.md#consumer-10)

## 指定的持续服务提供

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[指定的持续服务提供](https://www.no-trouble.caa.go.jp/what/continuousservices/)
- 相关条目：[consumer-11](book/23-consumer.md#consumer-11)

## 使用数字平台时要注意什么

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[使用数字平台时要注意什么](https://www.caa.go.jp/notice/assets/future_caa_cms201_211001_02.pdf)
- 相关条目：[consumer-12](book/23-consumer.md#consumer-12)

## 召回信息网站/搜索方法

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[召回信息网站/搜索方法](https://www.recall.caa.go.jp/search.html)
- 相关条目：[consumer-13](book/23-consumer.md#consumer-13)

## 我购买了线路合约和智能手机，但信号不稳定。

- 发布机构：国家消费者事务中心
- 原始资料：[我购买了线路合约和智能手机，但信号不稳定。](https://www.faq.kokusen.go.jp/faq/show/1248?site_domain=default)
- 相关条目：[consumer-14](book/23-consumer.md#consumer-14)

## 18岁以上成人 / 特别页面

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[18岁以上成人 / 特别页面](https://www.caa.go.jp/policies/policy/consumer_education/consumer_education/lower_the_age_of_adulthood/introduction/)
- 相关条目：[consumer-15](book/23-consumer.md#consumer-15)

## ADR/替代性争议解决程序简介

- 发布机构：国家消费者事务中心
- 原始资料：[ADR/替代性争议解决程序简介](https://www.kokusen.go.jp/adr/index.html)
- 相关条目：[consumer-16](book/23-consumer.md#consumer-16)

## 互联网连接产品安全选择和使用指南

- 发布机构：信息技术振兴机构
- 原始资料：[互联网连接产品安全选择和使用指南](https://www.ipa.go.jp/security/guide/vuln/forconsumer.html)
- 相关条目：[digital-09](book/24-digital.md#digital-09)、[digital-11](book/24-digital.md#digital-11)

## 支持诈骗举报

- 发布机构：信息技术振兴机构
- 原始资料：[支持诈骗举报](https://www.ipa.go.jp/security/anshin/measures/supportscam_report.html)
- 相关条目：[digital-12](book/24-digital.md#digital-12)

## 不去公众场合

- 发布机构：信息技术振兴机构
- 原始资料：[不去公众场合](https://www.ipa.go.jp/security/otasuketai-pr/list/ko.html)
- 相关条目：[digital-13](book/24-digital.md#digital-13)

## 未经授权登录互联网服务造成的损害正在上升

- 发布机构：信息技术振兴机构
- 原始资料：[未经授权登录互联网服务造成的损害正在上升](https://www.ipa.go.jp/security/anshin/attention/2025/mgdayori20250828.html)
- 相关条目：[digital-15](book/24-digital.md#digital-15)

## 切断网络并保持联系

- 发布机构：信息技术振兴机构
- 原始资料：[切断网络并保持联系](https://www.ipa.go.jp/security/otasuketai-pr/list/ne.html)
- 相关条目：[digital-16](book/24-digital.md#digital-16)

## 多重债务问题问答

- 发布机构：日本法律支援中心
- 原始资料：[多重债务问题问答](https://www.houterasu.or.jp/uploaded/attachment/7496.pdf)
- 相关条目：[debt-01](book/25-debt.md#debt-01)

## 我以为我取消了自动循环付款，但是循环付款仍然没有结束？

- 发布机构：国家消费者事务中心
- 原始资料：[我以为我取消了自动循环付款，但是循环付款仍然没有结束？](https://www.kokusen.go.jp/t_box/data/t_box-faq_qa2017_24.html)
- 相关条目：[debt-03](book/25-debt.md#debt-03)、[banking-11](book/26-banking.md#banking-11)

## 减少每月还款额/减少还款额制度

- 发布机构：日本学生支援机构
- 原始资料：[减少每月还款额/减少还款额制度](https://www.jasso.go.jp/shogakukin/henkan_konnan/gengaku/index.html)
- 相关条目：[debt-04](book/25-debt.md#debt-04)

## 等待退货/推迟退货期限

- 发布机构：日本学生支援机构
- 原始资料：[等待退货/推迟退货期限](https://www.jasso.go.jp/shogakukin/henkan_konnan/yuyo/index.html)
- 相关条目：[debt-05](book/25-debt.md#debt-05)

## 还款等咨询窗口

- 发布机构：住房金融局
- 原始资料：[还款等咨询窗口](https://www.jhf.go.jp/faq/contact/index.html)
- 相关条目：[debt-06](book/25-debt.md#debt-06)

## 免费法律咨询、报销律师费等。

- 发布机构：日本法律支援中心
- 原始资料：[免费法律咨询、报销律师费等。](https://www.houterasu.or.jp/site/soudan-tatekae/index-2.html)
- 相关条目：[debt-07](book/25-debt.md#debt-07)

## 债务/贷款问答

- 发布机构：日本法律支援中心
- 原始资料：[债务/贷款问答](https://www.houterasu.or.jp/site/yasasiinihongo/saimu-kashitsuke.html)
- 相关条目：[debt-08](book/25-debt.md#debt-08)、[debt-11](book/25-debt.md#debt-11)、[debt-15](book/25-debt.md#debt-15)

## 付款提醒

- 发布机构：法庭
- 原始资料：[付款提醒](https://www.courts.go.jp/saiban/syurui/syurui_minzi/minzi_25_22/index.html)
- 相关条目：[debt-09](book/25-debt.md#debt-09)

## 注册放债人信息搜索服务

- 发布机构：日本金融厅（金融庁）
- 原始资料：[注册放债人信息搜索服务](https://www.fsa.go.jp/ordinary/kensaku/index.html)
- 相关条目：[debt-10](book/25-debt.md#debt-10)

## 关于贷款约束制度

- 发布机构：日本金融厅（金融庁）
- 原始资料：[关于贷款约束制度](https://www.fsa.go.jp/policy/kashikin/kasitsukejisyuku.html)
- 相关条目：[debt-12](book/25-debt.md#debt-12)

## 信用和贷款筛选以及信用信息

- 发布机构：日本信用协会
- 原始资料：[信用和贷款筛选以及信用信息](https://www.j-credit.or.jp/customer/qa/qa_17.html)
- 相关条目：[debt-13](book/25-debt.md#debt-13)

## 放弃继承权声明

- 发布机构：法庭
- 原始资料：[放弃继承权声明](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_06_13/index.html)
- 相关条目：[debt-14](book/25-debt.md#debt-14)、[endoflife-04](book/40-endoflife.md#endoflife-04)、[bereavement-15](book/48-bereavement.md#bereavement-15)

## 特别贷款、福利金偿还等咨询窗口

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[特别贷款、福利金偿还等咨询窗口](https://corona-support.mhlw.go.jp/seikatsufukushi/samout/counter.html)
- 相关条目：[debt-16](book/25-debt.md#debt-16)

## 存款保险制度

- 发布机构：日本金融厅（金融庁）
- 原始资料：[存款保险制度](https://www.fsa.go.jp/policy/payoff/index.html)
- 相关条目：[banking-02](book/26-banking.md#banking-02)、[banking-03](book/26-banking.md#banking-03)

## 银行卡丢失或被盗等

- 发布机构：全国银行家协会
- 原始资料：[银行卡丢失或被盗等](https://www.zenginkyo.or.jp/abstract/loss/)
- 相关条目：[banking-04](book/26-banking.md#banking-04)

## 转移撤销/变更程序

- 发布机构：三井住友银行
- 原始资料：[转移撤销/变更程序](https://www.smbc.co.jp/direct/sousa/help_furikomi/36.html)
- 相关条目：[banking-05](book/26-banking.md#banking-05)

## 当你搬家时，一定要去银行。

- 发布机构：全国银行家协会
- 原始资料：[当你搬家时，一定要去银行。](https://www.zenginkyo.or.jp/article/tag-f/7486/)
- 相关条目：[banking-06](book/26-banking.md#banking-06)

## 你了解休眠存款吗？

- 发布机构：全国银行家协会
- 原始资料：[你了解休眠存款吗？](https://www.zenginkyo.or.jp/article/tag-b/10117/)
- 相关条目：[banking-07](book/26-banking.md#banking-07)

## ATM提款卡使用限额

- 发布机构：理索纳银行
- 原始资料：[ATM提款卡使用限额](https://www.resonabank.co.jp/security/service/atm.html)
- 相关条目：[banking-08](book/26-banking.md#banking-08)

## 有关信用的常见问题

- 发布机构：日本信用协会
- 原始资料：[有关信用的常见问题](https://www.j-credit.or.jp/customer/qa/)
- 相关条目：[banking-09](book/26-banking.md#banking-09)、[banking-10](book/26-banking.md#banking-10)

## 电子货币有效期

- 发布机构：国家消费者事务中心
- 原始资料：[电子货币有效期](https://www.kokusen.go.jp/t_box/data/t_box-faq_qa2019_21.html)
- 相关条目：[banking-12](book/26-banking.md#banking-12)

## 礼券和预付卡退款

- 发布机构：日本金融厅（金融庁）
- 原始资料：[礼券和预付卡退款](https://www.fsa.go.jp/policy/prepaid/index.html)
- 相关条目：[banking-13](book/26-banking.md#banking-13)

## Olive 灵活付费使用指南

- 发布机构：三井住友银行
- 原始资料：[Olive 灵活付费使用指南](https://www.smbc.co.jp/kojin/olive-account/regulation/pdf/flexible-pay-manual_251020.pdf?version=250919)
- 相关条目：[banking-14](book/26-banking.md#banking-14)

## 关于突发情况提取存款的思考

- 发布机构：全国银行家协会
- 原始资料：[关于突发情况提取存款的思考](https://www.zenginkyo.or.jp/news/2022/n051602/)
- 相关条目：[banking-15](book/26-banking.md#banking-15)

## 请求对灾害受害者等提供支持和财政措施

- 发布机构：日本金融厅（金融庁）
- 原始资料：[请求对灾害受害者等提供支持和财政措施](https://www.fsa.go.jp/ordinary/hisaisyashien_kinyusochi.html)
- 相关条目：[banking-16](book/26-banking.md#banking-16)

## 公共保险门户网站

- 发布机构：日本金融厅（金融庁）
- 原始资料：[公共保险门户网站](https://www.fsa.go.jp/ordinary/insurance-portal.html)
- 相关条目：[insurance-01](book/27-insurance.md#insurance-01)

## 意外保险合同摘要/警报信息指南

- 发布机构：日本财产保险协会
- 原始资料：[意外保险合同摘要/警报信息指南](https://www.sonpo.or.jp/about/guideline/keiyaku_guideline/ctuevu0000005hpl-att/shogai2024.pdf)
- 相关条目：[insurance-02](book/27-insurance.md#insurance-02)

## 关于更新

- 发布机构：人寿保险文化中心
- 原始资料：[关于更新](https://www.jili.or.jp/knows_learns/basic/change/20.html)
- 相关条目：[insurance-03](book/27-insurance.md#insurance-03)

## 保险产品咨询案例及建议

- 发布机构：日本金融厅（金融庁）
- 原始资料：[保险产品咨询案例及建议](https://www.fsa.go.jp/receipt/soudansitu/advice02.html)
- 相关条目：[insurance-04](book/27-insurance.md#insurance-04)、[insurance-14](book/27-insurance.md#insurance-14)

## 如何检视人寿保险及注意事项

- 发布机构：人寿保险文化中心
- 原始资料：[如何检视人寿保险及注意事项](https://jili.or.jp/tebiki/chapter3.html)
- 相关条目：[insurance-05](book/27-insurance.md#insurance-05)、[insurance-13](book/27-insurance.md#insurance-13)

## 从索赔到获得保险索赔/福利的指导

- 发布机构：人寿保险文化中心
- 原始资料：[从索赔到获得保险索赔/福利的指导](https://jili.or.jp/seikyutebiki/index.html)
- 相关条目：[insurance-06](book/27-insurance.md#insurance-06)

## 变更和通知

- 发布机构：人寿保险文化中心
- 原始资料：[变更和通知](https://www.jili.or.jp/knows_learns/basic/continuance/95.html)
- 相关条目：[insurance-07](book/27-insurance.md#insurance-07)

## 指定代表请求制度是什么样的制度？

- 发布机构：人寿保险文化中心
- 原始资料：[指定代表请求制度是什么样的制度？](https://www.jili.or.jp/knows_learns/q_a/life_insurance/169.html)
- 相关条目：[insurance-08](book/27-insurance.md#insurance-08)

## 非人寿保险，补偿因风、水、雪等造成的损失。

- 发布机构：日本财产保险协会
- 原始资料：[非人寿保险，补偿因风、水、雪等造成的损失。](https://www.sonpo.or.jp/insurance/shizen/index.html)
- 相关条目：[insurance-09](book/27-insurance.md#insurance-09)、[insurance-10](book/27-insurance.md#insurance-10)

## 汽车保险

- 发布机构：日本财产保险协会
- 原始资料：[汽车保险](https://www.sonpo.or.jp/insurance/car/index.html)
- 相关条目：[insurance-11](book/27-insurance.md#insurance-11)

## 个人赔偿责任保险

- 发布机构：日本财产保险协会
- 原始资料：[个人赔偿责任保险](https://www.sonpo.or.jp/insurance/compensation/index.html)
- 相关条目：[insurance-12](book/27-insurance.md#insurance-12)

## 寿险合同信息查询系统

- 发布机构：人寿保险协会
- 原始资料：[寿险合同信息查询系统](https://www.seiho.or.jp/contact/inquiry/)
- 相关条目：[insurance-15](book/27-insurance.md#insurance-15)、[bereavement-12](book/48-bereavement.md#bereavement-12)

## 关于金融机构的问题的咨询·投诉窗口

- 发布机构：日本金融厅（金融庁）
- 原始资料：[关于金融机构的问题的咨询·投诉窗口](https://www.fsa.go.jp/policy/adr/adr_madoguchi.html)
- 相关条目：[insurance-16](book/27-insurance.md#insurance-16)

## 关于完善的服务

- 发布机构：数字代理
- 原始资料：[关于完善的服务](https://app.oss.myna.go.jp/Application/resources/about/index.html)
- 相关条目：[benefits-01](book/28-benefits.md#benefits-01)、[benefits-02](book/28-benefits.md#benefits-02)

## 因家庭财务突变如何申请招聘及福利奖学金

- 发布机构：日本学生支援机构
- 原始资料：[因家庭财务突变如何申请招聘及福利奖学金](https://www.jasso.go.jp/shogakukin/moshikomi/rinji/kakei_kyuhen/moushikomi.html)
- 相关条目：[benefits-02](book/28-benefits.md#benefits-02)

## 发生灾害或家庭财务突然变化时的申请程序

- 发布机构：日本学生支援机构
- 原始资料：[发生灾害或家庭财务突然变化时的申请程序](https://www.jasso.go.jp/shogakukin/moshikomi/rinji/)
- 相关条目：[benefits-03](book/28-benefits.md#benefits-03)

## 教育一般贷款（国家教育贷款）

- 发布机构：日本金融公司
- 原始资料：[教育一般贷款（国家教育贷款）](https://www.jfc.go.jp/n/finance/search/ippan.html)
- 相关条目：[benefits-04](book/28-benefits.md#benefits-04)

## 母子父子寡妇福利资金贷款

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[母子父子寡妇福利资金贷款](https://www.cfa.go.jp/assets/contents/node/basic_page/field_ref_resources/0a870592-1814-4b21-bf56-16f06080c594/0f69b7f8/20260424_policies_hitori-oya_112.pdf)
- 相关条目：[benefits-05](book/28-benefits.md#benefits-05)

## 关于搬迁费、广域求职活动费等

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于搬迁费、广域求职活动费等](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000130693.html)
- 相关条目：[benefits-06](book/28-benefits.md#benefits-06)

## 高等职业培训促进福利信息

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[高等职业培训促进福利信息](https://www.cfa.go.jp/policies/hitori-oya/syokugyou-kunren)
- 相关条目：[benefits-07](book/28-benefits.md#benefits-07)

## 指定难病与医疗费补助咨询

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[指定难病与医疗费补助咨询](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000084783.html)
- 相关条目：[benefits-08](book/28-benefits.md#benefits-08)

## 关于儿童抚养津贴

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[关于儿童抚养津贴](https://www.cfa.go.jp/policies/hitori-oya/fuyou-teate/)
- 相关条目：[benefits-09](book/28-benefits.md#benefits-09)

## 同时领取儿童抚养津贴与公共养老金等时的手续

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[同时领取儿童抚养津贴与公共养老金等时的手续](https://www.cfa.go.jp/assets/contents/node/basic_page/field_ref_resources/71de338f-5ed2-4c95-9848-3fd387d0b4d7/a266fd63/20230401_policies_hitori-oya_fuyou-teate_05.pdf)
- 相关条目：[benefits-09](book/28-benefits.md#benefits-09)

## 关于特殊伤残津贴

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于特殊伤残津贴](https://www.mhlw.go.jp/bunya/shougaihoken/jidou/tokubetsu.html)
- 相关条目：[benefits-10](book/28-benefits.md#benefits-10)

## 养老金领取者支持福利

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[养老金领取者支持福利](https://www.nenkin.go.jp/service/jukyu/seido/sonota-kyufu/shienkyufukin/20190805.html)
- 相关条目：[benefits-11](book/28-benefits.md#benefits-11)

## 国民年金保险费的育儿免除制度

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[国民年金保险费的育儿免除制度](https://www.nenkin.go.jp/service/kokunen/menjo/ikujimenjo.html)
- 相关条目：[benefits-12](book/28-benefits.md#benefits-12)

## 生育津贴

- 发布机构：国民健康保险协会
- 原始资料：[生育津贴](https://www.kyoukaikenpo.or.jp/benefit/childbirth/001/index.html)
- 相关条目：[benefits-13](book/28-benefits.md#benefits-13)

## 关于护理假福利的问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于护理假福利的问答](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000158665.html)
- 相关条目：[benefits-14](book/28-benefits.md#benefits-14)

## 令和 7 年 4 月的制度变更：扩大住房保障补助金

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[令和 7 年 4 月的制度变更：扩大住房保障补助金](https://www.mhlw.go.jp/stf/newpage_51380.html)
- 相关条目：[benefits-15](book/28-benefits.md#benefits-15)

## 灾害受害者生计重建支援法

- 发布机构：日本内阁府（内閣府）
- 原始资料：[灾害受害者生计重建支援法](https://www.bousai.go.jp/taisaku/seikatsusaiken/shiensya.html)
- 相关条目：[benefits-16](book/28-benefits.md#benefits-16)

## 对于那些作为自由职业者等工作的人

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[对于那些作为自由职业者等工作的人](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyoukintou/zaitaku/index_00002.html)
- 相关条目：[sidework-01](book/29-sidework.md#sidework-01)

## 自由法律专业网站

- 发布机构：公平贸易委员会
- 原始资料：[自由法律专业网站](https://www.jftc.go.jp/freelancelaw_2026/index.html)
- 相关条目：[sidework-02](book/29-sidework.md#sidework-02)、[sidework-04](book/29-sidework.md#sidework-04)、[sidework-09](book/29-sidework.md#sidework-09)、[business-04](book/39-business.md#business-04)

## 自雇远程办公合同条件

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[自雇远程办公合同条件](https://homeworkers.mhlw.go.jp/guideline/gl03.html)
- 相关条目：[sidework-03](book/29-sidework.md#sidework-03)

## 可交付成果、交货日期和检验条件

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[可交付成果、交货日期和检验条件](https://homeworkers.mhlw.go.jp/guideline/about02.html)
- 相关条目：[sidework-05](book/29-sidework.md#sidework-05)

## 自由职业者麻烦号码 110

- 发布机构：厚生劳动省/第二东京律师协会
- 原始资料：[自由职业者麻烦号码 110](https://freelance110.mhlw.go.jp/)
- 相关条目：[sidework-07](book/29-sidework.md#sidework-07)

## 澄清经纪费用等

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[澄清经纪费用等](https://homeworkers.mhlw.go.jp/guideline/about03.html)
- 相关条目：[sidework-08](book/29-sidework.md#sidework-08)

## 发票系统概述

- 发布机构：日本国税厅（国税庁）
- 原始资料：[发票系统概述](https://www.nta.go.jp/taxes/shiraberu/zeimokubetsu/shohi/keigenzeiritsu/invoice_about.htm)
- 相关条目：[sidework-10](book/29-sidework.md#sidework-10)

## 电子账本存储系统/电子交易相关的专门网站

- 发布机构：日本国税厅（国税庁）
- 原始资料：[电子账本存储系统/电子交易相关的专门网站](https://www.nta.go.jp/law/joho-zeikaishaku/sonota/jirei/tokusetsu/01.htm)
- 相关条目：[sidework-11](book/29-sidework.md#sidework-11)、[business-12](book/39-business.md#business-12)

## 了解必要的开支

- 发布机构：日本国税厅（国税庁）
- 原始资料：[了解必要的开支](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2210.htm)
- 相关条目：[sidework-12](book/29-sidework.md#sidework-12)

## 特别加入自由职业者赔偿保险

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[特别加入自由职业者赔偿保险](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/rousai/kanyu_r3.4.1_00010.html)
- 相关条目：[sidework-13](book/29-sidework.md#sidework-13)

## 考虑交货日期和工作时间

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[考虑交货日期和工作时间](https://homeworkers.mhlw.go.jp/guideline/gl04.html)
- 相关条目：[sidework-14](book/29-sidework.md#sidework-14)

## 改善自由职业者的工作环境

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[改善自由职业者的工作环境](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/bunya/freelance_00006.html)
- 相关条目：[sidework-15](book/29-sidework.md#sidework-15)、[sidework-16](book/29-sidework.md#sidework-16)

## 有关骚扰的问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[有关骚扰的问答](https://www.no-harassment.mhlw.go.jp/qa/)
- 相关条目：[harassment-01](book/30-harassment.md#harassment-01)、[harassment-02](book/30-harassment.md#harassment-02)

## 意见、各类咨询及信息提供等

- 发布机构：日本警察厅（警察庁）
- 原始资料：[意见、各类咨询及信息提供等](https://www.npa.go.jp/goiken_index.html)
- 相关条目：[harassment-01](book/30-harassment.md#harassment-01)

## 关于工作场所骚扰的咨询台

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于工作场所骚扰的咨询台](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000137888.html)
- 相关条目：[harassment-03](book/30-harassment.md#harassment-03)、[harassment-04](book/30-harassment.md#harassment-04)、[harassment-05](book/30-harassment.md#harassment-05)

## 明亮的职场啦啦队

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[明亮的职场啦啦队](https://www.no-harassment.mhlw.go.jp/)
- 相关条目：[harassment-06](book/30-harassment.md#harassment-06)、[harassment-07](book/30-harassment.md#harassment-07)

## 预防骚扰的基本知识

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[预防骚扰的基本知识](https://www.no-harassment.mhlw.go.jp/assets/pdf/jinji_1_kiso.pdf)
- 相关条目：[harassment-08](book/30-harassment.md#harassment-08)、[harassment-12](book/30-harassment.md#harassment-12)

## 禁止歧视残疾人并有义务提供合理便利

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[禁止歧视残疾人并有义务提供合理便利](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000141747.html)
- 相关条目：[harassment-09](book/30-harassment.md#harassment-09)

## 兼职/定期雇佣劳动法问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[兼职/定期雇佣劳动法问答](https://part-tanjikan.mhlw.go.jp/faq/)
- 相关条目：[harassment-10](book/30-harassment.md#harassment-10)

## 临时工同工同酬

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[临时工同工同酬](https://www.mhlw.go.jp/content/001701328.pdf)
- 相关条目：[harassment-11](book/30-harassment.md#harassment-11)

## 个人劳动争议解决制度

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[个人劳动争议解决制度](https://www.mhlw.go.jp/general/seido/chihou/kaiketu/index.html)
- 相关条目：[harassment-13](book/30-harassment.md#harassment-13)

## 劳工法庭程序

- 发布机构：法庭
- 原始资料：[劳工法庭程序](https://www.courts.go.jp/saiban/syurui/syurui_minzi/minzi_25_21/index.html)
- 相关条目：[harassment-14](book/30-harassment.md#harassment-14)

## 关于工会

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于工会](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudouseisaku/roudoukumiai/index.html)
- 相关条目：[harassment-15](book/30-harassment.md#harassment-15)

## 公益举报人保护制度咨询电话

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[公益举报人保护制度咨询电话](https://www.caa.go.jp/policies/policy/consumer_partnerships/whisleblower_protection_system/contact)
- 相关条目：[harassment-16](book/30-harassment.md#harassment-16)

## 带薪年假与工作基础知识

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[带薪年假与工作基础知识](https://www.check-roudou.mhlw.go.jp/study/roudousya_yukyu.html)
- 相关条目：[retirement-01](book/31-retirement.md#retirement-01)

## 年中入职人员的年终调整

- 发布机构：日本国税厅（国税庁）
- 原始资料：[年中入职人员的年终调整](https://www.nta.go.jp/taxes/shiraberu/taxanswer/gensen/2674.htm)
- 相关条目：[retirement-02](book/31-retirement.md#retirement-02)

## 领取离职金时（退职所得）

- 发布机构：日本国税厅（国税庁）
- 原始资料：[领取离职金时（退职所得）](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/1420.htm)
- 相关条目：[retirement-03](book/31-retirement.md#retirement-03)

## 离职或转职时养老金资产转移

- 发布机构：国民年金基金联合会
- 原始资料：[离职或转职时养老金资产转移](https://www.ideco-koushiki.jp/retirement/)
- 相关条目：[retirement-04](book/31-retirement.md#retirement-04)

## 离职时的证明书

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[离职时的证明书](https://www.check-roudou.mhlw.go.jp/qa/roudousya/kaiko/q9.html)
- 相关条目：[retirement-05](book/31-retirement.md#retirement-05)

## 离职后的个人住民税缴纳

- 发布机构：横滨市
- 原始资料：[离职后的个人住民税缴纳](https://www.city.yokohama.lg.jp/faq/kukyoku/somu/hojin-kazei/20230227132728016.html)
- 相关条目：[retirement-06](book/31-retirement.md#retirement-06)

## 欠薪垫付制度概况与实施情况

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[欠薪垫付制度概况与实施情况](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/faq/faq_miharaichingin.html)
- 相关条目：[retirement-07](book/31-retirement.md#retirement-07)

## 劳动合同终止规则

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[劳动合同终止规则](https://www.mhlw.go.jp/seisakunitsuite/bunya/koyou_roudou/roudouseisaku/chushoukigyou/keiyakushuryo_rule.html)
- 相关条目：[retirement-08](book/31-retirement.md#retirement-08)

## 老年人就业安定法的修订

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[老年人就业安定法的修订](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/jigyounushi/page09_00001.html)
- 相关条目：[retirement-09](book/31-retirement.md#retirement-09)

## Mothers Hello Work 项目

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[Mothers Hello Work 项目](https://www.mhlw.go.jp/stf/newpage_21046.html)
- 相关条目：[retirement-10](book/31-retirement.md#retirement-10)

## 青年 Hello Work

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[青年 Hello Work](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000181329.html)
- 相关条目：[retirement-11](book/31-retirement.md#retirement-11)

## Hello Work 专业窗口

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[Hello Work 专业窗口](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/koyou/hellowork.html)
- 相关条目：[retirement-12](book/31-retirement.md#retirement-12)

## 残障人士相关窗口

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[残障人士相关窗口](https://www.mhlw.go.jp/stf/senmon_19585.html)
- 相关条目：[retirement-13](book/31-retirement.md#retirement-13)

## 高年龄继续雇佣给付问答

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[高年龄继续雇佣给付问答](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000158464.html)
- 相关条目：[retirement-14](book/31-retirement.md#retirement-14)

## 中年与高龄人士专业窗口

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[中年与高龄人士专业窗口](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000181329_00002.html)
- 相关条目：[retirement-15](book/31-retirement.md#retirement-15)

## 就业保险参保手续是否已正确办理

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[就业保险参保手续是否已正确办理](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000147331.html)
- 相关条目：[retirement-16](book/31-retirement.md#retirement-16)

## 警察不会通过社交平台或视频通话联系你

- 发布机构：日本警察厅（警察庁）
- 原始资料：[警察不会通过社交平台或视频通话联系你](https://www.npa.go.jp/bureau/safetylife/sos47/new-topics/241218/06.html)
- 相关条目：[fraud-01](book/32-fraud.md#fraud-01)

## 退款诈骗

- 发布机构：日本警察厅（警察庁）
- 原始资料：[退款诈骗](https://www.npa.go.jp/bureau/safetylife/sos47/case/refund/)
- 相关条目：[fraud-02](book/32-fraud.md#fraud-02)

## 家庭可以采取的防骗措施

- 发布机构：日本警察厅（警察庁）
- 原始资料：[家庭可以采取的防骗措施](https://www.npa.go.jp/bureau/safetylife/sos47/manga/family/)
- 相关条目：[fraud-03](book/32-fraud.md#fraud-03)

## 社交平台投资诈骗

- 发布机构：日本警察厅（警察庁）
- 原始资料：[社交平台投资诈骗](https://www.npa.go.jp/bureau/safetylife/sos47/case/sns-romance/investment/)
- 相关条目：[fraud-04](book/32-fraud.md#fraud-04)

## 社交平台恋爱诈骗

- 发布机构：日本警察厅（警察庁）
- 原始资料：[社交平台恋爱诈骗](https://www.npa.go.jp/bureau/safetylife/sos47/case/sns-romance/romance/)
- 相关条目：[fraud-05](book/32-fraud.md#fraud-05)

## 警惕投资相关诈骗性招揽

- 发布机构：日本金融厅（金融庁）
- 原始资料：[警惕投资相关诈骗性招揽](https://www.fsa.go.jp/ordinary/chuui/attention.html)
- 相关条目：[fraud-06](book/32-fraud.md#fraud-06)

## 致加密资产使用者

- 发布机构：日本金融厅（金融庁）
- 原始资料：[致加密资产使用者](https://www.fsa.go.jp/policy/virtual_currency/index.html)
- 相关条目：[fraud-07](book/32-fraud.md#fraud-07)

## 警惕利用社交平台等进行的个人间借贷

- 发布机构：日本金融厅（金融庁）
- 原始资料：[警惕利用社交平台等进行的个人间借贷](https://www.fsa.go.jp/ordinary/chuui/kinyu_chuui.html)
- 相关条目：[fraud-08](book/32-fraud.md#fraud-08)

## 警惕声称收购工资的非法高利贷

- 发布机构：日本金融厅（金融庁）
- 原始资料：[警惕声称收购工资的非法高利贷](https://www.fsa.go.jp/ordinary/chuui/kinyu_chuui2.html)
- 相关条目：[fraud-09](book/32-fraud.md#fraud-09)

## 警惕预付款回购变现

- 发布机构：日本金融厅（金融庁）
- 原始资料：[警惕预付款回购变现](https://www.fsa.go.jp/ordinary/chuui/cashing_chuui2.html)
- 相关条目：[fraud-10](book/32-fraud.md#fraud-10)

## 招募犯罪执行者的信息（黑暗兼职）

- 发布机构：日本警察厅（警察庁）
- 原始资料：[招募犯罪执行者的信息（黑暗兼职）](https://www.npa.go.jp/bureau/safetylife/yamibaito/hanzaishaboshu.html)
- 相关条目：[fraud-11](book/32-fraud.md#fraud-11)、[fraud-12](book/32-fraud.md#fraud-12)

## 转让存折、银行卡属于犯罪

- 发布机构：日本警察厅（警察庁）
- 原始资料：[转让存折、银行卡属于犯罪](https://www.npa.go.jp/bureau/safetylife/sos47/new-topics/250110/04.html)
- 相关条目：[fraud-12](book/32-fraud.md#fraud-12)

## 警惕为开展副业而借款

- 发布机构：国家消费者事务中心
- 原始资料：[警惕为开展副业而借款](https://www.kokusen.go.jp/news/data/n-20230607_1.html)
- 相关条目：[fraud-13](book/32-fraud.md#fraud-13)

## 对方称通过扫码支付退款时，应怀疑诈骗

- 发布机构：国家消费者事务中心
- 原始资料：[对方称通过扫码支付退款时，应怀疑诈骗](https://www.kokusen.go.jp/news/data/n-20240731_2.html)
- 相关条目：[fraud-14](book/32-fraud.md#fraud-14)

## 关于网络购物虚假网站等的咨询

- 发布机构：国家消费者事务中心
- 原始资料：[关于网络购物虚假网站等的咨询](https://www.kokusen.go.jp/soudan_now/data/online-shopping-scams.html)
- 相关条目：[fraud-15](book/32-fraud.md#fraud-15)

## 致转账诈骗等受害者

- 发布机构：日本金融厅（金融庁）
- 原始资料：[致转账诈骗等受害者](https://www.fsa.go.jp/policy/kyuusai/furikome/index.html)
- 相关条目：[fraud-16](book/32-fraud.md#fraud-16)

## 入住及搬出私人出租房屋须注意的事项

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[入住及搬出私人出租房屋须注意的事项](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_tk3_000016.html)
- 相关条目：[housing-01](book/33-housing.md#housing-01)、[housing-03](book/33-housing.md#housing-03)、[housing-14](book/33-housing.md#housing-14)

## 与恢复原状相关的问题和指南 Q&A

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[与恢复原状相关的问题和指南 Q&A](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_tk3_000024.html)
- 相关条目：[housing-02](book/33-housing.md#housing-02)、[housing-03](book/33-housing.md#housing-03)、[housing-12](book/33-housing.md#housing-12)

## 定期建筑物租赁

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[定期建筑物租赁](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_tk3_000059.html)
- 相关条目：[housing-04](book/33-housing.md#housing-04)

## 关于为确保住房而需要特别照顾的人的住房支援法人

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[关于为确保住房而需要特别照顾的人的住房支援法人](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_fr7_000026.html)
- 相关条目：[housing-05](book/33-housing.md#housing-05)

## 致力于建筑物状况调查（检查）的活用

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[致力于建筑物状况调查（检查）的活用](https://www.mlit.go.jp/tochi_fudousan_kensetsugyo/const/tochi_fudousan_kensetsugyo_const_tk3_000001_00063.html)
- 相关条目：[housing-06](book/33-housing.md#housing-06)

## 搬家手续网上服务

- 发布机构：数字代理
- 原始资料：[搬家手续网上服务](https://www.digital.go.jp/policies/moving_onestop_service)
- 相关条目：[moving-01](book/34-moving.md#moving-01)、[moving-16](book/34-moving.md#moving-16)

## 搬家/转运服务

- 发布机构：日本邮政
- 原始资料：[搬家/转运服务](https://www.post.japanpost.jp/service/receive/relocation/)
- 相关条目：[moving-02](book/34-moving.md#moving-02)

## 电子搬迁使用条款

- 发布机构：日本邮政
- 原始资料：[电子搬迁使用条款](https://www.post.japanpost.jp/service/receive/relocation/terms.html)
- 相关条目：[moving-02](book/34-moving.md#moving-02)

## 请勿使用未经授权的收集公司来处理废物

- 发布机构：日本环境省（環境省）
- 原始资料：[请勿使用未经授权的收集公司来处理废物](https://www.env.go.jp/recycle/kaden/tv-recycle/qa.html)
- 相关条目：[moving-03](book/34-moving.md#moving-03)

## 搬家相关手续一览（以横滨市为例）

- 发布机构：横滨市
- 原始资料：[搬家相关手续一览（以横滨市为例）](https://www.city.yokohama.lg.jp/life/hikkoshi.html)
- 相关条目：[moving-04](book/34-moving.md#moving-04)

## 如何安全可靠地使用搬家服务（2024 年 12 月号）

- 发布机构：国家消费者事务中心
- 原始资料：[如何安全可靠地使用搬家服务（2024 年 12 月号）](https://www.kokusen.go.jp/pdf_dl/wko/wko-202412.pdf)
- 相关条目：[moving-05](book/34-moving.md#moving-05)

## 搬家运输业务合同规则

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[搬家运输业务合同规则](https://www.mlit.go.jp/jidosha/jidosha_tk4_000034.html)
- 相关条目：[moving-05](book/34-moving.md#moving-05)

## 地址变更一站式服务等

- 发布机构：日本警察厅（警察庁）
- 原始资料：[地址变更一站式服务等](https://www.npa.go.jp/bureau/traffic/onestop.pdf)
- 相关条目：[moving-06](book/34-moving.md#moving-06)

## 孕妇身体变化、母婴健康手册、产前检查

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[孕妇身体变化、母婴健康手册、产前检查](https://prenatal.cfa.go.jp/pregnancy-and-childbirth/body-changes.html)
- 相关条目：[parenting-01](book/35-parenting.md#parenting-01)

## 孕妇综合咨询支援事业、孕妇支援福利

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[孕妇综合咨询支援事业、孕妇支援福利](https://www.cfa.go.jp/policies/shussan-kosodate)
- 相关条目：[parenting-02](book/35-parenting.md#parenting-02)

## 儿童津贴制度信息

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[儿童津贴制度信息](https://www.cfa.go.jp/policies/kokoseido/jidouteate/annai)
- 相关条目：[parenting-03](book/35-parenting.md#parenting-03)

## 有关免费幼儿教育和托儿系统的常见问题

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[有关免费幼儿教育和托儿系统的常见问题](https://www.cfa.go.jp/policies/kokoseido/mushouka/about/faq1/)
- 相关条目：[parenting-04](book/35-parenting.md#parenting-04)

## 关于开展产后护理业务

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[关于开展产后护理业务](https://www.cfa.go.jp/assets/contents/node/basic_page/field_ref_resources/0ac0f291-e4c2-475d-83fe-f1c39a6e551e/9691c745/20250408_policies_boshihoken_tsuuchi_2025_21.pdf)
- 相关条目：[parenting-05](book/35-parenting.md#parenting-05)

## 易于理解的新儿童/育儿支援系统

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[易于理解的新儿童/育儿支援系统](https://www.cfa.go.jp/policies/kokoseido/sukusuku/)
- 相关条目：[parenting-06](book/35-parenting.md#parenting-06)、[parenting-07](book/35-parenting.md#parenting-07)、[parenting-08](book/35-parenting.md#parenting-08)、[parenting-09](book/35-parenting.md#parenting-09)、[parenting-10](book/35-parenting.md#parenting-10)、[parenting-14](book/35-parenting.md#parenting-14)

## 护理保险制度及护理服务的利用方法

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[护理保险制度及护理服务的利用方法](https://www.mhlw.go.jp/content/12300000/001238058.pdf)
- 相关条目：[care-02](book/36-care.md#care-02)

## 护理服务信息公开制度

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[护理服务信息公开制度](https://www.mhlw.go.jp/stf/kaigo-kouhyou.html)
- 相关条目：[care-03](book/36-care.md#care-03)

## 减轻护理服务使用者的负担（横滨市指导）

- 发布机构：横滨市
- 原始资料：[减轻护理服务使用者的负担（横滨市指导）](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/fukushi-kaigo/koreisha-kaigo/kaigo-hoken/kougakukaigo.html)
- 相关条目：[care-04](book/36-care.md#care-04)

## 护理休假制度

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[护理休假制度](https://www.mhlw.go.jp/seisakunitsuite/bunya/koyou_roudou/koyoukintou/ryouritsu/kaigo/leave/index.html)
- 相关条目：[care-05](book/36-care.md#care-05)

## “○○家战略会议”讨论家务和育儿职责的分工

- 发布机构：内阁府男女共同参与局
- 原始资料：[“○○家战略会议”讨论家务和育儿职责的分工](https://www.gender.go.jp/public/sakusenkaigi/)
- 相关条目：[relationship-01](book/37-relationship.md#relationship-01)

## DV咨询导航/DV咨询+

- 发布机构：内阁府男女共同参与局
- 原始资料：[DV咨询导航/DV咨询+](https://www.gender.go.jp/policy/no_violence/dv_navi/index.html)
- 相关条目：[relationship-02](book/37-relationship.md#relationship-02)

## 儿童辅导中心虐待应对电话 189/咨询专用电话

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[儿童辅导中心虐待应对电话 189/咨询专用电话](https://www.cfa.go.jp/policies/jidougyakutai/gyakutai-taiou-dial)
- 相关条目：[relationship-03](book/37-relationship.md#relationship-03)

## 对单亲家庭的支援等

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[对单亲家庭的支援等](https://www.cfa.go.jp/policies/hitori-oya)
- 相关条目：[relationship-04](book/37-relationship.md#relationship-04)

## 你并不孤单

- 发布机构：内阁府孤独与孤立对策推进室
- 原始资料：[你并不孤单](https://www.notalone-cao.go.jp/)
- 相关条目：[relationship-05](book/37-relationship.md#relationship-05)

## 家庭关系调整调解

- 发布机构：法庭
- 原始资料：[家庭关系调整调解](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_07_06/index.html)
- 相关条目：[relationship-06](book/37-relationship.md#relationship-06)

## 自行车交通规则

- 发布机构：日本警察厅（警察庁）
- 原始资料：[自行车交通规则](https://www.npa.go.jp/bureau/traffic/bicycle/portal/rule.html)
- 相关条目：[mobility-01](book/38-mobility.md#mobility-01)

## 安全使用带踏板的自行车/机动自行车

- 发布机构：日本警察厅（警察庁）
- 原始资料：[安全使用带踏板的自行车/机动自行车](https://www.npa.go.jp/bureau/traffic/bicycle/index.html)
- 相关条目：[mobility-02](book/38-mobility.md#mobility-02)

## 反光材料/灯

- 发布机构：日本警察厅（警察庁）
- 原始资料：[反光材料/灯](https://www.npa.go.jp/bureau/traffic/anzen/reflector.html)
- 相关条目：[mobility-03](book/38-mobility.md#mobility-03)

## 关于安全驾驶咨询柜台

- 发布机构：日本警察厅（警察庁）
- 原始资料：[关于安全驾驶咨询柜台](https://www.npa.go.jp/policies/application/license_renewal/conferennce_out_line.html)
- 相关条目：[mobility-04](book/38-mobility.md#mobility-04)

## My Number 驾驶证（マイナ免許証）/在线更新培训

- 发布机构：日本警察厅（警察庁）
- 原始资料：[My Number 驾驶证（マイナ免許証）/在线更新培训](https://www.npa.go.jp/bureau/traffic/r4kaisei_main.html)
- 相关条目：[mobility-05](book/38-mobility.md#mobility-05)

## 通勤卡和学校卡的票价计算

- 发布机构：JR东日本
- 原始资料：[通勤卡和学校卡的票价计算](https://media.jreast.co.jp/articles/2871)
- 相关条目：[mobility-06](book/38-mobility.md#mobility-06)

## Yorozu支持中心的使用说明

- 发布机构：中小企业与创新组织
- 原始资料：[Yorozu支持中心的使用说明](https://www.smrj.go.jp/supporter/yorozu/index.html)
- 相关条目：[business-01](book/39-business.md#business-01)

## 创业支持/如何撰写创业计划

- 发布机构：日本金融公司
- 原始资料：[创业支持/如何撰写创业计划](https://www.jfc.go.jp/n/finance/sougyou/promotion/)
- 相关条目：[business-02](book/39-business.md#business-02)

## 为经营业务的个人保存簿记、分类帐等

- 发布机构：日本国税厅（国税庁）
- 原始资料：[为经营业务的个人保存簿记、分类帐等](https://www.nta.go.jp/taxes/shiraberu/shinkoku/kojin_jigyo/index.htm)
- 相关条目：[business-03](book/39-business.md#business-03)

## 食品卫生申请系统/保健所查询

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[食品卫生申请系统/保健所查询](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/shokuhin/kigu/index_00012.html)
- 相关条目：[business-05](book/39-business.md#business-05)

## G Biz ID 账户类型及申请

- 发布机构：数字代理
- 原始资料：[G Biz ID 账户类型及申请](https://gbiz-id.go.jp/top/apply/account_select.html?category=2)
- 相关条目：[business-06](book/39-business.md#business-06)

## 什么是人生聚会？

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[什么是人生聚会？](https://www.mhlw.go.jp/acp-jinseikaigi/about/)
- 相关条目：[endoflife-01](book/40-endoflife.md#endoflife-01)

## 什么是手写遗嘱存储系统？

- 发布机构：司法部
- 原始资料：[什么是手写遗嘱存储系统？](https://www.moj.go.jp/MINJI/01.html)
- 相关条目：[endoflife-02](book/40-endoflife.md#endoflife-02)

## 关于强制申请继承登记

- 发布机构：司法部
- 原始资料：[关于强制申请继承登记](https://www.moj.go.jp/MINJI/minji05_00599.html)
- 相关条目：[endoflife-03](book/40-endoflife.md#endoflife-03)

## 您现在应该开始考虑的数字退休

- 发布机构：国家消费者事务中心
- 原始资料：[您现在应该开始考虑的数字退休](https://www.kokusen.go.jp/news/data/n-20241120_1.html)
- 相关条目：[endoflife-05](book/40-endoflife.md#endoflife-05)

## 防止殡葬服务费出现问题

- 发布机构：国家消费者事务中心
- 原始资料：[防止殡葬服务费出现问题](https://www.kokusen.go.jp/news/data/n-20260603_2.html)
- 相关条目：[endoflife-06](book/40-endoflife.md#endoflife-06)

## 租金债务担保人登记制度

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[租金债务担保人登记制度](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_fr7_000024.html)
- 相关条目：[housing-07](book/33-housing.md#housing-07)

## 房地产交易过程中的洪水风险说明

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[房地产交易过程中的洪水风险说明](https://www.mlit.go.jp/totikensangyo/const/sosei_const_fr3_000074.html)
- 相关条目：[housing-08](book/33-housing.md#housing-08)

## 节能绩效标签

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[节能绩效标签](https://www.mlit.go.jp/shoene-jutaku/shoene-label/index.html)
- 相关条目：[housing-09](book/33-housing.md#housing-09)

## 公寓管理状况检查表

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[公寓管理状况检查表](https://www.mansion-info.mlit.go.jp/manshion_kanri/329/)
- 相关条目：[housing-10](book/33-housing.md#housing-10)、[housing-11](book/33-housing.md#housing-11)

## 租赁住房标准合同

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[租赁住房标准合同](https://www.mlit.go.jp/jutakukentiku/house/torikumi/keiyaku/kei01.html)
- 相关条目：[housing-13](book/33-housing.md#housing-13)

## 优先入住公屋

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[优先入住公屋](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_tk3_000096.html)
- 相关条目：[housing-15](book/33-housing.md#housing-15)

## 现有住房性能指南

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[现有住房性能指南](https://www.mlit.go.jp/common/001114501.pdf)
- 相关条目：[housing-16](book/33-housing.md#housing-16)

## 迁居申报（同一城市同一区内搬家）

- 发布机构：横滨市
- 原始资料：[迁居申报（同一城市同一区内搬家）](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/todokede/koseki-juminhyo/todokede-touroku/jyumin/tenkyo.html)
- 相关条目：[moving-07](book/34-moving.md#moving-07)

## 办理手续所需材料（这些情况不要忘记申报）

- 发布机构：横滨市
- 原始资料：[办理手续所需材料（这些情况不要忘记申报）](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/kokuho/todokede/process.html)
- 相关条目：[moving-08](book/34-moving.md#moving-08)

## 儿童医疗费补助

- 发布机构：横滨市
- 原始资料：[儿童医疗费补助](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/kenko-iryo/iryohijosei/shoni/child.html)
- 相关条目：[moving-09](book/34-moving.md#moving-09)

## 小学与初中入学手续说明

- 发布机构：横滨市
- 原始资料：[小学与初中入学手续说明](https://www.city.yokohama.lg.jp/kosodate-kyoiku/kyoiku/soudan/soudan1000.html)
- 相关条目：[moving-10](book/34-moving.md#moving-10)

## 各类申请相关：老年人福利指南

- 发布机构：横滨市
- 原始资料：[各类申请相关：老年人福利指南](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/fukushi-kaigo/koreisha-kaigo/kaigo-hoken/shinsei.html)
- 相关条目：[moving-11](book/34-moving.md#moving-11)

## 从南区迁往市外

- 发布机构：横滨市
- 原始资料：[从南区迁往市外](https://www.city.yokohama.lg.jp/minami/madoguchi-shisetsu/kuyakusho/annai/tetsuzukidownload.files/0109_20260318.pdf)
- 相关条目：[moving-12](book/34-moving.md#moving-12)

## 机动车登记手续

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[机动车登记手续](https://wwwtb.mlit.go.jp/kanto/jidou_gian/touroku/car_regist.html)
- 相关条目：[moving-13](book/34-moving.md#moving-13)

## 犬只登记及狂犬病预防接种手续

- 发布机构：横滨市
- 原始资料：[犬只登记及狂犬病预防接种手续](https://www.city.yokohama.lg.jp/kurashi/sumai-kurashi/pet-dobutsu/aigo/kainushi/kyokenbyo.html)
- 相关条目：[moving-14](book/34-moving.md#moving-14)

## 搬家时（迁出）

- 发布机构：横滨市
- 原始资料：[搬家时（迁出）](https://www.city.yokohama.lg.jp/nishi/shokai/sonota/lifestage/hikkoshi_tenshutsu.html)
- 相关条目：[moving-15](book/34-moving.md#moving-15)

## 关于婴儿健康检查的举措

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[关于婴儿健康检查的举措](https://www.cfa.go.jp/policies/boshihoken/nyuyojikenshin)
- 相关条目：[parenting-11](book/35-parenting.md#parenting-11)

## 育儿短期支援事业

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[育儿短期支援事业](https://www.cfa.go.jp/policies/kosodateshien/jido-short)
- 相关条目：[parenting-12](book/35-parenting.md#parenting-12)

## 家庭支援事业

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[家庭支援事业](https://kokasen.cfa.go.jp/support-programs)
- 相关条目：[parenting-13](book/35-parenting.md#parenting-13)

## 对残疾儿童的支持措施

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[对残疾儿童的支持措施](https://www.cfa.go.jp/policies/shougaijishien/shisaku)
- 相关条目：[parenting-15](book/35-parenting.md#parenting-15)

## 所有儿童都可以上幼儿园的制度

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[所有儿童都可以上幼儿园的制度](https://www.daretsu.cfa.go.jp/)
- 相关条目：[parenting-16](book/35-parenting.md#parenting-16)

## 提供护理服务

- 发布机构：横滨市
- 原始资料：[提供护理服务](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/fukushi-kaigo/koreisha-kaigo/kaigo-hoken/heart-page.files/0306_20260605.pdf)
- 相关条目：[care-09](book/36-care.md#care-09)、[care-10](book/36-care.md#care-10)、[care-12](book/36-care.md#care-12)

## 护理服务简介

- 发布机构：横滨市
- 原始资料：[护理服务简介](https://hama-gokoro.city.yokohama.lg.jp/care-services/)
- 相关条目：[care-11](book/36-care.md#care-11)

## 小型多功能家庭护理

- 发布机构：横滨市
- 原始资料：[小型多功能家庭护理](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/fukushi-kaigo/koreisha-kaigo/shisetsu/shisetu-annai/shouta.html)
- 相关条目：[care-15](book/36-care.md#care-15)

## 护理保险咨询窗口

- 发布机构：横滨市
- 原始资料：[护理保险咨询窗口](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/fukushi-kaigo/koreisha-kaigo/kaigo-hoken/kaigohoken-complaint/mado.html)
- 相关条目：[care-16](book/36-care.md#care-16)

## 子女抚养费索赔调解

- 发布机构：法庭
- 原始资料：[子女抚养费索赔调解](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_07_07/index.html)
- 相关条目：[relationship-07](book/37-relationship.md#relationship-07)

## 婚姻费用分担调解

- 发布机构：法庭
- 原始资料：[婚姻费用分担调解](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_07_03/index.html)
- 相关条目：[relationship-08](book/37-relationship.md#relationship-08)

## 有关儿童的调解

- 发布机构：法庭
- 原始资料：[有关儿童的调解](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_03_4/index.html)
- 相关条目：[relationship-09](book/37-relationship.md#relationship-09)

## 婚姻登记

- 发布机构：横滨市
- 原始资料：[婚姻登记](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/todokede/koseki-juminhyo/todokede-touroku/koseki/konin.html)
- 相关条目：[relationship-10](book/37-relationship.md#relationship-10)

## 合伙宣誓的各种程序

- 发布机构：横滨市
- 原始资料：[合伙宣誓的各种程序](https://www.city.yokohama.lg.jp/kurashi/kyodo-manabi/jinken/lgbt/partnershiptetsduki.html)
- 相关条目：[relationship-11](book/37-relationship.md#relationship-11)

## 关于年轻护理人员

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[关于年轻护理人员](https://kodomoshien.cfa.go.jp/young-carer/about/)
- 相关条目：[relationship-12](book/37-relationship.md#relationship-12)

## 支援蛰居族的举措

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[支援蛰居族的举措](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/hikikomori/index.html)
- 相关条目：[relationship-13](book/37-relationship.md#relationship-13)

## 性犯罪和性暴力受害者一站式支持中心

- 发布机构：日本内阁府（内閣府）
- 原始资料：[性犯罪和性暴力受害者一站式支持中心](https://www.gender.go.jp/policy/no_violence/seibouryoku/consult.html)
- 相关条目：[relationship-14](book/37-relationship.md#relationship-14)

## 网络人权咨询

- 发布机构：司法部
- 原始资料：[网络人权咨询](https://www.moj.go.jp/JINKEN/jinken113.html)
- 相关条目：[relationship-15](book/37-relationship.md#relationship-15)

## 请求不予受理

- 发布机构：横滨市
- 原始资料：[请求不予受理](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/todokede/koseki-juminhyo/todokede-touroku/koseki/fujyuri-moushide.html?lang=zh)
- 相关条目：[relationship-16](book/37-relationship.md#relationship-16)

## 儿童座椅保护儿童

- 发布机构：日本警察厅（警察庁）
- 原始资料：[儿童座椅保护儿童](https://www.npa.go.jp/bureau/traffic/anzen/childseat.html)
- 相关条目：[mobility-07](book/38-mobility.md#mobility-07)

## 请在所有座位上系好安全带。

- 发布机构：日本警察厅（警察庁）
- 原始资料：[请在所有座位上系好安全带。](https://www.npa.go.jp/bureau/traffic/anzen/seatbelt.html)
- 相关条目：[mobility-08](book/38-mobility.md#mobility-08)

## 切勿酒后驾车

- 发布机构：日本警察厅（警察庁）
- 原始资料：[切勿酒后驾车](https://www.npa.go.jp/bureau/traffic/insyu/info.html)
- 相关条目：[mobility-09](book/38-mobility.md#mobility-09)

## 驾驶执照/药物副作用和驾驶

- 发布机构：日本警察厅（警察庁）
- 原始资料：[驾驶执照/药物副作用和驾驶](https://www.npa.go.jp/bureau/traffic/menkyo/)
- 相关条目：[mobility-10](book/38-mobility.md#mobility-10)

## 安全使用高速公路

- 发布机构：NEXCO日本中部
- 原始资料：[安全使用高速公路](https://www.c-nexco.co.jp/images/news/6251/20b1b6ac19e20946c2730291a57e7b54.pdf)
- 相关条目：[mobility-11](book/38-mobility.md#mobility-11)

## 推动自行车责任保险等的投保。

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[推动自行车责任保险等的投保。](https://www.mlit.go.jp/road/bicycleuse/promotion/)
- 相关条目：[mobility-12](book/38-mobility.md#mobility-12)

## 对于使用轮椅的顾客

- 发布机构：JR东日本
- 原始资料：[对于使用轮椅的顾客](https://www.jreast.co.jp/en/equipment/equipment_1/wheelchair/)
- 相关条目：[mobility-13](book/38-mobility.md#mobility-13)

## 关于残疾人折扣制度的信息

- 发布机构：JR东日本
- 原始资料：[关于残疾人折扣制度的信息](https://jreastfaq.jreast.co.jp/faq/show/1175?category_id=27&site_domain=default)
- 相关条目：[mobility-14](book/38-mobility.md#mobility-14)

## 日常检查方法

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[日常检查方法](https://www.mlit.go.jp/jidosha/anzen/02maintenance/daily_check.html)
- 相关条目：[mobility-15](book/38-mobility.md#mobility-15)

## 如何加入汽车责任强制保险/互助

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[如何加入汽车责任强制保险/互助](https://www.mlit.go.jp/jidosha/jibaiseki/about/policyholder/index.html)
- 相关条目：[mobility-16](book/38-mobility.md#mobility-16)

## 在您的企业中利用知识产权

- 发布机构：专利局
- 原始资料：[在您的企业中利用知识产权](https://www.jpo.go.jp/support/chusho/index.html)
- 相关条目：[business-07](book/39-business.md#business-07)

## 邮购销售的监管

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[邮购销售的监管](https://www.no-trouble.caa.go.jp/what/mailorder/)
- 相关条目：[business-08](book/39-business.md#business-08)

## 邮购广告问答

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[邮购广告问答](https://www.no-trouble.caa.go.jp/qa/advertising.html-2)
- 相关条目：[business-09](book/39-business.md#business-09)

## 个人信息保护法的10大检查点

- 发布机构：个人信息保护委员会
- 原始资料：[个人信息保护法的10大检查点](https://www.ppc.go.jp/files/pdf/10_checkpoint.pdf)
- 相关条目：[business-10](book/39-business.md#business-10)

## 中小企业信息安全措施指南

- 发布机构：信息技术振兴机构
- 原始资料：[中小企业信息安全措施指南](https://www.ipa.go.jp/security/guide/sme/about.html)
- 相关条目：[business-11](book/39-business.md#business-11)

## 古董商牌照申请

- 发布机构：警察厅
- 原始资料：[古董商牌照申请](https://www.keishicho.metro.tokyo.lg.jp/tetsuzuki/kobutsu/tetsuzuki/kyoka.html?referral=referral%3Dfbadcv)
- 相关条目：[business-13](book/39-business.md#business-13)

## 业务连续性增强计划

- 发布机构：中小企业署
- 原始资料：[业务连续性增强计划](https://www.chusho.meti.go.jp/keiei/antei/bousai/keizokuryoku.html?post_id=7475)
- 相关条目：[business-14](book/39-business.md#business-14)

## 如果您想使用他人受版权保护的作品

- 发布机构：文化厅
- 原始资料：[如果您想使用他人受版权保护的作品](https://www.bunka.go.jp/seisaku/chosakuken/seidokaisetsu/chosakukensha_fumei/)
- 相关条目：[business-15](book/39-business.md#business-15)

## 人人可用的著作权合同手册：创作作品的权利与使用

- 发布机构：文化厅
- 原始资料：[人人可用的著作权合同手册：创作作品的权利与使用](https://www.bunka.go.jp/chosakuken/keiyaku_manual/2_3_2B.html)
- 相关条目：[business-16](book/39-business.md#business-16)

## 成人监护制度信息

- 发布机构：司法部
- 原始资料：[成人监护制度信息](https://www.moj.go.jp/MINJI/pdf/pamphlet.pdf)
- 相关条目：[endoflife-07](book/40-endoflife.md#endoflife-07)

## 成人监护制度概述

- 发布机构：法庭
- 原始资料：[成人监护制度概述](https://www.courts.go.jp/saiban/koukenp00/koukenp1/index.html)
- 相关条目：[endoflife-08](book/40-endoflife.md#endoflife-08)

## 使用长者终身支援服务须注意的事项

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[使用长者终身支援服务须注意的事项](https://www.caa.go.jp/policies/policy/consumer_policy/caution/caution_018/)
- 相关条目：[endoflife-09](book/40-endoflife.md#endoflife-09)

## 老年人终身支持业务指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[老年人终身支持业务指南](https://www.mhlw.go.jp/content/001262636.pdf?campaign=sbi)
- 相关条目：[endoflife-10](book/40-endoflife.md#endoflife-10)

## 荣区版结尾注

- 发布机构：横滨市
- 原始资料：[荣区版结尾注](https://www.city.yokohama.lg.jp/sakae/kenko-iryo-fukushi/fukushi_kaigo/koreisha_kaigo/hoken-igai/korei11.files/0009_20260105.pdf)
- 相关条目：[endoflife-11](book/40-endoflife.md#endoflife-11)

## 如何写结尾注释、葬礼和坟墓

- 发布机构：横滨市
- 原始资料：[如何写结尾注释、葬礼和坟墓](https://www.city.yokohama.lg.jp/seya/kenko-iryo-fukushi/fukushi_kaigo/koreisha_kaigo/torikumi/kourei18.files/0006_20220510.pdf)
- 相关条目：[endoflife-12](book/40-endoflife.md#endoflife-12)

## 有关墓地、墓葬等的法律概述

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[有关墓地、墓葬等的法律概述](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000130181.html)
- 相关条目：[endoflife-13](book/40-endoflife.md#endoflife-13)

## 撒灰指南

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[撒灰指南](https://www.mhlw.go.jp/content/11130500/001321304.pdf)
- 相关条目：[endoflife-14](book/40-endoflife.md#endoflife-14)

## 储存后内容的变更或撤回

- 发布机构：大阪法务局
- 原始资料：[储存后内容的变更或撤回](https://houmukyoku.moj.go.jp/osaka/hokangononaiyouhenkoutekkai.html)
- 相关条目：[endoflife-15](book/40-endoflife.md#endoflife-15)

## 业务继承/转移支持中心

- 发布机构：中小企业与创新组织
- 原始资料：[业务继承/转移支持中心](https://shoukei.smrj.go.jp/center/)
- 相关条目：[endoflife-16](book/40-endoflife.md#endoflife-16)

## 关于就学支援制度

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[关于就学支援制度](https://www.mext.go.jp/a_menu/shotou/career/05010502/017.htm)
- 相关条目：[education-01](book/41-education.md#education-01)

## 高中生的学术支援等

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[高中生的学术支援等](https://www.mext.go.jp/a_menu/shotou/mushouka/index.htm?mode=PC)
- 相关条目：[education-02](book/41-education.md#education-02)、[education-03](book/41-education.md#education-03)

## 符合新高等教育学习支持制度资格的院校

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[符合新高等教育学习支持制度资格的院校](https://www.mext.go.jp/a_menu/koutou/hutankeigen/1421838.htm)
- 相关条目：[education-04](book/41-education.md#education-04)

## 发生灾害或家庭财务突然变化时的申请

- 发布机构：日本学生支援机构
- 原始资料：[发生灾害或家庭财务突然变化时的申请](https://www.jasso.go.jp/shogakukin/moshikomi/rinji/index.html)
- 相关条目：[education-05](book/41-education.md#education-05)

## 处理拒绝上学的问题

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[处理拒绝上学的问题](https://www.mext.go.jp/a_menu/shotou/seitoshidou/04121505/004.htm)
- 相关条目：[education-06](book/41-education.md#education-06)

## 残疾儿童教育支持指南

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[残疾儿童教育支持指南](https://www.mext.go.jp/content/20210629-mxt_tokubetu01-000016487_01.pdf)
- 相关条目：[education-07](book/41-education.md#education-07)

## 关于对失学儿童的支持

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[关于对失学儿童的支持](https://www.mext.go.jp/a_menu/shotou/seitoshidou/1422155.htm)
- 相关条目：[education-08](book/41-education.md#education-08)

## 放学后儿童俱乐部

- 发布机构：日本儿童家庭厅（こども家庭庁）
- 原始资料：[放学后儿童俱乐部](https://www.cfa.go.jp/policies/kosodateshien/houkago-jidou)
- 相关条目：[education-09](book/41-education.md#education-09)

## 灾难互助福利/家长

- 发布机构：日本体育振兴中心
- 原始资料：[灾难互助福利/家长](https://www.jpnsport.go.jp/anzen/saigai/seido/tabid/60/default.aspx)
- 相关条目：[education-10](book/41-education.md#education-10)

## 24小时儿童SOS拨号

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[24小时儿童SOS拨号](https://www.mext.go.jp/a_menu/h30gouu7/1407291.htm)
- 相关条目：[education-11](book/41-education.md#education-11)

## 高中毕业水平认证考试概述

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[高中毕业水平认证考试概述](https://www.mext.go.jp/a_menu/koutou/shiken/mext_01319.html)
- 相关条目：[education-12](book/41-education.md#education-12)

## 对于那些想在初中夜校学习的人

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[对于那些想在初中夜校学习的人](https://www.mext.go.jp/a_menu/shotou/yakan/index_00005.htm)
- 相关条目：[education-13](book/41-education.md#education-13)

## 函授高中/常见问题解答

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[函授高中/常见问题解答](https://www.mext.go.jp/tsushinseikoukou/faq/)
- 相关条目：[education-14](book/41-education.md#education-14)

## 残障学生就学支援研讨会报告（第三次总结）

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[残障学生就学支援研讨会报告（第三次总结）](https://www.mext.go.jp/b_menu/shingi/chousa/koutou/123/mext_01732.html)
- 相关条目：[education-15](book/41-education.md#education-15)

## 建立学习支持门户网站

- 发布机构：日本文部科学省（文部科学省）
- 原始资料：[建立学习支持门户网站](https://www.mext.go.jp/b_menu/houdou/mext_01362.html)
- 相关条目：[education-16](book/41-education.md#education-16)

## 在线预订旅行的相关问题

- 发布机构：国家消费者事务中心
- 原始资料：[在线预订旅行的相关问题](https://www.kokusen.go.jp/news/data/n-20230920_1.html)
- 相关条目：[travel-01](book/42-travel.md#travel-01)

## 旅行社注册确认

- 发布机构：旅游代理机构
- 原始资料：[旅行社注册确认](https://www.mlit.go.jp/kankocho/seisaku_seido/ryokochui/torokukakunin.html)
- 相关条目：[travel-02](book/42-travel.md#travel-02)

## 关于将危险品带上飞机

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[关于将危险品带上飞机](https://www.mlit.go.jp/koku/koku_fr2_000007.html)
- 相关条目：[travel-03](book/42-travel.md#travel-03)

## 关于携带超大行李

- 发布机构：JR东海
- 原始资料：[关于携带超大行李](https://railway.jr-central.co.jp/oversized-baggage/)
- 相关条目：[travel-04](book/42-travel.md#travel-04)

## 火车延误/停运和退款

- 发布机构：JR东日本
- 原始资料：[火车延误/停运和退款](https://jreastfaq.jreast.co.jp/faq/show/1161?category_id=15&site_domain=default)
- 相关条目：[travel-05](book/42-travel.md#travel-05)

## 租车时，请务必在还车前检查汽车的状况。

- 发布机构：国家消费者事务中心
- 原始资料：[租车时，请务必在还车前检查汽车的状况。](https://www.kokusen.go.jp/news/data/n-20250328_1.html)
- 相关条目：[travel-06](book/42-travel.md#travel-06)

## 全民旅游

- 发布机构：旅游代理机构
- 原始资料：[全民旅游](https://www.mlit.go.jp/kankocho/seisaku_seido/kihonkeikaku/kokunaikoryu/kaitaku/universal-tourism.html)
- 相关条目：[travel-07](book/42-travel.md#travel-07)

## 山地事故与防灾概况

- 发布机构：日本警察厅（警察庁）
- 原始资料：[山地事故与防灾概况](https://www.npa.go.jp/news/release/2025/r06_sangakusounan_gaikyou.pdf)
- 相关条目：[travel-08](book/42-travel.md#travel-08)

## 为火山登山者提供信息

- 发布机构：日本气象厅
- 原始资料：[为火山登山者提供信息](https://www.data.jma.go.jp/vois/data/report/activity_info/)
- 相关条目：[travel-09](book/42-travel.md#travel-09)

## 海里玩耍的注意事项

- 发布机构：日本海上保安厅
- 原始资料：[海里玩耍的注意事项](https://www6.kaiho.mlit.go.jp/watersafety/swimming/02_attention/index.html)
- 相关条目：[travel-10](book/42-travel.md#travel-10)

## 使用国家公园的礼仪

- 发布机构：日本环境省（環境省）
- 原始资料：[使用国家公园的礼仪](https://www.env.go.jp/nature/nationalparks/about/manner/)
- 相关条目：[travel-11](book/42-travel.md#travel-11)

## 安全的私人住宿环境

- 发布机构：旅游代理机构
- 原始资料：[安全的私人住宿环境](https://www.mlit.go.jp/kankocho/minpaku/environment.html)
- 相关条目：[travel-12](book/42-travel.md#travel-12)

## 关于外出就餐或熟食时的食物过敏

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[关于外出就餐或熟食时的食物过敏](https://www.caa.go.jp/policies/policy/food_labeling/food_sanitation/allergy/efforts/)
- 相关条目：[travel-13](book/42-travel.md#travel-13)

## 假期郊游通行证

- 发布机构：JR东日本
- 原始资料：[假期郊游通行证](https://www.jreast.co.jp/tickets/info.aspx?GoodsCd=2490)
- 相关条目：[travel-14](book/42-travel.md#travel-14)

## 第 12 章 火灾时有用的建筑设施

- 发布机构：东京消防署
- 原始资料：[第 12 章 火灾时有用的建筑设施](https://www.tfd.metro.tokyo.lg.jp/ts/bfc_manual/instructor/cp12.html)
- 相关条目：[travel-15](book/42-travel.md#travel-15)

## 预防和控制过度旅游

- 发布机构：旅游代理机构
- 原始资料：[预防和控制过度旅游](https://www.mlit.go.jp/kankocho/seisaku_seido/kihonkeikaku/jizoku_kankochi/jizokukano_taisei/overtourism.html)
- 相关条目：[travel-16](book/42-travel.md#travel-16)

## 对于宠物主人和未来的宠物主人

- 发布机构：日本环境省（環境省）
- 原始资料：[对于宠物主人和未来的宠物主人](https://www.env.go.jp/nature/dobutsu/aigo/pickup/owner.html)
- 相关条目：[pets-01](book/43-pets.md#pets-01)

## 圈养动物搜索信息网站

- 发布机构：日本环境省（環境省）
- 原始资料：[圈养动物搜索信息网站](https://www.env.go.jp/nature/dobutsu/aigo/shuyo/index.html)
- 相关条目：[pets-02](book/43-pets.md#pets-02)、[pets-05](book/43-pets.md#pets-05)

## 狂犬病

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[狂犬病](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/kenkou/kekkaku-kansenshou18/kyokenbyou.html)
- 相关条目：[pets-03](book/43-pets.md#pets-03)

## 狗和猫的微芯片信息登记

- 发布机构：日本环境省（環境省）
- 原始资料：[狗和猫的微芯片信息登记](https://www.env.go.jp/nature/dobutsu/aigo/pickup/chip.html)
- 相关条目：[pets-04](book/43-pets.md#pets-04)

## 宠物的防灾对策

- 发布机构：日本环境省（環境省）
- 原始资料：[宠物的防灾对策](https://www.env.go.jp/nature/dobutsu/aigo/1_law/disaster.html)
- 相关条目：[pets-06](book/43-pets.md#pets-06)、[pets-07](book/43-pets.md#pets-07)

## 把猫养在室内

- 发布机构：日本环境省（環境省）
- 原始资料：[把猫养在室内](https://www.env.go.jp/nature/dobutsu/aigo/2_data/pamph/h2711a/pdf/04.pdf)
- 相关条目：[pets-08](book/43-pets.md#pets-08)

## 如果你保留它而不扔掉它或增加它，它会持续一生。

- 发布机构：日本环境省（環境省）
- 原始资料：[如果你保留它而不扔掉它或增加它，它会持续一生。](https://www.env.go.jp/nature/dobutsu/aigo/2_data/pamph/h2509a/full.pdf)
- 相关条目：[pets-09](book/43-pets.md#pets-09)、[pets-14](book/43-pets.md#pets-14)

## 你了解人畜共患病吗？

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[你了解人畜共患病吗？](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000155663.html)
- 相关条目：[pets-10](book/43-pets.md#pets-10)

## 与老年宠物和白银一代一起生活

- 发布机构：日本环境省（環境省）
- 原始资料：[与老年宠物和白银一代一起生活](https://www.env.go.jp/nature/dobutsu/aigo/2_data/pamph/r0109/pdf/full.pdf)
- 相关条目：[pets-11](book/43-pets.md#pets-11)、[pets-15](book/43-pets.md#pets-15)

## 对第一类动物经营业者的监管

- 发布机构：日本环境省（環境省）
- 原始资料：[对第一类动物经营业者的监管](https://www.env.go.jp/nature/dobutsu/aigo/1_law/trader.html)
- 相关条目：[pets-12](book/43-pets.md#pets-12)

## 关于遛狗

- 发布机构：日本环境省（環境省）
- 原始资料：[关于遛狗](https://www.env.go.jp/garden/kokyogaien/news/2022/06/post_486_00156.html)
- 相关条目：[pets-13](book/43-pets.md#pets-13)

## 给宠物主人的宠物食品指南

- 发布机构：日本环境省（環境省）
- 原始资料：[给宠物主人的宠物食品指南](https://www.env.go.jp/nature/dobutsu/aigo/2_data/pamph/petfood_guide/pdf/full.pdf)
- 相关条目：[pets-16](book/43-pets.md#pets-16)

## 振兴现有住房/装修市场

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[振兴现有住房/装修市场](https://www.mlit.go.jp/jutakukentiku/house/jutakukentiku_house_fr2_000055.html)
- 相关条目：[homecare-01](book/44-homecare.md#homecare-01)

## 装修估价咨询系统

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[装修估价咨询系统](https://www.mlit.go.jp/jutakukentiku/jutaku-kentiku.files/kashitanpocorner/consumer/reform.html)
- 相关条目：[homecare-02](book/44-homecare.md#homecare-02)

## 屋顶施工检查商业方法的问题正在增加。

- 发布机构：国家消费者事务中心
- 原始资料：[屋顶施工检查商业方法的问题正在增加。](https://www.kokusen.go.jp/news/data/n-20231011_1.html)
- 相关条目：[homecare-03](book/44-homecare.md#homecare-03)

## 抗震加固支撑系统

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[抗震加固支撑系统](https://taishin-kaishu.mlit.go.jp/rsystem/)
- 相关条目：[homecare-04](book/44-homecare.md#homecare-04)

## 建筑物拆除/翻新等过程中石棉的初步调查

- 发布机构：日本环境省（環境省）
- 原始资料：[建筑物拆除/翻新等过程中石棉的初步调查](https://www.env.go.jp/air/asbestos/post_87.html)
- 相关条目：[homecare-05](book/44-homecare.md#homecare-05)

## 公寓专用区域的维修等详细规定示例

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[公寓专用区域的维修等详细规定示例](https://www.mlit.go.jp/common/001185573.pdf)
- 相关条目：[homecare-06](book/44-homecare.md#homecare-06)

## 住宅火灾报警器

- 发布机构：消防局
- 原始资料：[住宅火灾报警器](https://www.fdma.go.jp/relocation/html/life/juukei.html?_fsi=FZBLZ7hc)
- 相关条目：[homecare-07](book/44-homecare.md#homecare-07)

## 有关住宅通风的信息

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[有关住宅通风的信息](https://www.mlit.go.jp/jutakukentiku/build/jutakukentiku_house_fr_000108.html)
- 相关条目：[homecare-08](book/44-homecare.md#homecare-08)

## 关于漏水（漏水）

- 发布机构：东京都水道局
- 原始资料：[关于漏水（漏水）](https://www.waterworks.metro.tokyo.lg.jp/faq/qa-7)
- 相关条目：[homecare-09](book/44-homecare.md#homecare-09)

## 警惕空调内部清洗造成的事故

- 发布机构：国家技术与产品评估研究所
- 原始资料：[警惕空调内部清洗造成的事故](https://www.nite.go.jp/jiko/chuikanki/press/2020fy/prs200625.html)
- 相关条目：[homecare-10](book/44-homecare.md#homecare-10)

## 小心害虫和害虫消灭问题

- 发布机构：国家消费者事务中心
- 原始资料：[小心害虫和害虫消灭问题](https://www.kokusen.go.jp/news/data/n-20240424_1.html)
- 相关条目：[homecare-11](book/44-homecare.md#homecare-11)

## 关于水管冻结

- 发布机构：东京都水道局
- 原始资料：[关于水管冻结](https://www.waterworks.metro.tokyo.lg.jp/kurashi/trouble/touketsu)
- 相关条目：[homecare-12](book/44-homecare.md#homecare-12)

## 长期使用产品安全检测系统

- 发布机构：日本经济产业省（経済産業省）
- 原始资料：[长期使用产品安全检测系统](https://www.meti.go.jp/product_safety/producer/shouan/21_shouan_panfu.pdf)
- 相关条目：[homecare-13](book/44-homecare.md#homecare-13)

## 清洁和检查接线设备

- 发布机构：国家技术与产品评估研究所
- 原始资料：[清洁和检查接线设备](https://www.nite.go.jp/jiko/chuikanki/press/2024fy/prs241128.html)
- 相关条目：[homecare-14](book/44-homecare.md#homecare-14)

## 年末年初谨防老人发生意外

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[年末年初谨防老人发生意外](https://www.caa.go.jp/policies/policy/consumer_safety/caution/caution_084/)
- 相关条目：[homecare-15](book/44-homecare.md#homecare-15)

## 房地产经纪人空置房屋委托管理指引

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[房地产经纪人空置房屋委托管理指引](https://www.mlit.go.jp/tochi_fudousan_kensetsugyo/const/content/001750009.pdf)
- 相关条目：[homecare-16](book/44-homecare.md#homecare-16)

## 推广家庭生态诊断

- 发布机构：日本环境省（環境省）
- 原始资料：[推广家庭生态诊断](https://www.env.go.jp/earth/ondanka/uchi_eco/shindan.html)
- 相关条目：[environment-01](book/45-environment.md#environment-01)

## 空调节能

- 发布机构：自然资源和能源局
- 原始资料：[空调节能](https://www.enecho.meti.go.jp/category/saving_and_new/saving/general/howto/airconditioning/index.html)
- 相关条目：[environment-02](book/45-environment.md#environment-02)

## 家庭节能工作及效果

- 发布机构：自然资源和能源局
- 原始资料：[家庭节能工作及效果](https://www.enecho.meti.go.jp/category/saving_and_new/saving/media/data/2025_summer/syouenemenu_katei01.pdf)
- 相关条目：[environment-03](book/45-environment.md#environment-03)

## 用 LED 灯替代荧光灯时的注意事项

- 发布机构：国家技术与产品评估研究所
- 原始资料：[用 LED 灯替代荧光灯时的注意事项](https://www.nite.go.jp/jiko/chuikanki/press/2024fy/prs250327.html)
- 相关条目：[environment-04](book/45-environment.md#environment-04)

## 选择节能产品的标准

- 发布机构：日本环境省（環境省）
- 原始资料：[选择节能产品的标准](https://ondankataisaku.env.go.jp/shinkyusan/knowledge04.html)
- 相关条目：[environment-05](book/45-environment.md#environment-05)

## 节能支持包

- 发布机构：自然资源和能源局
- 原始资料：[节能支持包](https://www.enecho.meti.go.jp/category/saving_and_new/saving/government/package.html)
- 相关条目：[environment-06](book/45-environment.md#environment-06)

## 家电回收系统常见问题解答

- 发布机构：日本经济产业省（経済産業省）
- 原始资料：[家电回收系统常见问题解答](https://www.meti.go.jp/policy/it_policy/kaden_recycle/faq/faq.html)
- 相关条目：[environment-07](book/45-environment.md#environment-07)

## 小家电回收信息

- 发布机构：日本环境省（環境省）
- 原始资料：[小家电回收信息](https://www.env.go.jp/content/900535790.pdf)
- 相关条目：[environment-08](book/45-environment.md#environment-08)

## 锂离子电池相关

- 发布机构：日本环境省（環境省）
- 原始资料：[锂离子电池相关](https://www.env.go.jp/recycle/waste/lithium_1/index.html)
- 相关条目：[environment-09](book/45-environment.md#environment-09)

## 您可以采取哪些措施来防止汞污染

- 发布机构：日本环境省（環境省）
- 原始资料：[您可以采取哪些措施来防止汞污染](https://www.env.go.jp/chemi/tmms/tobira/dekirukoto.html)
- 相关条目：[environment-10](book/45-environment.md#environment-10)

## 垃圾和资源物的分类和处理方法

- 发布机构：横滨市
- 原始资料：[垃圾和资源物的分类和处理方法](https://www.city.yokohama.lg.jp/lang/residents/ej/garbage/japanese1.html)
- 相关条目：[environment-11](book/45-environment.md#environment-11)

## 垃圾和资源物的分类和处理方法

- 发布机构：横滨市
- 原始资料：[垃圾和资源物的分类和处理方法](https://www.city.yokohama.lg.jp/lang/residents/living-guide/garbage/garbage-bunbetsu.html)
- 相关条目：[environment-12](book/45-environment.md#environment-12)

## 时尚与环保行动

- 发布机构：日本环境省（環境省）
- 原始资料：[时尚与环保行动](https://www.env.go.jp/policy/sustainable_fashion/actions/)
- 相关条目：[environment-13](book/45-environment.md#environment-13)

## 和全家人一起清理冰箱

- 发布机构：日本消费者厅（消費者庁）
- 原始资料：[和全家人一起清理冰箱](https://www.no-foodloss.caa.go.jp/topic_apr.html)
- 相关条目：[environment-14](book/45-environment.md#environment-14)

## 地方政府生活垃圾地沟油收集案例汇总

- 发布机构：日本环境省（環境省）
- 原始资料：[地方政府生活垃圾地沟油收集案例汇总](https://www.env.go.jp/recycle/waste/tool_gwd3r/gl-mcs/glmcs0703-ref01.pdf)
- 相关条目：[environment-15](book/45-environment.md#environment-15)

## 环境显示检查工具

- 发布机构：日本环境省（環境省）
- 原始资料：[环境显示检查工具](https://www.env.go.jp/policy/hozen/green/ecolabel/checklist.html)
- 相关条目：[environment-16](book/45-environment.md#environment-16)

## 个人编号卡及电子证明书的有效期限及更新

- 发布机构：数字代理
- 原始资料：[个人编号卡及电子证明书的有效期限及更新](https://www.digital.go.jp/policies/mynumber/expiration-date)
- 相关条目：[documents-01](book/46-documents.md#documents-01)

## 我的号码卡的安全

- 发布机构：数字代理
- 原始资料：[我的号码卡的安全](https://www.digital.go.jp/policies/mynumber/safety)
- 相关条目：[documents-02](book/46-documents.md#documents-02)

## 忘记密码

- 发布机构：地方政府信息系统组织
- 原始资料：[忘记密码](https://www.jpki.go.jp/procedure/password.html)
- 相关条目：[documents-03](book/46-documents.md#documents-03)

## 什么是便利店送货？

- 发布机构：地方政府信息系统组织
- 原始资料：[什么是便利店送货？](https://swww.lg-waps.go.jp/01-00.html)
- 相关条目：[documents-04](book/46-documents.md#documents-04)

## 户籍证明等广域投递

- 发布机构：司法部
- 原始资料：[户籍证明等广域投递](https://www.moj.go.jp/content/001409033.pdf)
- 相关条目：[documents-05](book/46-documents.md#documents-05)

## 在日本境内在线申请

- 发布机构：外交部
- 原始资料：[在日本境内在线申请](https://www.mofa.go.jp/mofaj/toko/passport/page22_004036.html)
- 相关条目：[documents-06](book/46-documents.md#documents-06)

## 索取住民票复印件/住民票记载事项证明书

- 发布机构：东广岛市
- 原始资料：[索取住民票复印件/住民票记载事项证明书](https://www.city.higashihiroshima.lg.jp/kurashi/todokede/3/7459.html)
- 相关条目：[documents-07](book/46-documents.md#documents-07)

## 什么是授权书？

- 发布机构：桥本市
- 原始资料：[什么是授权书？](https://www.city.hashimoto.lg.jp/guide/somubu/shimin/other/1510811470466.html)
- 相关条目：[documents-08](book/46-documents.md#documents-08)

## 印章登录证等遗失时的手续

- 发布机构：埼玉市
- 原始资料：[印章登录证等遗失时的手续](https://www.city.saitama.lg.jp/faq/001/001/002/p110017.html)
- 相关条目：[documents-09](book/46-documents.md#documents-09)

## 户口本附件复印件

- 发布机构：神户市
- 原始资料：[户口本附件复印件](https://www.city.kobe.lg.jp/a53715/kurashi/registration/shomeisho/13_huhyo.html)
- 相关条目：[documents-10](book/46-documents.md#documents-10)

## 户籍注音假名/常见问题解答

- 发布机构：司法部
- 原始资料：[户籍注音假名/常见问题解答](https://www.moj.go.jp/MINJI/furigana/faq.html)
- 相关条目：[documents-11](book/46-documents.md#documents-11)

## 用于验证身份的个人编号卡复印件

- 发布机构：个人信息保护委员会
- 原始资料：[用于验证身份的个人编号卡复印件](https://www.ppc.go.jp/all_faq_index/faq5-q6-13/)
- 相关条目：[documents-12](book/46-documents.md#documents-12)

## 预登记型身份通知系统

- 发布机构：西宫市
- 原始资料：[预登记型身份通知系统](https://www.city.nishinomiya.lg.jp/kurashi/koseki/kofumadoguchi/honnintsuchi.html)
- 相关条目：[documents-13](book/46-documents.md#documents-13)

## 有关注册证书上的批号/门牌号的常见问题

- 发布机构：司法部
- 原始资料：[有关注册证书上的批号/门牌号的常见问题](https://www.touki-kyoutaku-online.moj.go.jp/faq/faq_090.html)
- 相关条目：[documents-14](book/46-documents.md#documents-14)

## 到柜台索取身份证件

- 发布机构：横滨市
- 原始资料：[到柜台索取身份证件](https://www.city.yokohama.lg.jp/kurashi/koseki-zei-hoken/todokede/koseki-juminhyo/shoumei/mibun/mado.html)
- 相关条目：[documents-15](book/46-documents.md#documents-15)

## 确认已收到电子申请

- 发布机构：数字代理
- 原始资料：[确认已收到电子申请](https://app.e-oss.myna.go.jp/Application/resources/manual/application/07.html)
- 相关条目：[documents-16](book/46-documents.md#documents-16)

## 个人数字化物资传输服务

- 发布机构：国立国会图书馆
- 原始资料：[个人数字化物资传输服务](https://www.ndl.go.jp/use/digital_transmission_individuals)
- 相关条目：[community-01](book/47-community.md#community-01)

## 文娱中心/地区中心介绍

- 发布机构：札幌市
- 原始资料：[文娱中心/地区中心介绍](https://www.city.sapporo.jp/minami/shinko/center/index.html)
- 相关条目：[community-02](book/47-community.md#community-02)

## 当地综合性体育俱乐部

- 发布机构：体育经纪公司
- 原始资料：[当地综合性体育俱乐部](https://www.mext.go.jp/sports/b_menu/sports/mcatetop05/list/1371972.htm)
- 相关条目：[community-03](book/47-community.md#community-03)

## 居委会管理 居委会

- 发布机构：横滨市
- 原始资料：[居委会管理 居委会](https://www.city.yokohama.lg.jp/kurashi/kyodo-manabi/shiminkyodo/jichikai/jitikaiunnei.html)
- 相关条目：[community-04](book/47-community.md#community-04)

## 关于地方福利专员和儿童专员

- 发布机构：日本厚生劳动省（厚生労働省）
- 原始资料：[关于地方福利专员和儿童专员](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/hukushi_kaigo/seikatsuhogo/minseiiin/index.html)
- 相关条目：[community-05](book/47-community.md#community-05)

## 横滨当地活动/志愿者信息网站

- 发布机构：横滨市
- 原始资料：[横滨当地活动/志愿者信息网站](https://yokomusubi.city.yokohama.lg.jp/)
- 相关条目：[community-06](book/47-community.md#community-06)

## 对于那些考虑志愿服务和支持灾区的人

- 发布机构：日本内阁府（内閣府）
- 原始资料：[对于那些考虑志愿服务和支持灾区的人](https://www.bousai.go.jp/updates/r60101notojishin/volunteer.html)
- 相关条目：[community-07](book/47-community.md#community-07)

## 自愿防灾组织指南

- 发布机构：消防局
- 原始资料：[自愿防灾组织指南](https://www.fdma.go.jp/bousaikeikaku/items/0105dab156135146a3df02174d1bbee7752f29e8.pdf)
- 相关条目：[community-08](book/47-community.md#community-08)

## 道路紧急电话#9910

- 发布机构：日本国土交通省（国土交通省）
- 原始资料：[道路紧急电话#9910](https://www.mlit.go.jp/road/dia/index.html)
- 相关条目：[community-09](book/47-community.md#community-09)

## 公园里的游乐设施坏了，我想修一下。

- 发布机构：横滨市
- 原始资料：[公园里的游乐设施坏了，我想修一下。](https://www.city.yokohama.lg.jp/faq/kukyoku/kankyo/ryokuchi-iji/20211018164551029.html)
- 相关条目：[community-10](book/47-community.md#community-10)

## 关于公众意见征询制度

- 发布机构：数字代理
- 原始资料：[关于公众意见征询制度](https://public-comment.e-gov.go.jp/contents/about-public-comment/)
- 相关条目：[community-11](book/47-community.md#community-11)

## 有关国家管理的投诉、意见和要求，请向政府咨询。

- 发布机构：内阁府政府公共关系办公室
- 原始资料：[有关国家管理的投诉、意见和要求，请向政府咨询。](https://www.gov-online.go.jp/article/201310/entry-8552.html)
- 相关条目：[community-12](book/47-community.md#community-12)

## 会议记录

- 发布机构：横滨市
- 原始资料：[会议记录](https://www.city.yokohama.lg.jp/shikai/kiroku/kaigiroku.html)
- 相关条目：[community-13](book/47-community.md#community-13)

## NPO法人门户网站

- 发布机构：日本内阁府（内閣府）
- 原始资料：[NPO法人门户网站](https://www.npo-homepage.go.jp/npoportal/)
- 相关条目：[community-14](book/47-community.md#community-14)

## 了解残疾人的沟通方法

- 发布机构：札幌市
- 原始资料：[了解残疾人的沟通方法](https://www.city.sapporo.jp/shogaifukushi/communication/study.html)
- 相关条目：[community-15](book/47-community.md#community-15)

## 饮食改善促进会员

- 发布机构：横滨市
- 原始资料：[饮食改善促进会员](https://www.city.yokohama.lg.jp/kenko-iryo-fukushi/kenko-iryo/kenkozukuri/eiyo/kaizen/14583.html)
- 相关条目：[community-16](book/47-community.md#community-16)

## 死亡通知

- 发布机构：司法部
- 原始资料：[死亡通知](https://www.moj.go.jp/ONLINE/FAMILYREGISTER/5-4.html)
- 相关条目：[bereavement-01](book/48-bereavement.md#bereavement-01)

## 按目的搜索 [Okuyami]

- 发布机构：船桥市
- 原始资料：[按目的搜索 \[Okuyami\]](https://www.city.funabashi.lg.jp/other/0001/frequent_okuyami.html)
- 相关条目：[bereavement-02](book/48-bereavement.md#bereavement-02)

## 晚安角柜台信息

- 发布机构：船桥市
- 原始资料：[晚安角柜台信息](https://www.city.funabashi.lg.jp/kurashi/koseki/001/p083468.html)
- 相关条目：[bereavement-03](book/48-bereavement.md#bereavement-03)

## 当领取养老金的人去世时

- 发布机构：日本年金机构（日本年金機構）
- 原始资料：[当领取养老金的人去世时](https://www.nenkin.go.jp/service/jukyu/tetsuduki/kyotsu/jukyu/20140731-01.html)
- 相关条目：[bereavement-04](book/48-bereavement.md#bereavement-04)

## 健康保险丧葬费（费）缴纳申请书

- 发布机构：国民健康保险协会
- 原始资料：[健康保险丧葬费（费）缴纳申请书](https://www.kyoukaikenpo.or.jp/application_form/benefit/012)
- 相关条目：[bereavement-05](book/48-bereavement.md#bereavement-05)

## 曾由逝者供养的人（家属）加入国民健康保险的手续

- 发布机构：新宿区
- 原始资料：[曾由逝者供养的人（家属）加入国民健康保险的手续](https://www.city.shinjuku.lg.jp/content/000398612.pdf)
- 相关条目：[bereavement-06](book/48-bereavement.md#bereavement-06)

## 迁入、迁出、搬迁、户籍变更通知

- 发布机构：船桥市
- 原始资料：[迁入、迁出、搬迁、户籍变更通知](https://www.city.funabashi.lg.jp/kurashi/koseki/002/p009791.html)
- 相关条目：[bereavement-07](book/48-bereavement.md#bereavement-07)

## 遗嘱认证

- 发布机构：法庭
- 原始资料：[遗嘱认证](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_06_17/index.html)
- 相关条目：[bereavement-08](book/48-bereavement.md#bereavement-08)

## 关于证书 |手写遗嘱及遗嘱存储系统

- 发布机构：司法部
- 原始资料：[关于证书 |手写遗嘱及遗嘱存储系统](https://www.moj.go.jp/MINJI/05.html)
- 相关条目：[bereavement-09](book/48-bereavement.md#bereavement-09)

## 关于法定继承信息认证制度具体程序

- 发布机构：法务局
- 原始资料：[关于法定继承信息认证制度具体程序](https://houmukyoku.moj.go.jp/homu/page7_000014)
- 相关条目：[bereavement-10](book/48-bereavement.md#bereavement-10)

## 有关继承程序的信息

- 发布机构：三菱UFJ银行
- 原始资料：[有关继承程序的信息](https://www.bk.mufg.jp/tsukau/tetsuduki/sozoku/point.html)
- 相关条目：[bereavement-11](book/48-bereavement.md#bereavement-11)

## 纳税人死亡时的年度纳税申报（准确定申报）

- 发布机构：日本国税厅（国税庁）
- 原始资料：[纳税人死亡时的年度纳税申报（准确定申报）](https://www.nta.go.jp/taxes/shiraberu/taxanswer/shotoku/2022.htm)
- 相关条目：[bereavement-13](book/48-bereavement.md#bereavement-13)

## 继承分割调解

- 发布机构：法庭
- 原始资料：[继承分割调解](https://www.courts.go.jp/saiban/syurui/syurui_kazi/kazi_07_12/index.html)
- 相关条目：[bereavement-14](book/48-bereavement.md#bereavement-14)

## 房地产处置服务的合同问题

- 发布机构：国家消费者事务中心
- 原始资料：[房地产处置服务的合同问题](https://www.kokusen.go.jp/news/data/n-20180719_1.html)
- 相关条目：[bereavement-15](book/48-bereavement.md#bereavement-15)

## 悲伤护理

- 发布机构：春日井市
- 原始资料：[悲伤护理](https://www.city.kasugai.lg.jp/kenko/iryo/kokoronokenko/1030244.html)
- 相关条目：[bereavement-16](book/48-bereavement.md#bereavement-16)
