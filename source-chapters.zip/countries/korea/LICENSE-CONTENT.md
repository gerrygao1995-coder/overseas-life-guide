# 内容许可

本韩国卷的原创改编与中文翻译沿用 **Creative Commons Attribution 4.0 International（CC BY 4.0）**。韩国源项目将其说明文字、韩文正文、条目数据、自制封面与分享图、EPUB正文按此许可提供；其生成、HTML显示和计算代码采用MIT。

- [许可说明](https://creativecommons.org/licenses/by/4.0/)
- [许可全文](https://creativecommons.org/licenses/by/4.0/legalcode)
- [来源与改动说明](ATTRIBUTION.md)
- [完整保留的原许可](ORIGIN/LICENSE-CONTENT.md)

复制、再分发或改编时须保留原作、韩国版及本次改编的来源与许可链接，说明修改情况。第三方网站、商标、图片和外链原文不因链接而纳入此许可。具体条款以许可全文为准。
