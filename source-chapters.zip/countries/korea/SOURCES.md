# 韩国卷来源索引

以下按条目保留来源链接及韩国原版核查日期；不表示中文改编重新核验了全部来源。完整原题也保存在各条目和数据文件中。

## H01 戒烟先使用保健所的免费帮助

- [戒烟指南 — 保健所（보건소） 戒烟诊所](https://www.nosmokeguide.go.kr/helpness/clinic) · 2026-10-09

## H02 把步行和力量训练纳入日常安排

- [世界卫生组织 — 体力活动和久坐行为指南](https://www.who.int/publications/i/item/9789240015128) · 2026-10-09
- [世界卫生组织 — 《身体活动指南》中针对成人的详细建议（由 NCBI 提供）](https://www.ncbi.nlm.nih.gov/books/NBK566046/) · 2026-10-09
- [世界卫生组织 — 体力活动](https://www.who.int/news-room/fact-sheets/detail/physical-activity) · 2026-10-09

## H03 选择付费体检前先查询国家体检资格

- [国民健康保险（NHIS） — 一般健康检查实施指南](https://www.nhis.or.kr/nhis/healthin/wbhaca04500m01.do) · 2026-10-09
- [国民健康保险公团（NHIS）— 体检对象及资格查询（需要身份认证）](https://www.nhis.or.kr/nhis/healthin/retrieveHealthinCheckUpTargetPerson.do) · 2026-10-09
- [国家法令信息中心 — 健康检查实施标准（2026-01-07生效）](https://www.law.go.kr/LSW/admRulInfoP.do?admRulSeq=2100000272270&chrClsCd=010201) · 2026-10-09
- [韩国法制处生活法律信息 — 健康体检支持与费用说明](https://easylaw.go.kr/CSP/OnhunqueansInfoRetrieve.laf?onhunqnaAstSeq=97&onhunqueSeq=5256) · 2026-10-09

## H04 汇总用药清单，检查重复用药与相互作用

- [健康保险审查评价院（HIRA） — 我吃的药！一目了然](https://www.hira.or.kr/rb/dur/form.do?pgmid=HIRAA050300000100) · 2026-10-09

## H05 医保外自费项目要同时问清必要性、替代方案与总费用

- [国民健康保险（NHIS） — 医保外自费项目（비급여） 用户指南](https://www.nhis.or.kr/nbinfo/htmc_guide.do) · 2026-10-09
- [国民健康保险（NHIS） — 医保外自费项目（비급여） 按项目列出的定价信息](https://www.nhis.or.kr/nbinfo/wbhfaa06200m28.do) · 2026-10-09

## H06 需要洗牙时先确认医保适用范围

- [国民健康保险公团（NHIS）— 洗牙医保给付说明](https://www.nhis.or.kr/static/html/wbma/c/wbmac0218.html) · 2026-10-09

## E01 提前熟悉119、112和报警时需要提供的信息

- [韩国政策简报 — 119、112、110求助电话](https://www.korea.kr/briefing/policyBriefingView.do?newsId=148906821) · 2026-10-09
- [韩国疾病管理厅 — 心肺复苏期间拨打 119 的指南](https://health.kdca.go.kr/healthinfo/biz/health/gnrlzHealthInfo/gnrlzHealthInfo/gnrlzHealthInfoView.do?cntnts_sn=6226) · 2026-10-09

## E02 练习胸外按压与AED使用，应对成人心脏骤停

- [韩国疾病管理厅 - 心肺复苏 (CPR)](https://health.kdca.go.kr/healthinfo/biz/health/gnrlzHealthInfo/gnrlzHealthInfo/gnrlzHealthInfoView.do?cntnts_sn=6226) · 2026-10-09
- [内政部和安全部 Safe TV – CPR 培训](https://www.safetv.go.kr/base/video/view?idx=1527&playlistManagementIdx=&searchCategory=) · 2026-10-09

## E03 突发瘫痪、言语障碍或严重胸痛时立即拨打119

- [韩国疾病管理厅 - 中风和心肌梗塞的早期应对很重要](https://www.kdca.go.kr/kdca/2847/subview.do?enc=Zm5jdDF8QEB8JTJGYmJzJTJGa2RjYSUyRjQxJTJGMzEwMDYxJTJGYXJ0Y2xWaWV3LmRvJTNGcGFzc3dvcmQlM0QlMjZyZ3NCZ25kZVN0ciUzRCUyNmZpbmRPcG53cmQlM0QlMjZmaW5kV29yZCUzRCUyNnJnc0VuZGRlU3RyJTNEJTI2ZmluZFR5cGUlM0QlMjZmaW5kQ2xTZXElM0QlMjZwYWdlJTNEMSUyNg%3D%3D) · 2026-10-09

## E04 公寓起火时根据家中和疏散路线的情况行动

- [KTV全国广播—消防局公寓火灾疏散安全措施指南](https://www.ktv.go.kr/content/view?content_id=689298) · 2026-10-09
- [相关部委联合 - 公寓住户火灾疏散行为指南（江原道消防厅发布的PDF）](https://gfsa.gwd.go.kr/egf/bp/board/article/download?fileSeq=1221842) · 2026-10-09

## E05 露营和取暖时单独排查一氧化碳风险

- [国家消防局/政策简报——一氧化碳中毒的预防和应对](https://www.korea.kr/multi/visualNewsView.do?newsId=148857162) · 2026-10-09
- [消防部门/政策简报——露营用品和安全规则](https://www.korea.kr/multi/visualNewsView.do?newsId=148942495) · 2026-10-09

## E06 出现进水迹象时立即离开地下空间

- [公共管理和安全部/政策简报——防洪公民行动指南](https://www.korea.kr/news/policyNewsView.do?newsId=148916782) · 2026-10-09
- [行政安全部 - 地下空间浸水准备 (2025-05-26)](https://mois.go.kr/video/bbs/type019/commonSelectBoardArticle.do?bbsId=BBSMSTR_000000000255&nttId=117937&searchCode1=) · 2026-10-09
- [公共管理和安全部——大雨和大风行为准则](https://www.mois.go.kr/frt/bbs/type002/commonSelectBoardArticle.do?bbsId=BBSMSTR_000000000205&nttId=78903) · 2026-10-09

## R01 比较每月住房总成本，而不只看房价

- [国土交通省实际交易价格公开制度](https://rt.molit.go.kr/) · 2026-10-09

## R02 支付定金前确认所有人及顺位在先的权利

- [轻松查找生活法律法规信息：登记确认等。](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=629&popMenu=ov) · 2026-10-09
- [国土交通省：全租合同 避免 全租诈骗 的检查表](https://www.korea.kr/news/policyNewsView.do?newsId=148905628) · 2026-10-09

## R03 把入住、迁入申报和取得确定日期一起办理

- [轻松查找生活法律信息：获取对抗力（대항력）和优先受偿权（우선변제권）](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=3&cnpClsNo=1&csmSeq=629) · 2026-10-09

## R04 签约前先确认能否投保押金返还保证

- [韩国住房金融公司：一般 全租（전세） 保护保证](https://www.hf.go.kr/ko/sub02/sub02_05_01.do) · 2026-10-09

## R05 查看私人房源时也查看公共租赁住房公告

- [韩国政策简报：有关住房政策的所有信息“我的家”](https://www.korea.kr/news/policyNewsView.do?newsId=148919758) · 2026-10-09

## R06 押金未退还时先检查搬家的办理顺序

- [国家法令信息中心：对抗力（대항력） 关于承租人失去占有后完成租赁登记的先例](https://www.law.go.kr/LSW/precInfoP.do?precSeq=605771) · 2026-10-09

## M01 保留应急资金后，优先减少高成本债务

- [韩国金融电信清算协会账户信息：金融信息查询和综合账户管理](https://payinfo.or.kr/main/main.do) · 2026-10-09

## M02 按金融机构分别计算存款保护限额

- [金融服务委员会：与提高存款保护限额相关的主要质量保证](https://fsc.go.kr/po020201/84975) · 2026-10-09

## M03 就业或晋升后再次查询贷款利率

- [金融服务委员会：要求降息的权利](https://www.fsc.go.kr/no040101?cnId=1621) · 2026-10-09

## M04 集中整理分散的账户、积分和自动付款

- [韩国金融电信和清算协会账户信息：账户信息综合管理服务](https://payinfo.or.kr/main/main.do) · 2026-10-09

## M05 怀疑电话诈骗时立即停止通话与汇款

- [警察厅：语音网络钓鱼综合对策指南](https://www.counterscam112.go.kr/campaign/index.html) · 2026-10-09
- [韩国政策简报：如何应对金融犯罪损害](https://www.korea.kr/news/policyNewsView.do?newsId=148925712) · 2026-10-09

## M06 排除声称同时保本和保证高收益的投资

- [金融服务委员会：安全金融生活运动](https://www.fsc.go.kr/no010101/87634) · 2026-10-09
- [警察厅：投资领袖室诈骗警告](https://www.korea.kr/news/policyNewsView.do?newsId=148926749) · 2026-10-09

## T01 固定通勤时确认“모두의 카드”的登记及返还记录

- [韩国政府 K-Empathy：每个人的卡 (K-Pass)](https://gonggam.korea.kr/newsContentView.es?mid=a12502000000&news_id=288d790b-147a-42fb-ac86-d1042418f22c&section_id=) · 2026-10-09
- [首尔市：气候伴侣卡运营终止，大家的卡转换常见问题解答](https://news.seoul.go.kr/traffic/public/climatecard-faq/faq-stop) · 2026-10-09

## T02 按居住地址与实际路线选择当地交通通票

- [首尔市：关于推出气候伴侣通行证的通知](https://news.seoul.go.kr/traffic/archives/518138) · 2026-10-09
- [首尔市：气候伴侣卡 30 天运营结束常见问题解答](https://news.seoul.go.kr/traffic/public/climatecard-faq/faq-stop) · 2026-10-09
- [首尔市：推出气候伴侣卡短期票](https://news.seoul.go.kr/traffic/archives/510651) · 2026-10-09

## T03 换乘使用同一张卡，并按规定下车刷卡

- [首尔市：综合换乘折扣系统](https://news.seoul.go.kr/traffic/transfer_discount) · 2026-10-09

## T04 比较火车票的最终票价与改签条件

- [KORAIL 官方车票预订](https://www.korail.com/) · 2026-10-09

## T05 以全年持有成本判断是否买车

- [韩国国家石油公司 Offinet：智能手机服务信息](https://www.opinet.co.kr/user/cusmartapp/cusmartappView.do) · 2026-10-09

## T06 先用公共自行车试行短途出行，并确认还车完成

- [首尔市：公共自行车Ttareungi使用费和安全规则](https://news.seoul.go.kr/traffic/archives/33719) · 2026-10-09

## W01 第一天上班就留存劳动条件文件

- [雇佣劳动部劳动合同信息](https://www.moel.go.kr/mainpop2.do) · 2026-10-09
- [就业劳动部标准劳动合同及工资表格式](https://www.moel.go.kr/policy/policydata/view.do?bbs_seq=20230700845) · 2026-10-09

## W02 记录欠薪金额与应付日期，再寻求咨询

- [就业和劳动部劳动门户网站如何解决拖欠工资问题](https://labor.moel.go.kr/minwonSysInfo/wagesolway.do) · 2026-10-09

## W03 离职后先确认离职证明与求职补助资格

- [雇佣24（고용24） 失业保险金（실업급여）（永久）](https://www.work24.go.kr/cm/c/f/1100/selecSystInfo.do?currentPageNo=1&recordCountPerPage=10&systClId=SC00000254&systCnntId=CI00001715&systId=SI00000411&upprSystClId=) · 2026-10-09
- [就业保险失业保险金（실업급여）制度信息及工作变动的正当理由](https://ei.work24.go.kr/ei/eim/eg/ei/eiEminsr/retrievePb0201Info.do) · 2026-10-09

## W04 选择“明日学习卡”课程时看其能产生什么求职成果

- [雇佣24（고용24） 全国明日学习卡发行指南](https://www.work24.go.kr/hr/h/a/1100/selectIssuGudn.do) · 2026-10-09

## W05 工作受伤后，在治疗的同时留存工伤资料

- [轻松查找生活法律信息 护理福利的申请和支付](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=2&cnpClsNo=2&csmSeq=575&popMenu=ov) · 2026-10-09

## W06 自由职业者每月整理收入、费用和税务资料

- [国家税务局 综合所得税 信息和簿记义务](https://nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7802) · 2026-10-09
- [国税厅个人劳务事业收入缴纳表信息](https://d.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=238925&mi=40349) · 2026-10-09

## B01 同时查询福利会员与政府24的福利提醒服务

- [Bokjiro福利门户（복지로）服务使用指南](https://www.bokjiro.go.kr/ssis-tbu/cms/pc/intro/intro/info/01/index.html) · 2026-10-09
- [政府24（정부24） 福利通知](https://plus.gov.kr/portal/benefitV2/) · 2026-10-09

## B02 生计突然中断时拨打129咨询紧急福利

- [卫生福利部紧急福利支援](https://www.mohw.go.kr/menu.es?mid=a10708010100) · 2026-10-09
- [健康福利咨询中心129电话咨询](https://www.129.go.kr/counsel/counsel01.do) · 2026-10-09

## B03 离职后比较地区医保保费与任意继续参保

- [国民健康保险公团（NHIS） 自愿继续认购信息](https://www.nhis.or.kr/static/alim/paper/oldpaper/202212/sub/18.html) · 2026-10-09
- [生活法律信息：维持失业人员的就业订户状态](https://easylaw.go.kr/CSP/OnhunqueansInfoRetrieve.laf?onhunqnaAstSeq=97&onhunqueSeq=5102) · 2026-10-09

## B04 先查询国民年金的参保空档与预计领取额

- [国民年金（국민연금） 工业园区 国民年金（국민연금） 常见问题·信用信息](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0095M0.do) · 2026-10-09

## B05 需要长期照护时了解长期护理认定

- [国民健康保险公团（NHIS） 长期护理保险 信息](https://www.nhis.or.kr/renewal_popup/imgPopup16/index.html) · 2026-10-09
- [生活法信息 长期护理分级程序和标准](https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=2&cnpClsNo=1&csmSeq=2038) · 2026-10-09

## B06 因残疾而生活困难时联系活动支援与当地资源

- [保健福祉部对残疾人活动的支援](https://www.mohw.go.kr/menu.es?mid=a10710040700) · 2026-10-09
- [Bokjiro福利门户（복지로） 福利指导及服务信息](https://www.bokjiro.go.kr/ssis-tbu/cms/pc/intro/intro/info/01/index.html) · 2026-10-09

## F01 统一申请孕产支持后，还要确认受理记录

- [行政安全部 — 幸福生育一站式服务说明](https://www.korea.kr/news/customizedNewsView.do?newsId=148933586) · 2026-10-09
- [政府民事服务咨询中心 — 安心怀孕综合服务说明](https://www.110.go.kr/data/counselView.do?curPage=23&num=A01_720936&scCate1=&scCate2=&scIntt=&scText=&scType=) · 2026-10-09

## F02 分别确认育儿假使用权与补助领取条件

- [雇佣24 — 育儿假补助](https://m.work24.go.kr/cm/c/f/1100/selecSystInfo.do?systClId=SC00000251&systId=SI00000402) · 2026-10-09
- [雇佣劳动部关于使用短期育儿假的信息](https://moel.go.kr/news/cardinfo/view.do?bbs_seq=20260800522) · 2026-10-09
- [雇佣劳动部关于延长育儿假期间要求的咨询](https://1350.moel.go.kr/rtmview.do?id=1000325546) · 2026-10-09

## F03 分别准备儿童照护补助资格认定与实际服务分配

- [申请政府托儿服务支持指南](https://idolbom.go.kr/front/srvcUtztnGuide/govApply) · 2026-10-09

## F04 一起核对托育费用补助与实际额外支出

- [中央育儿综合支援中心 育儿补助金支援概要](https://central.childcare.go.kr/lcentral/cmmnpage/cmmnpage10.jsp) · 2026-10-09
- [中央保育综合支援中心 0~5岁保育费](https://central.childcare.go.kr/lcentral/d1_30000/d1_600058/d1_600320/d1_600322.jsp) · 2026-10-09
- [釜山广域市2026年必要费用征收限额事例](https://central.childcare.go.kr/lbusan/d3_30000/d3_20032.jsp) · 2026-10-09

## F05 通过居民中心衔接老年家人的日常照护

- [生活法资讯2026老年人定制化护理服务指南](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=1963&menuType=cnpcls&popMenu=ov) · 2026-10-09

## F06 继承、抚养费等家庭纠纷要备好资料后咨询公共法律服务

- [韩国法律援助公团咨询及预约信息](https://www.klac.or.kr/startingChat.do?channelCd=CHAT) · 2026-10-09
- [生活法律资讯 法律咨询及诉讼支持信息](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=3&cnpClsNo=2&csmSeq=1533&popMenu=ov) · 2026-10-09

## C01 按整个合约期总成本比较手机方案，而不只看月费

- [Smart Choice 可选合同申请人](https://smartchoice.or.kr/smc/service/danpageNew.do) · 2026-10-09

## C02 定期付款同时核对使用次数与下次扣款日

- [公平交易委员会电子商务法施行令及施行细则修正案](https://www.ftc.go.kr/www/selectBbsNttView.do?bordCd=3&key=12&nttSn=43795&pageIndex=1&pageUnit=10&rltnNttSn=38047&searchCnd=all&searchCtgry=01%2C02&searchViolt=11) · 2026-10-09

## C03 网购退货须在期限内申请并留存记录

- [轻松查找生活方式法律信息 网上购物 退货/退款](https://easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=4&cciNo=1&cnpClsNo=2&csmSeq=835&popMenu=ov) · 2026-10-09
- [韩国消费者院消费者咨询程序](https://www.kca.go.kr/odr/pg/ma/cnsutInfo.do) · 2026-10-09

## C04 选家电时同时考虑尺寸与耗电量

- [韩国能源机构能源消耗效率等级标签制度](https://eep.energy.or.kr/business_introduction/effi_summary.aspx) · 2026-10-09

## C05 采购食物按单位价格和实际能吃掉的数量计算

- [韩国消费者院参与价格服务介绍](https://price.go.kr/tprice/portal/pricenewsandtpriceintro/tpriceintro/getPriceIntro.do) · 2026-10-09
- [参与价格：各商品的价格信息及使用注意事项](https://www.price.go.kr/tprice/portal/pricenews/pricereport/priceReportList.do) · 2026-10-09

## C06 先到社区图书馆找书籍与学习资料

- [韩国国立中央图书馆图书链接服务新闻稿](https://www.nl.go.kr/NL/contents/N50603000000.do?id=46421&page=1&schBdcode=&schGroupCode=&schM=view&viewCount=9) · 2026-10-09
- [图书连接服务通知和用户指南菜单](https://books.nl.go.kr/one/contents/ON1010000000.do) · 2026-10-09

## D01 为重要账户设置不同密码与2步验证

- [KISA 两步身份验证信息](https://www.boho.or.kr/kr/bbs/view.do?bbsId=B0001030&menuNo=205090&nttId=71204) · 2026-10-09
- [KISA 账户接管注意事项和诈骗应对措施](https://www.boho.or.kr/kr/bbs/view.do?bbsId=B0000133&menuNo=205020&nttId=71555) · 2026-10-09

## D02 备份照片和重要文件，并实际测试恢复

- [KISA 安全信息系统备份指南](https://www.boho.or.kr/kr/bbs/view.do?bbsId=B0000127&menuNo=205021&nttId=36327) · 2026-10-09
- [KISA 勒索软件响应指南](https://www.boho.or.kr/common/cmm/fms/FileDown.do?atchFileId=FILE_000000000081740&fileSn=3) · 2026-10-09

## D03 核对本人名下通信线路，必要时限制新开户

- [MSafer 身份防盗服务](https://www.msafer.or.kr/index.do?refer=top) · 2026-10-09
- [MSafer 常见问题解答](https://www.msafer.or.kr/cs/faq.do) · 2026-10-09

## D04 收到快递与补助短信后在官方应用中再次核实

- [KISA 诈骗警告](https://www.boho.or.kr/kr/bbs/view.do?bbsId=B0000030&menuNo=205027&nttId=71280) · 2026-10-09
- [KISA 诈骗验证服务](https://boho.or.kr/kr/subPage.do?menuNo=205116) · 2026-10-09

## D05 清理闲置账户与不必要的个人信息授权

- [个人信息门户信息主体权利行使服务](https://www.privacy.go.kr/front/contents/cntntsView.do?contsNo=196) · 2026-10-09

## D06 支付昂贵课程前，先完整学完一门公开课

- [教育部国内终身教育网站介绍](https://okep.moe.go.kr/html/page.do?htmlId=23&menu_seq=209) · 2026-10-09
- [K-MOOC当前课程和运营期间](https://www.kmooc.kr/) · 2026-10-09

## SL01 先确定起床时间，再确定就寝目标

- [美国疾病预防控制中心，关于睡眠](https://www.cdc.gov/sleep/about/index.html) · 2026-10-09

## SL02 失眠影响生活时先就医，再考虑购买安眠药

- [英国国民医疗服务体系（NHS），失眠](https://www.nhs.uk/conditions/insomnia/) · 2026-10-09

## SL03 打鼾伴随呼吸暂停和白天嗜睡时咨询检查

- [英国 NHS，睡眠呼吸暂停](https://www.nhs.uk/conditions/sleep-apnoea/) · 2026-10-09

## SL04 紧张时温和呼吸5分钟

- [英国 NHS，压力呼吸练习](https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/) · 2026-10-09

## SL05 记录日常功能变化，而不只描述情绪，再寻求咨询

- [美国 NIMH，关爱您的心理健康](https://www.nimh.nih.gov/health/topics/caring-for-your-mental-health) · 2026-10-09
- [国家心理健康信息门户，搜索心理健康相关组织](https://mentalhealth.go.kr/portal/health/fac/PotalHealthFacListTab2.do) · 2026-10-09

## SL06 把精神科药物的疗效、副作用与下次复诊日一并管理

- [NIMH，心理健康药物，美国](https://www.nimh.nih.gov/health/topics/mental-health-medications) · 2026-10-09

## SL07 应对职业倦怠时纳入工作量调整

- [英国 NHS，工作相关压力](https://www.nhs.uk/every-mind-matters/lifes-challenges/work-related-stress/) · 2026-10-09

## SL08 感到有自伤风险时不要独自承受，应立即求助

- [卫生福利部宣传预防自杀政策，24小时求助热线109](https://www.mohw.go.kr/menu.es?mid=a10716040000) · 2026-10-09

## NU01 选定3种可以经常重复吃的基础餐食

- [世界卫生组织，健康饮食](https://www.who.int/news-room/fact-sheets/detail/healthy-diet) · 2026-10-09

## NU02 从汤汁与酱料中减少钠摄入

- [世界卫生组织，减少钠摄入量](https://www.who.int/news-room/fact-sheets/detail/sodium-reduction) · 2026-10-09

## NU03 从每天的一杯含糖饮料开始替换

- [世界卫生组织，指南：成人和儿童的糖摄入量](https://www.who.int/publications/i/item/9789241549028/) · 2026-10-09
- [世界卫生组织，健康饮食](https://www.who.int/news-room/fact-sheets/detail/healthy-diet) · 2026-10-09

## NU04 把体重目标改为可持续行为，避免极端限制

- [美国疾病预防控制中心，减肥步骤](https://www.cdc.gov/healthy-weight-growth/losing-weight/) · 2026-10-09

## NU05 剩菜从在室温下冷却时起就要管理存放时间

- [U.S. FoodSafety.gov，食品安全的四个步骤](https://www.foodsafety.gov/keep-food-safe/4-steps-to-food-safety) · 2026-10-09

## NU06 把饭前、如厕后洗手变成固定习惯

- [韩国疾病管理厅国家健康信息门户网站、洗手](https://health.kdca.go.kr/healthinfo/biz/health/gnrlzHealthInfo/gnrlzHealthInfo/gnrlzHealthInfoView.do?cntnts_sn=6545) · 2026-10-09

## NU07 以含氟牙膏和牙间清洁为基础

- [英国 NHS，如何保持牙齿清洁](https://www.nhs.uk/live-well/healthy-teeth-and-gums/how-to-keep-your-teeth-clean/) · 2026-10-09

## NU08 成人接种疫苗时同时核对年龄、疾病与接种记录

- [韩国疾病管理厅疫苗接种助理、成人疫苗接种时间表](https://nip.kdca.go.kr/irhp/infm/goVcntInfo.do?menuCd=115&menuLv=1) · 2026-10-09
- [疾病管理本部预防接种助理、预防接种管理](https://nip.kdca.go.kr/irhp/mngm/goVcntMngm.do?menuCd=332&menuLv=3) · 2026-10-09

## NU09 记录饮酒量；存在戒断症状时不要自行戒酒

- [英国 NHS，酒精使用障碍](https://www.nhs.uk/conditions/alcohol-use-disorder/) · 2026-10-09
- [国家心理健康信息门户，搜索心理健康相关组织](https://mentalhealth.go.kr/portal/health/fac/PotalHealthFacListTab2.do) · 2026-10-09

## NU10 按功效、成分重复与相互作用检查营养补充剂清单

- [釜山地方食品药品安全局，保健功能食品的故事](https://www.mfds.go.kr/brd/m_768/view.do?seq=3693) · 2026-10-09
- [食品安全国家门户（식품안전나라）— 保健功能食品安全服用指南](https://www.foodsafetykorea.go.kr/portal/board/boardDetail.do?bbs_no=bbs464&menu_grp=MENU_NEW01&menu_no=3811&ntctxt_no=1070219) · 2026-10-09

## CH01 在相同条件下测量并记录家庭血压

- [美国疾病预防控制中心，测量你的血压](https://www.cdc.gov/high-blood-pressure/measure/index.html) · 2026-10-09

## CH02 提前与家人练习糖尿病低血糖应对

- [美国疾病预防控制中心，低血糖的治疗](https://www.cdc.gov/diabetes/treatment/treatment-low-blood-sugar-hypoglycemia.html) · 2026-10-09

## CH03 在诊室里当面演示哮喘吸入器的使用

- [英国国民医疗服务体系（NHS），哮喘](https://www.nhs.uk/conditions/asthma/) · 2026-10-09

## CH04 腰痛时尽量保持可承受的活动，避免长时间卧床

- [英国国民医疗服务体系（NHS），背痛](https://www.nhs.uk/conditions/back-pain/) · 2026-10-09

## CH05 根据检查结果调整肾病饮食

- [美国NIDDK，成人慢性肾病患者的健康饮食](https://www.niddk.nih.gov/health-information/kidney-disease/chronic-kidney-disease-ckd/healthy-eating-adults-chronic-kidney-disease) · 2026-10-09
- [美国 NIDDK，保持肾脏安全：明智的药物选择](https://www.niddk.nih.gov/health-information/kidney-disease/keeping-kidneys-safe) · 2026-10-09

## CH06 购买辅助器具前，按实际生活空间咨询适配性

- [国家康复中心中央辅助器具中心、区域中心信息](https://forum.nrc.go.kr/knw/home/knat/knat_map.php) · 2026-10-09

## CH07 准备3个问题和一份变化记录再去慢性病复诊

- [美国NIH — 就诊准备](https://health.nih.gov/health-topics-a-z/prepare-for-appointment) · 2026-10-09

## CH08 突然听不清时不要等到下个月体检

- [美国 NIDCD，突发性耳聋](https://www.nidcd.nih.gov/health/sudden-deafness) · 2026-10-09

## PR01 备孕时先确认叶酸补充与已有健康问题

- [美国疾病预防控制中心，关于叶酸](https://www.cdc.gov/folic-acid/about/index.html) · 2026-10-09

## PR02 发现怀孕后先和医务人员核对用药清单

- [英国 NHS，妊娠期药物](https://www.nhs.uk/pregnancy/keeping-well/medicines/) · 2026-10-09

## PR03 集中保存产前检查安排与结果

- [英国 NHS，您的产前护理](https://www.nhs.uk/pregnancy/your-pregnancy-care/your-antenatal-care-and-appointments/) · 2026-10-09
- [e保健所（보건소）、保健所（보건소） 与怀孕和分娩相关的服务](https://www.e-health.go.kr/) · 2026-10-09

## PR04 提前了解孕期危险信号并确定夜间联系渠道

- [美国疾病预防控制中心，紧急孕产妇警告信号和症状](https://www.cdc.gov/hearher/maternal-warning-signs/index.html) · 2026-10-09

## PR05 孕期饮食先注意食品安全与停止饮酒

- [英国 NHS，怀孕期间应避免的食物](https://www.nhs.uk/pregnancy/keeping-well/foods-to-avoid/) · 2026-10-09

## PR06 按身体状况以短时活动保持孕期运动

- [英国国民医疗服务体系（NHS），孕期锻炼](https://www.nhs.uk/pregnancy/keeping-well/exercise/) · 2026-10-09

## PR07 先安排联系、出行与分娩偏好，再准备待产用品

- [英国NHS — 分娩计划应包含什么](https://www.nhs.uk/best-start-in-life/pregnancy/preparing-for-labour-and-birth/what-to-include-in-your-birth-plan/) · 2026-10-09
- [英国NHS — 待产住院用品清单](https://www.nhs.uk/start-for-life/pregnancy/preparing-for-labour-and-birth/hospital-bag-checklist/) · 2026-10-09

## PR08 产后也把母亲的身心健康纳入就诊计划

- [美国疾病预防控制中心，紧急孕产妇警告信号和症状](https://www.cdc.gov/hearher/maternal-warning-signs/index.html) · 2026-10-09

## PR09 让婴儿睡眠表面坚实、平坦且无杂物

- [美国NICHD，为婴儿提供安全的睡眠环境](https://safetosleep.nichd.nih.gov/reduce-risk/safe-sleep-environment) · 2026-10-09
- [美国NICHD，安全睡眠常见问题解答](https://safetosleep.nichd.nih.gov/reduce-risk/FAQ) · 2026-10-09

## PR10 严格遵守配方奶浓度与使用时限

- [美国疾病预防控制中心，婴儿配方奶粉制备和储存](https://www.cdc.gov/infant-toddler-nutrition/formula-feeding/preparation-and-storage.html) · 2026-10-09

## YH01 把婴幼儿体检结果的后续处理也写入日历

- [国民健康保险公团（NHIS），2024年婴幼儿健康检查指南](https://www.nhis.or.kr/static/html/wbma/c/wbhaca04800_2024.pdf) · 2026-10-09

## YH02 入学前区分漏种疫苗与电子记录缺失

- [韩国疾病管理厅 — 2026年小学、初中入学生预防接种核查项目说明](https://www.kdca.go.kr/bbs/kdca/55/305178/download.do) · 2026-10-09
- [疾病管理本部预防接种助理、预防接种管理](https://nip.kdca.go.kr/irhp/mngm/goVcntMngm.do?menuCd=332&menuLv=3) · 2026-10-09

## YH03 婴儿发热时同时观察体温、呼吸与反应

- [英国诺丁汉 NHS 和诺丁汉郡 ICB 3 个月以下婴儿发烧。](https://notts.icb.nhs.uk/your-services/childrens-health-and-wellbeing/concerned-your-newborn-baby-is-unwell-less-than-3-months/my-baby-has-fever-high-temperature/) · 2026-10-09

## YH04 安排补习班课程前先留足睡眠时间

- [美国疾病预防控制中心，睡眠与健康](https://www.cdc.gov/healthy-schools/sleep/index.html) · 2026-10-09

## YH05 看不清黑板时先查视力，再考虑护眼保健品

- [美国 NEI，屈光不正眼镜](https://www.nei.nih.gov/eye-health-information/eye-conditions-and-diseases/refractive-errors/eyeglasses-refractive-errors) · 2026-10-09

## YH06 先听孩子说上学遇到的困难，再看缺课次数

- [青年1388，咨询信息](https://www.1388.go.kr/cco/YTOSP_SC_CCI_01) · 2026-10-09

## YH07 与学校共享食物过敏的书面应对计划

- [美国疾病预防控制中心，学校食物过敏](https://www.cdc.gov/school-health-conditions/food-allergies/index.html) · 2026-10-09

## YH08 撞到头后出现异常，当天不要再返回赛场

- [美国疾病预防控制中心，应对与运动相关的脑震荡](https://www.cdc.gov/heads-up/response/index.html) · 2026-10-09
- [美国疾病预防控制中心，轻度创伤性脑损伤和脑震荡的症状](https://www.cdc.gov/traumatic-brain-injury/signs-symptoms/index.html) · 2026-10-09

## AE01 防晒产品要与遮阴和衣物防护一起使用

- [英国 NHS、防晒霜和防晒安全](https://www.nhs.uk/live-well/seasonal-health/sunscreen-and-sun-safety/) · 2026-10-09

## AE02 减少痤疮刺激，并在形成瘢痕前就医

- [英国国民医疗服务体系（NHS），痤疮](https://www.nhs.uk/conditions/acne/) · 2026-10-09

## AE03 购买脱发治疗套餐前先查明原因

- [英国国民医疗服务体系（NHS），脱发](https://www.nhs.uk/symptoms/hair-loss/) · 2026-10-09

## AE04 直接向实际施术者咨询美容治疗，并留出决定时间

- [英国 NHS，在您进行整容手术之前](https://www.nhs.uk/tests-and-treatments/cosmetic-procedures/advice/before-you-have-a-cosmetic-procedure/) · 2026-10-09
- [英国 NHS，选择谁来为您进行整容手术](https://www.nhs.uk/tests-and-treatments/cosmetic-procedures/advice/choosing-who-will-do-your-procedure/) · 2026-10-09

## AE05 外貌焦虑占据日常生活时，也要咨询心理痛苦

- [英国NHS — 躯体变形障碍（BDD）](https://www.nhs.uk/mental-health/conditions/body-dysmorphia/) · 2026-10-09

## AE06 填充注射后视力改变或异常疼痛，应先就医再问退款

- [美国 FDA，真皮填充剂：软组织填充剂](https://www.fda.gov/medical-devices/aesthetic-cosmetic-devices/dermal-fillers-soft-tissue-fillers) · 2026-10-09

## AG01 从夜间去卫生间的路线开始减少跌倒风险

- [NIA，在家预防跌倒：逐个房间](https://www.nia.nih.gov/health/falls-and-falls-prevention/preventing-falls-home-room-room) · 2026-10-09

## AG02 进食呛咳与体重下降不要一概归因于年龄

- [英国 NHS，吞咽困难](https://www.nhs.uk/symptoms/swallowing-problems-dysphagia/) · 2026-10-09

## AG03 突发意识混乱不要当成痴呆的自然进展

- [英国NHS，突然混乱](https://www.nhs.uk/symptoms/confusion/) · 2026-10-09

## AG04 出院前确认回家后由谁负责什么

- [英国NHS，出院](https://www.nhs.uk/nhs-services/hospitals/going-into-hospital/being-discharged-from-hospital/) · 2026-10-09

## AG05 比较长期护理机构时同时看评估结果与实际照护

- [国民健康保险公团（NHIS）— 长期护理机构查询、机构评估与家庭照护者休假制度](https://www.longtermcare.or.kr/npbs/r/a/201/selectLtcoSrch.web?menuId=npe0000000650) · 2026-10-09

## AG06 家庭照护表先安排主要照护者的休息时间

- [NIA，照顾好自己：给护理人员的提示](https://www.nia.nih.gov/health/caregiving/taking-care-yourself-tips-caregivers) · 2026-10-09
- [国民健康保险公团（NHIS）— 长期护理机构查询、机构评估与家庭照护者休假制度](https://www.longtermcare.or.kr/npbs/r/a/201/selectLtcoSrch.web?menuId=npe0000000650) · 2026-10-09

## AG07 在本人还有判断能力时记录自己的延命医疗意愿

- [韩国国立延命医疗管理机构 — 预立延命医疗意愿书常见问题](https://www.lst.go.kr/comm/faq.do?view=2) · 2026-10-09
- [韩国国立延命医疗管理机构 — 预立延命医疗意愿书费用说明](https://www.lst.go.kr/comm/cardDetail.do?bno=2910) · 2026-10-09

## AG08 根据症状与照护需要咨询临终关怀和姑息治疗

- [国家癌症信息中心、临终关怀和姑息治疗](https://www.cancer.go.kr/lay1/S1T571C572/contents.do) · 2026-10-09
- [韩国国家癌症信息中心 — 临终关怀适用对象](https://www.cancer.go.kr/lay1/S1T307C856/contents.do) · 2026-10-09

## SA01 按家庭实际需要准备应急包

- [行政安全部国民安全24 — 地震公众行动指南](https://www.safekorea.go.kr/safekorea-kor/acts/nacts/action-guide.do?actsHeaderTitle=%EC%A7%80%EC%A7%84&category=earthQuake&menuSn=4) · 2026-10-09

## SA02 酷暑时转移到凉爽地点，并警惕意识变化

- [韩国疾病管理厅国家健康信息门户网站，热相关疾病的预防和应对](https://health.kdca.go.kr/healthinfo/biz/health/ntcnInfo/healthSourc/thtimtCntnts/thtimtCntntsView.do?thtimt_cntnts_sn=122) · 2026-10-09

## SA03 寒冷中言语含糊与意识混乱可能是失温信号

- [英国 NHS，体温过低](https://www.nhs.uk/conditions/hypothermia/) · 2026-10-09

## SA04 地震摇晃时保护自己，停止后再疏散

- [行政安全部国民安全24 — 地震公众行动指南](https://www.safekorea.go.kr/safekorea-kor/acts/nacts/action-guide.do?actsHeaderTitle=%EC%A7%80%EC%A7%84&category=earthQuake&menuSn=4) · 2026-10-09

## SA05 高速公路事故后先避免二次事故

- [韩国道路公社高速公路TV — 事故或故障时的“비트박스”行动口诀](https://www.youtube.com/watch?v=mKcqxi6rTL8) · 2026-10-09

## SA06 有人溺水时不要贸然跳水施救

- [韩国疾病管理厅国家健康信息门户 — 溺水](https://health.kdca.go.kr/healthinfo/biz/health/gnrlzHealthInfo/gnrlzHealthInfo/gnrlzHealthInfoView.do?cntnts_sn=1747) · 2026-10-09
- [京畿道坡州市教育支援厅 戏水安全规则指南](https://www.goepj.kr/dext5editordata/2024/07/20240718_130020321_03916.pdf) · 2026-10-09

## SA07 热力烧伤用流动的凉水冷却

- [英国 NHS 伦敦和东南烧伤网络、烧伤急救](https://www.lsebn.nhs.uk/patient-information-3) · 2026-10-09
- [英国 NHS，烧伤和烫伤](https://www.nhs.uk/conditions/burns-and-scalds/) · 2026-10-09

## SA08 纽扣电池上锁存放，怀疑吞入就应急诊就医

- [英国剑桥大学医院 NHS 儿童误食纽扣电池](https://www.cuh.nhs.uk/patient-information/button-battery-ingestion-in-children-advice-for-parents-and-carers/) · 2026-10-09
- [英国NHS Alder Hey儿童医院 — 孩子吞入纽扣电池后怎么办](https://www.alderhey.nhs.uk/what-to-do-if-your-child-swallows-a-button-battery/) · 2026-10-09

## CR01 重大事件第一天先落实安全地点与当日基本需要

- [世界卫生组织，心理急救：现场工作人员指南](https://iris.who.int/bitstream/handle/10665/44615/9789241548205_eng.pdf) · 2026-10-09

## CR02 头部受伤后与亲近的人共享出院指示及恶化信号

- [美国疾病预防控制中心，轻度脑外伤或脑震荡后该怎么办](https://www.cdc.gov/traumatic-brain-injury/response/index.html) · 2026-10-09
- [美国疾病预防控制中心，轻度创伤性脑损伤和脑震荡的症状](https://www.cdc.gov/traumatic-brain-injury/signs-symptoms/index.html) · 2026-10-09

## CR03 请求具体帮助，并保留是否讲述经历的选择权

- [世界卫生组织，心理急救：现场工作人员指南](https://iris.who.int/bitstream/handle/10665/44615/9789241548205_eng.pdf) · 2026-10-09

## CR04 噩梦、回避或焦虑影响生活时不要等满一个月

- [美国 NIMH，应对创伤事件](https://www.nimh.nih.gov/health/topics/coping-with-traumatic-events) · 2026-10-09
- [国家创伤中心，2026 年灾难经历恢复计划信息](https://www.nct.go.kr/serviceCenter/noticeDetail.do?refnceSeq=1066) · 2026-10-09
- [国家心理健康信息门户，搜索心理健康相关组织](https://mentalhealth.go.kr/portal/health/fac/PotalHealthFacListTab2.do) · 2026-10-09

## CR05 向孩子反复说明安全情况，并保持熟悉的日常安排

- [NIMH，帮助儿童和青少年应对创伤事件](https://www.nimh.nih.gov/sites/default/files/documents/health/publications/helping-children-and-adolescents-cope-with-disasters-and-other-traumatic-events/helping-children-and-adolescents-cope-with-traumatic-events.pdf) · 2026-10-09

## CR06 从小范围活动开始安排恢复计划，并继续调整

- [美国退伍军人事务部国家创伤后应激障碍中心 — 灾后自我照护](https://www.ptsd.va.gov/disaster_events/for_everyone/selfcare_after_disaster.asp) · 2026-10-09
- [美国 NIMH，应对创伤事件](https://www.nimh.nih.gov/health/topics/coping-with-traumatic-events) · 2026-10-09

## EF01 把今天要完成的一件事定义为具体成果

- [智慧休息中心咨询使用指南](https://www.iapc.or.kr/contents.do?cid=50&idx=11) · 2026-10-09

## EF02 把通知分为紧急联系与可以稍后查看的信息

- [智慧休息中心咨询使用指南](https://www.iapc.or.kr/contents.do?cid=50&idx=11) · 2026-10-09

## EF03 限制使用时间先从最常打开的一个应用开始

- [智慧休息中心咨询使用指南](https://www.iapc.or.kr/contents.do?cid=50&idx=11) · 2026-10-09

## EF04 结束工作时写下一句话，说明下次从哪里继续

- [雇佣24（고용24） 就业支持和就业信息服务](https://m.work24.go.kr/cm/main.do) · 2026-10-09

## EF05 会前列出待决问题，会后记录负责人和截止时间

- [妇女新工作中心就业支持服务](https://saeil.mogef.go.kr/hom/info/service.do) · 2026-10-09

## EF06 接到新请求时先确认原计划中需要推迟什么

- [家庭中心商业和家庭咨询指南](https://seocho.familynet.or.kr/web/lay1/S1T296C337/contents.do) · 2026-10-09

## EF07 每周把一次时间表与实际生活对照

- [智慧休息中心咨询使用指南](https://www.iapc.or.kr/contents.do?cid=50&idx=11) · 2026-10-09

## EF08 数字设备使用破坏日常生活时联系咨询服务

- [智慧休息中心咨询使用指南](https://www.iapc.or.kr/contents.do?cid=50&idx=11) · 2026-10-09

## RE01 同居前自愿说明收入、债务与赡养责任

- [性别平等和家庭部家庭中心支援项目](https://www.mogef.go.kr/sp/fam/sp_fam_f003.do) · 2026-10-09

## RE02 婚礼支付定金前列出总费用与取消费用表

- [韩国消费者厅各商品损害救济箱使用指南](https://www.kca.go.kr/odr/cm/in/exmplPgItem.do) · 2026-10-09

## RE03 确定共同生活费与各自自由支出的范围

- [性别平等和家庭部家庭中心支援项目](https://www.mogef.go.kr/sp/fam/sp_fam_f003.do) · 2026-10-09
- [韩国法律援助公团咨询信息](https://www.klac.or.kr/startingChat.do?channelCd=CHAT) · 2026-10-09

## RE04 家务分工包括执行，也包括准备与检查

- [性别平等和家庭部家庭中心支援项目](https://www.mogef.go.kr/sp/fam/sp_fam_f003.do) · 2026-10-09

## RE05 共同承担住房费用时记录登记名义、出资额与结算原则

- [韩国法律援助公社咨询信息](https://www.klac.or.kr/startingChat.do?channelCd=CHAT) · 2026-10-09

## RE06 婚前讨论是否生育以及照护与职业计划

- [家庭中心商业和家庭咨询指南](https://seocho.familynet.or.kr/web/lay1/S1T296C337/contents.do) · 2026-10-09

## RE07 约定双方原生家庭支持与人情礼金支出的上限

- [性别平等和家庭部家庭中心支援项目](https://www.mogef.go.kr/sp/fam/sp_fam_f003.do) · 2026-10-09
- [韩国法律援助公社咨询信息](https://www.klac.or.kr/startingChat.do?channelCd=CHAT) · 2026-10-09

## RE08 家庭财务检查用于决定下一步，而非互相评判

- [家庭中心商业和家庭咨询指南](https://seocho.familynet.or.kr/web/lay1/S1T296C337/contents.do) · 2026-10-09

## RS01 受到威胁时先到安全地点并联系112，再考虑交谈

- [警察厅犯罪风险/现场报告指南](https://www.police.go.kr/www/agency/intro/intro0601.jsp) · 2026-10-09
- [女性紧急号码1366信息](https://www.mogef.go.kr/cc/wcc/cc_wcc_f001.do) · 2026-10-09

## RS02 在安全范围内保存跟踪骚扰记录的原件与日期

- [女性紧急号码1366信息](https://www.mogef.go.kr/cc/wcc/cc_wcc_f001.do) · 2026-10-09
- [警察厅犯罪风险/现场报告指南](https://www.police.go.kr/www/agency/intro/intro0601.jsp) · 2026-10-09

## RS03 怀疑位置跟踪或账户控制时，使用安全设备求助

- [针对暴力侵害妇女行为的网络咨询](https://www.women1366.kr/?menuno=227) · 2026-10-09

## RS04 借助外部支持，保密制定离开暴力关系的计划

- [女性紧急号码1366信息](https://www.mogef.go.kr/cc/wcc/cc_wcc_f001.do) · 2026-10-09

## RS05 遭遇性影像或合成影像侵害时联系专业删除支援

- [如何向中央数字性犯罪受害者支持中心申请支持](https://d4u.stop.or.kr/ko/support/content/guide) · 2026-10-09
- [关于通过妇女紧急热线 1366 大田中心为数字性暴力受害者提供支持的信息](https://www.dj1366.or.kr/theme/dj1366/index/guide_03.php) · 2026-10-09
- [警察厅犯罪风险/现场报告指南](https://www.police.go.kr/www/agency/intro/intro0601.jsp) · 2026-10-09

## RS06 分手后先按登记名义列出共同合同清单

- [韩国法律援助公社咨询信息](https://www.klac.or.kr/startingChat.do?channelCd=CHAT) · 2026-10-09

## RS07 为向你倾诉遭遇的人保留选择权与安全联系渠道

- [女性紧急号码1366信息](https://www.mogef.go.kr/cc/wcc/cc_wcc_f001.do) · 2026-10-09
- [如何向儿童权利保障机构举报虐待儿童行为](https://www.ncrc.or.kr/ncrc/cm/cntnts/cntntsView.do?cntntsId=1484&mi=1030) · 2026-10-09

## RS08 怀疑虐待儿童时告知112，不要自行调查

- [如何向儿童权利保障机构举报虐待儿童行为](https://www.ncrc.or.kr/ncrc/cm/cntnts/cntntsView.do?cntntsId=1484&mi=1030) · 2026-10-09

## CA01 把职业心理测试结果转化为两项可尝试的行动

- [使用雇佣劳动部职业心理测试的信息](https://work.go.kr/consltJobCarpa/jobPsyExam/jobPsyExamIntro.do) · 2026-10-09

## CA02 从十份目标岗位招聘公告中找出所需能力

- [韩国就业信息院雇佣24（고용24）服务介绍](https://www.keis.or.kr/keis/ko/conts/101/web.do) · 2026-10-09

## CA03 简历写出你带来的变化，而不只罗列任务

- [雇佣24（고용24） 就业支持和就业信息服务](https://m.work24.go.kr/cm/main.do) · 2026-10-09

## CA04 分别核查招聘邀约中的公司、岗位与金钱要求

- [雇佣24（고용24） 就业支持和就业信息服务](https://m.work24.go.kr/cm/main.do) · 2026-10-09
- [警察厅犯罪风险/现场报告指南](https://www.police.go.kr/www/agency/intro/intro0601.jsp) · 2026-10-09

## CA05 中年转职应在离职前预约咨询

- [雇佣24（고용24） 中年明天中心换职支援服务](https://m.work24.go.kr/wk/u/b/1000/seniorChgJobSptSvc.do) · 2026-10-09

## CA06 职业空档后重返职场，先向새일센터说明自身条件

- [妇女新工作中心就业支持服务](https://saeil.mogef.go.kr/hom/info/service.do) · 2026-10-09

## CA07 求职时间延长时咨询国民就业支援制度的适用类型

- [就业福利加中心2026年国民就业支援制度信息](https://www.work.go.kr/gimcheon/newsPlace/prNewsData/prNewsDataDetail.do?articleSeqno=150544&pageIndex=1&searchKey=&searchWord=) · 2026-10-09

## CA08 比较录用邀约时同时考虑年薪、时间与可持续性

- [雇佣24（고용24） 就业支持和就业信息服务](https://m.work24.go.kr/cm/main.do) · 2026-10-09

## ED01 选择大学时同时比较专业课程与生活总成本

- [大学信息 搜索大学/系公告信息](https://m.academyinfo.go.kr/index.do) · 2026-10-09
- [大学信息公布内容及使用指南](https://m.academyinfo.go.kr/intro/intro0300/intro.do) · 2026-10-09

## ED02 分别确认国家奖学金申请、文件与家庭成员同意

- [韩国奖学财团国家奖学金I类申请信息](https://www.kosaf.go.kr/ko/scholar.do?pg=scholarship05_12_01_01) · 2026-10-09

## ED03 助学贷款要区分申请、实际放款及两种还款方式

- [2026年第二学期学生贷款主要信息](https://www.kosaf.go.kr/ko/tuition.do?pg=tuition14) · 2026-10-09
- [韩国奖学财团学生贷款信息和还款支持](https://www.kosaf.go.kr/ko/tuition.do?pg=tuition_main&platform=app) · 2026-10-09

## ED04 确认上课时间与分配条件后再申请国家勤工助学

- [韩国奖学财团国家工作奖学金简介](https://www.kosaf.go.kr/ko/scholar.do?pg=scholarship05_04_02p) · 2026-10-09

## ED05 把校内外奖学金分为学费支持与生活费支持

- [韩国奖学财团的学生贷款重复防止系统](https://www.kosaf.go.kr/ko/tuition.do?pg=tuition11_01_01) · 2026-10-09

## ED06 休学或转专业前计算毕业前剩余学期和费用

- [大学信息公布内容及使用指南](https://m.academyinfo.go.kr/intro/intro0300/intro.do) · 2026-10-09

## ED07 提前使用大学就业中心，不要等临近毕业才集中准备

- [雇佣劳动部大学Job Plus中心运营](https://www.moel.go.kr/policyitrd/policyItrdView.do?policy_itrd_sn=381) · 2026-10-09
- [雇佣24（고용24） 就业支持和就业信息服务](https://m.work24.go.kr/cm/main.do) · 2026-10-09

## ED08 在온통청년查询大学之外的出路与地区支持

- [翁通青少年政策、青少年中心和咨询服务介绍](https://www.youthcenter.go.kr/youthIntro/introduce/introAbout) · 2026-10-09

## MS01 兵役判定检查先准备对应疾病所需的文件

- [兵务厅（병무청） 兵役 判定检验流程及需要携带什么](https://www.mma.go.kr/seoul/contents.do?mc=mma0000975) · 2026-10-09

## MS02 区分已确认与未确定事项，规划入伍和学校休学

- [兵务厅（병무청） 在校生申请入伍须知](https://www.mma.go.kr/contents.do?mc=usr0000176) · 2026-10-09
- [兵务厅（병무청） 历史变更者的处理](https://www.mma.go.kr/seoul/contents.do?mc=usr0000175) · 2026-10-09

## MS03 通过兵役生涯规划把军事专业与个人专业、经历相连

- [兵务厅（병무청） 兵役职业规划咨询申请流程](https://www.mma.go.kr/contents.do?mc=mma0002535) · 2026-10-09

## MS04 依据官方说明从最低必要范围准备入伍用品

- [兵务厅（병무청）入伍指南](https://www.mma.go.kr/seoul/contents.do?mc=mma0000739) · 2026-10-09

## MS05 同时确认军人“明日准备储蓄”的资格、缴存与到期文件

- [国防部士兵明天准备储蓄](https://www.mnd.go.kr/mbshome/mbs/mnd/subview.jsp?id=mnd_011302000000) · 2026-10-09
- [兵务厅（병무청） 社会服务人员明天军事准备节省信息](https://www.mma.go.kr/board/boardView.do?gesipan_id=2&gsgeul_no=1518779) · 2026-10-09

## MS06 了解军营暴力及申诉问题的外部举报、咨询渠道

- [国防部士兵福利指南：防务求助热线1303](https://www.mnd.go.kr/user/mnd/upload/pblictn/PBLICTNEBOOK_202504141105046620.pdf) · 2026-10-09
- [国家人权委员会军事权利咨询和报告指南](https://humanrights.go.kr/base/board/read?boardManagementNo=9&boardNo=7610296&menuLevel=3&menuNo=91) · 2026-10-09

## MS07 入伍和退伍时重新协调助学贷款还款与复学时间

- [韩国奖学财团兵役期间利息减免常见问题解答](https://www.kosaf.go.kr/ko/tuitionnf.do?pg=tuition05_05_04) · 2026-10-09
- [兵务厅（병무청）入伍指南](https://www.mma.go.kr/seoul/contents.do?mc=mma0000739) · 2026-10-09

## MS08 先确认所属部队与训练类型，再查看预备军日程

- [预备军网站常见问题解答](https://yebigun1.mil.kr/dmobis/rfh/rgt/library/02_question.jsp) · 2026-10-09

## TR01 付款买机票前确认护照和入境、转机要求

- [外交部护照补发指南](https://www.passport.go.kr/home/kor/contents.do?menuPos=6) · 2026-10-09
- [外交部境外安全旅行注意事项](https://www.0404.go.kr/bbs/safetyNtc/ATC0000000009537/detail) · 2026-10-09

## TR02 预订时及出发前再次确认旅行警示

- [外交部境外安全旅行注意事项](https://www.0404.go.kr/bbs/safetyNtc/ATC0000000009537/detail) · 2026-10-09
- [外交部领事安全呼叫中心的使用范围和支持](https://0404.go.kr/bbs/bbsPst/MST0000000000039/ATC0000000048212/detail) · 2026-10-09

## TR03 海外保险先看旅行目的与保障除外责任

- [外交部境外安全旅行指南：出发前准备](https://www.0404.go.kr/files/download/FILE_000000000100727/1) · 2026-10-09

## TR04 分散保存联系信息，应对护照或手机遗失

- [外交部境外安全旅行指南：出发前准备](https://www.0404.go.kr/files/download/FILE_000000000100727/1) · 2026-10-09
- [外交部领事安全呼叫中心使用及支持范围](https://0404.go.kr/bbs/bbsPst/MST0000000000039/ATC0000000048212/detail) · 2026-10-09

## TR05 尚有兵役义务时，另行确认出国旅行许可

- [兵务厅（병무청） 境外旅行证短期旅行标准](https://www.mma.go.kr/contents.do?mc=mma0000787) · 2026-10-09

## TR06 打工度假同时确认允许的工作范围与初期生活费

- [海外同胞办公室工作假期信息中心国家特定信息](https://whic.mofa.go.kr/whic/nation/info.jsp?boardNo=100013) · 2026-10-09

## TR07 留学分别审查学校录取与中介合同

- [韩国消费者院留学项目押金纠纷案](https://www.kca.go.kr/odr/bj/br/osBjDecisionExamDetW.do?brdId=00000007&dataStts=Y&seq=1000914152) · 2026-10-09

## TR08 长期海外预算要留出取消、回国与汇率变化的余量

- [轻松查找生活法律信息政府资助国际学生选择指南](https://www.easylaw.go.kr/CSP/OnhunqueansInfoRetrieve.laf?onhunqnaAstSeq=89&onhunqueSeq=3583) · 2026-10-09

## TR09 分清中国领事自愿登记与韩国居留登记

- [韩国驻华大使馆：在外国民登记与回国申报说明](https://overseas.mofa.go.kr/cn-ko/brd/m_1251/view.do?seq=1305771) · 2026-10-09

## TR10 返回韩国前列出携入物品申报与恢复当地生活清单

- [釜山海关总部海关旅客随身物品清关](https://www2.customs.go.kr/busan/cm/cntnts/cntntsView.do?cntntsId=829&mi=7139) · 2026-10-09
- [关于在国外登记、变更国籍以及回国申报的信息](https://0404.go.kr/bbs/embsyNtc/2018/detail?ntnCd=295) · 2026-10-09

## RC01 资金中断时先列出未来4周的基本生存支出

- [健康福利咨询中心 129 咨询信息](https://www.129.go.kr/counsel/counsel01.do) · 2026-10-09
- [韩国普惠金融院官方咨询信息](https://www.kinfa.or.kr/) · 2026-10-09

## RC02 出现还款困难迹象时，在逾期前咨询

- [政府政策每周债务调整支持信息](https://gonggam.korea.kr/newsContentView.es?b_list=9&code_cd=011900%2A%2A%2A%2A&content=NC002&mid=a12502000000&nPage=89&news_id=ed987ae4-89fd-4b4a-87ee-33682a9b1c04&section_id=) · 2026-10-09
- [韩国普惠金融院官方咨询信息](https://www.kinfa.or.kr/) · 2026-10-09

## RC03 水电等公共费用分别核对减免资格与欠费咨询

- [生活法律信息一目了然 基本生活保障 公用事业费用减免](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=3&cnpClsNo=1&csmSeq=1533&popMenu=ov) · 2026-10-09

## RC04 把支持申请的受理编号与补交期限集中保存

- [健康福利咨询中心 129 咨询信息](https://www.129.go.kr/counsel/counsel01.do) · 2026-10-09

## RC05 遭遇违法催收或高利贷时保留证据并联系公共支援

- [金融服务委员会为非法私人融资受害者提供支持的信息](https://fsc.go.kr/po010101/87620?curPage=8&srchBeginDt=&srchCtgry=&srchEndDt=&srchKey=&srchText=) · 2026-10-09
- [警察厅犯罪风险/现场报告指南](https://www.police.go.kr/www/agency/intro/intro0601.jsp) · 2026-10-09

## RC06 债务难以承担时比较咨询债务调整、个人重整与破产

- [轻松查找生活法资讯 个人康复理念及申请资质](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=1&cciNo=1&cnpClsNo=1&csmSeq=1286) · 2026-10-09
- [韩国法律援助公社咨询信息](https://www.klac.or.kr/startingChat.do?channelCd=CHAT) · 2026-10-09
- [政府政策每周债务调整支持信息](https://gonggam.korea.kr/newsContentView.es?b_list=9&code_cd=011900%2A%2A%2A%2A&content=NC002&mid=a12502000000&nPage=89&news_id=ed987ae4-89fd-4b4a-87ee-33682a9b1c04&section_id=) · 2026-10-09

## RC07 食物开支不足时询问能否使用食物银行或食物市场

- [国家食品银行使用程序和选择标准](https://www.foodbank1377.org/guide/useInfo.do) · 2026-10-09
- [健康福利咨询中心 129 咨询信息](https://www.129.go.kr/counsel/counsel01.do) · 2026-10-09

## RC08 恢复计划衔接债务、就业与福利负责人，并每周更新

- [韩国普惠金融院官方咨询信息](https://www.kinfa.or.kr/) · 2026-10-09
- [雇佣24（고용24） 就业支持和就业信息服务](https://m.work24.go.kr/cm/main.do) · 2026-10-09

## CM01 购买装备前先体验或租借尝试新爱好

- [如何使用GongNuri公共资源预订](https://www.eshare.go.kr/UserPortal/Upc/56/contents.do) · 2026-10-09

## CM02 志愿服务先申请附近的短时活动

- [韩国中央志愿者中心志愿者参与信息](https://www.v1365.or.kr/participation/volunteer) · 2026-10-09

## CM03 按实际使用时段与预约规则选择公共体育设施

- [如何使用GongNuri公共资源预订](https://www.eshare.go.kr/UserPortal/Upc/56/contents.do) · 2026-10-09

## CM04 参观博物馆同时确认展览、讲解与预约

- [国立中央博物馆参观及教育项目预约信息](https://www.museum.go.kr/MUSEUM/contents/M0104090000.do) · 2026-10-09

## CM05 徒步先选适合体力的路线，不必追逐著名山顶

- [国家公园管理局步道评级信息](https://www.knps.or.kr/front/portal/visit/visitCourseMain.do?menuNo=7020006&parkId=120000) · 2026-10-09
- [国家公园管理局北汉山探索路线和入场时间信息](https://www.knps.or.kr/front/portal/visit/visitCourseSubMain.do?menuNo=8000739&parkId=122400&parkNavGb=park) · 2026-10-09

## CM06 一次确认文化누리卡的资格、合作商户与使用期限

- [2026年文化努里卡发行信息](https://www.mnuri.kr/munhwa/cardIssueGuide.do) · 2026-10-09

## CM07 有学习意愿时查看当地终身教育券公告

- [终身教育券分地区公告及使用指南](https://edu.lllcard.kr/main) · 2026-10-09

## CM08 用可承担的小约定反复维持人际关系

- [性别平等和家庭部家庭中心支援项目](https://www.mogef.go.kr/sp/fam/sp_fam_f003.do) · 2026-10-09
- [家庭中心商业和家庭咨询指南](https://seocho.familynet.or.kr/web/lay1/S1T296C337/contents.do) · 2026-10-09

## LC01 签字前明确合同当事人与承诺范围

- [轻松查找生活法律信息：产品购买合同等](https://easylaw.go.kr/CSP/CSP/CnpClsMain.laf?ccfNo=1&cciNo=1&cnpClsNo=1&csmSeq=669&popMenu=ov) · 2026-10-09

## LC02 按日期整理纠纷记录与证据

- [轻松查找生活法律信息：提起诉讼前的准备](https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=568&popMenu=ov) · 2026-10-09

## LC03 内容证明邮寄文件中具体写明要求与履行期限

- [轻松查找生活法律信息：提起诉讼前的准备](https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=568&popMenu=ov) · 2026-10-09

## LC04 先确认请求对象与法律文书送达地址

- [轻松查找生活法律信息：付款单](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=3&cnpClsNo=1&csmSeq=568) · 2026-10-09

## LC05 在支付命令与诉讼之间选择适合的程序

- [轻松查找生活法律信息：付款单](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=3&cnpClsNo=1&csmSeq=568) · 2026-10-09

## LC06 希望维持关系的纠纷，把调解方案落实为金额和时间表

- [易于查找的生活法律信息：民事调解](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=5&cciNo=1&cnpClsNo=3&csmSeq=669) · 2026-10-09

## LC07 收到法院文书当天就确认期限

- [轻松查找生活法律信息：民事诉讼程序](https://easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=6&cciNo=1&cnpClsNo=1&csmSeq=538&popMenu=ov) · 2026-10-09

## LC08 分别计算胜诉可能性与实际收回款项的可能性

- [轻松查找有关现行法律法规的信息：强制执行金钱债权](https://easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=4&cciNo=7&cnpClsNo=1&csmSeq=272&menuType=cnpcls&popMenu=ov) · 2026-10-09

## LC09 高度担心对方处分财产时，先咨询保全措施

- [轻松查找现行法律信息：申请临时扣押的要求](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=294&popMenu=ov) · 2026-10-09

## LC10 同时确认律师委托范围与全部诉讼费用

- [韩国法律援助公团法律支援团：咨询和诉讼代理指南](https://www.klac.or.kr/pil/faq-boards) · 2026-10-09
- [易于查找的生活法律信息：民事诉讼程序](https://easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=6&cciNo=1&cnpClsNo=1&csmSeq=538&popMenu=ov) · 2026-10-09

## LR01 录音前确认自己是否为谈话当事人

- [易于查找的生活方式法律信息：确保客户服务代理的证据](https://easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=3&cnpClsNo=2&csmSeq=1407&popMenu=ov) · 2026-10-09

## LR02 公开揭露前区分事实、意见与个人信息

- [易于查找的法律信息：网络诽谤](https://www.easylaw.go.kr/CSP/common/CnpClsMain.laf?ccfNo=1&cciNo=1&cnpClsNo=2&csmSeq=293&popMenu=ov) · 2026-10-09

## LR03 不要使用拾得物，移交时保留记录

- [轻松查找生活法律信息：获取手机等丢失物品](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=3&cciNo=1&cnpClsNo=1&csmSeq=1650&popMenu=ov) · 2026-10-09

## LR04 签署担保前计算可能损失的最大金额

- [轻松查找生活法律资讯：担保人保护特别法](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=4&cciNo=1&cnpClsNo=4&csmSeq=1209&popMenu=ov) · 2026-10-09

## LR05 私人借贷也要留下还款计划与转账依据

- [易于查找的法律信息：金融交易和追债](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=1&cciNo=1&cnpClsNo=2&csmSeq=272&popMenu=ov) · 2026-10-09

## LR06 用时间记录与调解处理楼上楼下噪声，避免报复

- [轻松查找生活法律资讯：楼层间噪音纠纷](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=1&cciNo=1&cnpClsNo=1&csmSeq=1409&popMenu=ov) · 2026-10-09

## LR07 遛狗前检查安全措施与事故责任

- [易于查找的生活方式法律信息：携带宠物外出](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=2&cnpClsNo=1&csmSeq=1809) · 2026-10-09

## LR08 交通事故现场先履行救助与提供身份信息的义务

- [轻松查找生活法律法规信息：发生交通事故时该怎么办](https://easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=4&cciNo=1&cnpClsNo=1&csmSeq=684&popMenu=ov) · 2026-10-09

## SB01 分别确认经营主体登记与行业许可

- [国税厅：申请商业登记](https://sc.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7777&mi=2444) · 2026-10-09
- [轻松查找生活方式法律信息：按行业分类的商业报告/登记](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=3&cciNo=2&cnpClsNo=2&csmSeq=633&popMenu=ov) · 2026-10-09

## SB02 在职做副业时先核对就业规则与工作冲突

- [雇佣劳动部：关于同时就业限制及就业规则的咨询](https://1350.moel.go.kr/rtmview.do?id=1000270037) · 2026-10-09

## SB03 外包合同中约定验收标准与额外修改费用

- [文化体育旅游部：版权转让及许可标准协议](https://www.mcst.go.kr/site/s_notice/press/pressView.jsp?pCurrent=&pMenuCD=0302000000&pSeq=13855) · 2026-10-09

## SB04 分别约定制作费用与著作权转让范围

- [文化体育旅游部：版权转让及许可标准协议](https://www.mcst.go.kr/site/s_notice/press/pressView.jsp?pCurrent=&pMenuCD=0302000000&pSeq=13855) · 2026-10-09

## SB05 把经营支出支付工具与生活费分开

- [IRS：商业信用卡概述](https://ems.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7799&mi=2475) · 2026-10-09

## SB06 确认已预扣税款的副业收入最终应纳税额

- [国税局：填写报告和预扣税结算](https://s.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=239072&mi=41095) · 2026-10-09

## SB07 确定商号前查询商标与指定商品

- [知识产权局：知识产权信息检索指南](https://www.kipo.go.kr/kcall/faqRead.do?curMenuCd=SCD0300081&pgmId=PGM0000014&pgmSeq=106) · 2026-10-09

## SB08 合伙创业前将出资、权限与退出条件写成文件

- [轻松查找有关现行法律法规的信息：签订合伙协议](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=633&menuType=cnpcls&popMenu=ov) · 2026-10-09

## BO01 签店铺租约前确认该地点允许开展的营业活动

- [轻松查找生活法律资讯：餐厅商店合同](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=2&cnpClsNo=1&csmSeq=839&popMenu=ov) · 2026-10-09
- [轻松查找生活方式法律信息：按行业分类的商业报告/登记](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=3&cciNo=2&cnpClsNo=2&csmSeq=633&popMenu=ov) · 2026-10-09

## BO02 加盟合同同时审查信息披露书与实际成本

- [轻松查找生活法律信息：提供附属机构信息披露表](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=3&csmSeq=647&popMenu=ov) · 2026-10-09

## BO03 雇人时根据实际工作方式判断关系，而不只看合同名称

- [就业劳动部：自由职业者就业及社会保险咨询](https://1350.moel.go.kr/rtmview.do?id=1000300920) · 2026-10-09

## BO04 每月同时完成工资核算与工资明细单交付

- [就业劳动部：检查基本劳动令和工资文件](https://www.moel.go.kr/local/seoulgwanak/news/notice/noticeView.do?bbs_seq=20250600787) · 2026-10-09

## BO05 非全日制员工也要分别核查各项社会保险适用性

- [就业劳动部：自由职业者就业及社会保险咨询](https://1350.moel.go.kr/rtmview.do?id=1000300920) · 2026-10-09

## BO06 把销售到账款中的税款份额单独管理

- [国家税务局：增值税概述](https://ems.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7693&mi=2272) · 2026-10-09

## BO07 在网络销售页面显示交易条件与责任主体

- [国家法令信息中心：提供邮购交易条件信息](https://law.go.kr/lsLawLinkInfo.do?chrClsCd=010202&lsJoLnkSeq=1013449467) · 2026-10-09

## BO08 停止营业时分别处理税务、员工与合同事项

- [国税厅：停业或歇业报告](https://sc.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7780&mi=2447) · 2026-10-09

## DP01 为每项注册信息写明收集理由与保存期限

- [易于查找的生活方式法律信息以及个人信息的收集和使用](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=1&cnpClsNo=1&csmSeq=1257&popMenu=ov) · 2026-10-09

## DP02 让隐私政策与实际数据流一致

- [个人信息保护委员会·个人信息处理政策制定指南（2026年4月）](https://pipc.go.kr/np/cop/bbs/selectBoardArticle.do?bbsId=BS217&mCode=D010030030&nttId=12018) · 2026-10-09

## DP03 区分外包及SaaS合同中的个人信息处理角色

- [轻松查找生活法律信息以及个人信息的提供和委托](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=2&csmSeq=1257&popMenu=ov) · 2026-10-09

## DP04 提前制作个人信息事故通知与报告判断表

- [轻松查找有关个人信息泄露时的生活法律和措施的信息](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=2&cnpClsNo=3&csmSeq=1257&popMenu=ov) · 2026-10-09
- [个人信息保护委员会·个人信息泄露等事故应对手册（2026.9.）](https://pipc.go.kr/np/cop/bbs/selectBoardArticle.do?bbsId=BS217&mCode=D010030030&nttId=12465) · 2026-10-09

## DP05 确认海外云和AI API的数据出境条件

- [个人信息保护委员会/个人信息保护法修正实施指南](https://pipc.go.kr/np/cop/bbs/selectBoardArticle.do?bbsId=BS074&mCode=C020010000&nttId=9233) · 2026-10-09

## DP06 把注销账户及保存期届满落实为实际删除操作

- [易于查找的生活方式法律信息和个人信息的销毁](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=2&cnpClsNo=3&csmSeq=1257&popMenu=ov) · 2026-10-09

## DP07 平台上线前整理卖家角色与资金流向

- [金融委员会/平台对电子支付代理业务的说明](https://www.fsc.go.kr/no010102/82523?curPage=15&srchBeginDt=&srchCtgry=&srchEndDt=&srchKey=&srchText=) · 2026-10-09
- [国家法令信息中心：提供有关邮购交易条款和条件的信息](https://law.go.kr/lsLawLinkInfo.do?chrClsCd=010202&lsJoLnkSeq=1013449467) · 2026-10-09

## DP08 让用户在付款前查看订阅价格与解约条件

- [国家法令信息中心：提供邮购交易条件信息](https://law.go.kr/lsLawLinkInfo.do?chrClsCd=010202&lsJoLnkSeq=1013449467) · 2026-10-09

## DP09 发布前整理开源软件与内容的使用条件

- [韩国版权委员会OLIS·开源许可证介绍](https://www.olis.or.kr/license/introduction.do) · 2026-10-09
- [文化体育旅游部：版权转让及许可标准协议](https://www.mcst.go.kr/site/s_notice/press/pressView.jsp?pCurrent=&pMenuCD=0302000000&pSeq=13855) · 2026-10-09

## DP10 先确认外部数据采集与安全检查的许可范围

- [国家法令信息中心·最高法院关于信息和通信网络入侵的判例](https://law.go.kr/LSW/precInfoP.do?mode=0&precSeq=599601) · 2026-10-09
- [易于查找的生活方式法律信息和个人信息的概念](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?csmSeq=1257&ccfNo=1&cciNo=1&cnpClsNo=1) · 2026-10-09

## IN01 逐项确认丧葬费用并确定家庭联络人

- [轻松查找有关生活法律和殡仪馆的信息](https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=1&cciNo=2&cnpClsNo=1&csmSeq=1811&popMenu=ov) · 2026-10-09

## IN02 一起整理死亡申报与所需证明的申领

- [轻松查找有关现行法律以及如何报告死亡的信息](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=6&cciNo=1&cnpClsNo=1&csmSeq=707&popMenu=ov) · 2026-10-09

## IN03 除“安心继承”查询外，另列潜在债务清单

- [政府24（정부24） · 包括死者及被监护人在内的财产查询一体化处理申请表](https://www.gov.kr/mw/AA020InfoCappView.do?CappBizCD=17400000001&tp_seq=02) · 2026-10-09
- [轻松查找生活方式法律信息 · 继承批准/放弃决定](https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=4&cciNo=1&cnpClsNo=1&csmSeq=255) · 2026-10-09

## IN04 在期限内准备继承承认、限定承认或放弃的决定

- [轻松查找生活方式法律信息 · 继承批准/放弃决定](https://easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=4&cciNo=1&cnpClsNo=1&csmSeq=255) · 2026-10-09

## IN05 作出继承决定前先停止处分逝者财产

- [生活法律信息轻松查找·继承审批简单](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=4&cciNo=2&cnpClsNo=1&csmSeq=255) · 2026-10-09

## IN06 确认未成年继承人的利益关系与代理权限

- [轻松查找有关生活法的信息·共同继承人的继承财产分割](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=3&cciNo=3&cnpClsNo=2&csmSeq=255) · 2026-10-09

## IN07 区分遗产分割协议与债务、税务程序

- [轻松查找有关生活法的信息·共同继承人的继承财产分割](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=3&cciNo=3&cnpClsNo=2&csmSeq=255) · 2026-10-09

## IN08 遗属年金须单独确认申请程序

- [国民年金（국민연금）法人·遗属年金](https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0072M0.do?menuId=MN24001121) · 2026-10-09

## CI01 消费者纠纷应把诉求与证据整理后再咨询

- [轻松查找生活方式法律信息并与企业主咨询](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=3&cciNo=1&cnpClsNo=1&csmSeq=669) · 2026-10-09
- [轻松查找生活法律信息·利用韩国消费者院](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=4&cciNo=1&cnpClsNo=3&csmSeq=669&popMenu=ov) · 2026-10-09

## CI02 预付服务先看未使用余额，再看折扣率

- [轻松查找有关生活法律和信用卡分期付款交易的信息](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=3&csmSeq=2984&popMenu=ov) · 2026-10-09

## CI03 修车前拿报价，修车后拿明细

- [轻松查找生活方式法律信息 · 修理损坏的汽车](https://m.easylaw.go.kr/MOB/CsmInfoRetrieve.laf?ccfNo=2&cciNo=3&cnpClsNo=1&csmSeq=675) · 2026-10-09

## CI04 确认个人与团体实损医疗保险的重复投保和暂停条件

- [金融委员会·暂停个人及团体实际损失保险重复投保制度](https://www.fsc.go.kr/no010101/79180) · 2026-10-09

## CI05 更换保险前比较现有保障与新合同条件

- [轻松找到有关生活法律的信息以及购买保险时需要检查的事项](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=2&csmSeq=2588&popMenu=ov) · 2026-10-09
- [轻松查找生活法律信息 · 投保人的权利和义务](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=4&csmSeq=2588&popMenu=ov) · 2026-10-09

## CI06 亲自核对保险投保书中的问题与回答

- [轻松找到有关生活法律的信息以及购买保险时需要检查的事项](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=2&csmSeq=2588&popMenu=ov) · 2026-10-09
- [轻松查找生活法律信息 · 投保人的权利和义务](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=2&cciNo=1&cnpClsNo=4&csmSeq=2588&popMenu=ov) · 2026-10-09

## CI07 取得保险拒赔的书面理由并整理争议点

- [轻松查找生活法律资讯·保险纠纷调解解决](https://www.easylaw.go.kr/CSP/CnpClsMainBtr.laf?ccfNo=5&cciNo=1&cnpClsNo=1&csmSeq=2588&popMenu=ov) · 2026-10-09

## CI08 境外银行卡交易出问题时先收集争议申诉材料

- [韩国消费者院·政策简报·海外交易退款服务信息](https://www.korea.kr/news/policyNewsView.do?newsId=148845877) · 2026-10-09

## HM01 先计算房价之外的费用与贷款还款额

- [轻松查找生活法律信息 · 准备资金购买房地产](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=3&cnpClsNo=1&csmSeq=649&popMenu=ov) · 2026-10-09
- [轻松查找生活法律信息·不动产购置税](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=4&cciNo=3&cnpClsNo=2&csmSeq=649&popMenu=ov) · 2026-10-09

## HM02 一起核查拟购房屋的登记、建筑物台账与现场

- [轻松查找有关生活法律和房地产登记的信息](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=1&cnpClsNo=2&csmSeq=649&popMenu=ov) · 2026-10-09
- [轻松查找生活法律信息、土地登记、建筑登记等。](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=1&cnpClsNo=3&csmSeq=649&popMenu=ov) · 2026-10-09

## HM03 按具体地块确认土地交易许可与使用义务

- [轻松查找有关生活法律和土地交易合同许可证的信息。](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=4&cnpClsNo=1&csmSeq=649&popMenu=ov) · 2026-10-09

## HM04 提前约定无法取得贷款时如何处理合同

- [轻松查找有关生活法律和撰写房地产销售合同的信息](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=2&cnpClsNo=1&csmSeq=649&popMenu=ov) · 2026-10-09

## HM05 同时核对尾款支付、权利清理与登记文件

- [轻松查找生活法律信息·首付、临时付款、余款支付](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=2&cnpClsNo=2&csmSeq=649&popMenu=ov) · 2026-10-09
- [轻松查找有关生活法律和房地产登记的信息](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=1&cnpClsNo=2&csmSeq=649&popMenu=ov) · 2026-10-09

## HM06 用照片和书面约定确认瑕疵、保留设备及交付状态

- [轻松查找有关生活法律和撰写房地产销售合同的信息](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=2&cnpClsNo=1&csmSeq=649&popMenu=ov) · 2026-10-09
- [轻松查找生活法律信息、土地登记、建筑登记等。](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=1&cnpClsNo=3&csmSeq=649&popMenu=ov) · 2026-10-09

## HM07 分别管理取得税、交易申报与登记日程

- [轻松查找生活法律信息·不动产购置税](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=4&cciNo=3&cnpClsNo=2&csmSeq=649&popMenu=ov) · 2026-10-09
- [轻松查找生活法律信息·首付、临时付款、余款支付](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=2&cnpClsNo=2&csmSeq=649&popMenu=ov) · 2026-10-09

## HM08 明确搬家报价的工作范围与破损确认方式

- [轻松查找生活法律信息·选择搬家公司](https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=3&cciNo=2&cnpClsNo=1&csmSeq=666&menuType=cnpcls&popMenu=ov) · 2026-10-09
