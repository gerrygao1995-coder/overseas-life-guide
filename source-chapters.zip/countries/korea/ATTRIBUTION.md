# 来源、署名与改动

- 思路原作：[高性价比人生指南 / HowToLiveBetter](https://github.com/eternity4719/HowToLiveBetter)。作者与贡献者：eternity4719/HowToLiveBetter。
- 本卷直接底稿：[gerrygao1995-coder/better-life-korea — 대한민국 생활 치트키](https://github.com/gerrygao1995-coder/better-life-korea)，2026-10-09本地完整版本，36章274条。
- 原内容许可：[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。原代码许可：[MIT](LICENSE-CODE)。[源署名文件原样保存](ORIGIN/ATTRIBUTION.md)。

韩国版是非官方本地化与扩展，不是原作全部条目的同步或翻译。它重新选择274条建议，按韩国法律、公共服务和生活情境重新编写内容，使用“官方指引／制度与法律／实用判断”分类，而非原作A/B/C等级。韩国版说明未复制原作代码或图像。

本合集于2026-10-09把韩国版机器辅助翻译成简体中文，逐条修订标题，统一术语，修正发现的电话号码、否定及重点条款误译；按用户要求进一步改写为在韩国的中国读者适配版，增加国籍、永居、签证、游客分支、替代行动及官方身份资料。保留原ID、原出处和基准版本，读者可在ORIGIN核对原文。增加的身份说明单独标注来源与核对日期。

原作及韩国源项目作者未对本合集进行正式审核、授权背书或保证。再分发须保留署名、许可链接和改动说明。第三方外链内容、标志与图片仍适用各权利人的条件。
