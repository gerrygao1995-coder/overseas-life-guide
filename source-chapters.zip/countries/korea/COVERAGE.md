# 原作主题与韩国底稿、本次适配的对应关系

韩国底稿把原作34个大主题重新组织为36章274条，并不是原作672条的逐条翻译。本表保留主题对应关系；本次改编进一步按中国读者身份调整办理入口。原底稿对应表保存在[ORIGIN](ORIGIN/COVERAGE.ko.md)。

|原作主题|对应章节|韩国底稿的重点|
|---|---|---|
|01 预防过早死亡|[01章](book/chapter-01.md)、[12章](book/chapter-12.md)|体检、戒烟和官方健康指引|
|02 长期健康风险|[11章](book/chapter-11.md)、[12章](book/chapter-12.md)|可调整的生活习惯与例外|
|03 精力管理|[11章](book/chapter-11.md)、[17章](book/chapter-17.md)|健康问题与时间安排分开|
|04 时间管理|[17章](book/chapter-17.md)|不夸大实践建议的研究效果|
|05 资金管理|[04章](book/chapter-04.md)、[09章](book/chapter-09.md)|账户、自动付款、存款保护与反诈|
|06 避免消费陷阱|[09章](book/chapter-09.md)、[16章](book/chapter-16.md)、[31章](book/chapter-31.md)|总成本、退款与保险条件|
|07 资金不足时|[07章](book/chapter-07.md)、[33章](book/chapter-33.md)|公共支持、债务与生计|
|08 法律与财产安全|[20章](book/chapter-20.md)|法院、咨询、证据和执行|
|09 日常法律风险|[21章](book/chapter-21.md)|行为边界与责任|
|10 恋爱与婚姻|[18章](book/chapter-18.md)、[19章](book/chapter-19.md)|协商、共同支出与受害者支持|
|11 技术人员法律风险|[24章](book/chapter-24.md)|数据、著作权与服务责任|
|12 创业与经营|[22章](book/chapter-22.md)、[23章](book/chapter-23.md)|许可、雇佣和税务|
|13 紧急情况|[02章](book/chapter-02.md)、[32章](book/chapter-32.md)|112、119与官方行动指引|
|14 账户与信息安全|[10章](book/chapter-10.md)|身份冒用与网络诈骗|
|15 租赁与住房|[03章](book/chapter-03.md)、[35章](book/chapter-35.md)|全租押金、登记及返还保证|
|16 慢性病|[13章](book/chapter-13.md)|治疗计划与日常管理|
|17 老年家庭成员|[29章](book/chapter-29.md)、[07章](book/chapter-07.md)|长期照护、家庭分工与本人意愿|
|18 育儿成本与制度|[08章](book/chapter-08.md)、[15章](book/chapter-15.md)|申请、可用时间与家庭实际负担|
|19 就业、离职与工伤|[06章](book/chapter-06.md)、[25章](book/chapter-25.md)|雇佣24、工伤机构与劳动程序|
|20 新生儿照护|[14章](book/chapter-14.md)|安全睡眠、喂养与就医|
|21 境外旅行与安全|[28章](book/chapter-28.md)|护照、领事和保险核对|
|22 休息与娱乐|[34章](book/chapter-34.md)、[11章](book/chapter-11.md)|公共设施、人际关系与恢复|
|23 技能学习|[25章](book/chapter-25.md)、[26章](book/chapter-26.md)|实际招聘、培训与学费|
|24 医疗可及性|[01章](book/chapter-01.md)、[13章](book/chapter-13.md)|医保、自费项目和处方信息|
|25 身后手续|[30章](book/chapter-30.md)|葬礼、财产查询与继承选择|
|26 网站与平台运营|[24章](book/chapter-24.md)|个人信息、电商及运营责任|
|27 怀孕与分娩|[14章](book/chapter-14.md)、[08章](book/chapter-08.md)|临床安全和行政申请分开|
|28 外貌与美容治疗|[16章](book/chapter-16.md)|适应证、风险与后续管理|
|29 重大事件之后|[36章](book/chapter-36.md)|安全、治疗、支持及逐步恢复|
|30 在校儿童|[15章](book/chapter-15.md)|健康、学习环境与学校支持|
|31 成年早期职业路径|[25章](book/chapter-25.md)、[26章](book/chapter-26.md)、[27章](book/chapter-27.md)|教育、就业及适用时的兵役|
|32 留学|[28章](book/chapter-28.md)|目的地居留与返回准备|
|33 残疾后的生活|[13章](book/chapter-13.md)、[07章](book/chapter-07.md)|康复、便利措施、支持与自主决定|
|34 家庭用药|[01章](book/chapter-01.md)、[13章](book/chapter-13.md)、[14章](book/chapter-14.md)|成分、重复用药与避免擅自改量|

韩国底稿另强化了全租押金、服兵役与退伍、公共服务查询、12条情境路线和离线阅读。底稿的保存、计算器及EPUB功能仍由原项目提供。

本次适配保留全部274个ID与原来源，并增加中国籍居民、签证者和游客的分支；韩国公民专用制度只作为明确限定的分支保留。地区补助、疾病细节、全部签证例外和个税计算仍需按个案核对。欢迎按[贡献说明](CONTRIBUTING.md)补充官方依据。
