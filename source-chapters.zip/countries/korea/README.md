# 韩国：中国人在海外的高性价比生活指南

**36章 · 274条建议 · 原版306个不同来源网址，并补充中国读者身份依据。**

面向在韩国定居的华人、中国籍永居者、工作／留学等签证持有人，以及短期游客。以用户已有[韩国人生指南](https://github.com/gerrygao1995-coder/better-life-korea)完整成果为底稿，翻译后逐条增加人群判断、资格边界和替代行动，重写了外国租客登记、年金、国际生资助、领事登记与旅行证件等路径。

**[先读：中国读者身份与落地路径](CHINESE-READERS.md)**。韩籍华人与中国籍永居者分开判断；永居、税务居民、工作许可、医保及公民身份不能互换。每条都写明不适用时怎么做，游客无需执行长期居民专用流程。

[阅读说明](INTRO.md) · [30天行动入口](START-HERE.md) · [12条情境路线](PLAYBOOKS.md) · [来源索引](SOURCES.md) · [贡献方法](CONTRIBUTING.md)

源版本为2026-10-09；身份适配来源于同日核对。翻译采用机器辅助初译，并修订全部标题、术语、电话号码、已发现的否定和重点条款误译。原ID、出处和韩文数据保留，可在[ORIGIN](ORIGIN/guide.json)核查。新增适配是明确的编辑改编，不声称原作者审核。

## 全部章节

|章节|条目数|
|---|---:|
|[01 健康与医疗费用](book/chapter-01.md)|6|
|[02 紧急情况与安全](book/chapter-02.md)|6|
|[03 全租、月租与住房](book/chapter-03.md)|6|
|[04 储蓄、债务与金融诈骗](book/chapter-04.md)|6|
|[05 交通与出行费用](book/chapter-05.md)|6|
|[06 就业与劳动权益](book/chapter-06.md)|6|
|[07 福利与养老](book/chapter-07.md)|6|
|[08 家庭与照护](book/chapter-08.md)|6|
|[09 生活成本与消费](book/chapter-09.md)|6|
|[10 数字生活与学习](book/chapter-10.md)|6|
|[11 睡眠、压力与心理健康](book/chapter-11.md)|8|
|[12 饮食、体重与预防习惯](book/chapter-12.md)|10|
|[13 慢性病与残疾](book/chapter-13.md)|8|
|[14 怀孕、分娩与新生儿](book/chapter-14.md)|10|
|[15 儿童青少年健康与学校](book/chapter-15.md)|8|
|[16 外貌、美容治疗与医疗选择](book/chapter-16.md)|6|
|[17 专注、时间与数字生活平衡](book/chapter-17.md)|8|
|[18 恋爱、婚姻与家庭财务约定](book/chapter-18.md)|8|
|[19 分手、暴力与关系安全](book/chapter-19.md)|8|
|[20 合同纠纷与法律应对](book/chapter-20.md)|10|
|[21 日常应遵守的法律](book/chapter-21.md)|8|
|[22 自由职业、副业与创业](book/chapter-22.md)|8|
|[23 店铺经营、雇佣与税务](book/chapter-23.md)|8|
|[24 开发者、平台运营与个人信息](book/chapter-24.md)|10|
|[25 职业规划与再就业](book/chapter-25.md)|8|
|[26 大学、奖学金与青年发展](book/chapter-26.md)|8|
|[27 服兵役与退伍](book/chapter-27.md)|8|
|[28 海外旅行、留学与返回韩国](book/chapter-28.md)|10|
|[29 养老与家庭照护实务](book/chapter-29.md)|8|
|[30 丧亲、继承与葬礼](book/chapter-30.md)|8|
|[31 消费者权益、保险与纠纷](book/chapter-31.md)|8|
|[32 灾害、交通事故与生活安全](book/chapter-32.md)|8|
|[33 资金不足时的恢复计划](book/chapter-33.md)|8|
|[34 兴趣、人际关系与社区生活](book/chapter-34.md)|8|
|[35 买房、贷款与搬家](book/chapter-35.md)|8|
|[36 重大事件后的第一个30天](book/chapter-36.md)|6|

## 读者附件与溯源

- [原作主题对应表](COVERAGE.md)
- [韩国源项目的验证记录直译](VERIFICATION.md)
- [韩国源项目的版本记录直译](SOURCE-CHANGELOG.md)
- [源项目分享材料直译](SHARING.md)
- [中文条目数据](data/guide.zh-CN.json)与[路线数据](data/routes.zh-CN.json)
- [翻译与覆盖报告](translation-report.json)
- [来源及改动说明](ATTRIBUTION.md)、[内容许可](LICENSE-CONTENT.md)、[原MIT代码许可](LICENSE-CODE)

本合集未重新制作韩国源项目的EPUB、计算器或分享图片。这些原有功能可在原项目使用。正文采用CC BY 4.0；源项目代码采用MIT，第三方外链内容仍归各自权利人。原作者与韩国原编者的署名和原许可保存在ORIGIN中。
