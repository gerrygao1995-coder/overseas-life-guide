# 中国人在澳洲的高性价比人生指南 🇦🇺

面向华人定居者、中国籍工作／学生签证者与游客的中文适配版：**40 章、720 条行动**，涵盖健康、住房、工作、金钱、家庭、法律、学习与日常生活。

[先看身份与落地路径](CHINESE-READERS.md) · [从这里开始](START-HERE.md) · [按生活情境找答案](SCENARIOS.md) · [依据与编辑政策](EDITORIAL-POLICY.md) · [来源目录](SOURCES.md)

## 翻译与中国读者适配

本册基于 [Live Better Australia 原项目](https://github.com/gerrygao1995-coder/live-better-australia)，保留 40 章、720 条行动的完整实用内容，并逐条增加适用标签、华人澳洲公民／中国籍 PR／临时签证／中国游客的具体路径，以及不适用时的替代行动。

这里的“定居”不等于“入籍”。中国籍永久居民与澳洲公民分开处理；学习贷款、投票、医保、福利、养老金、税务和购房限制不能用同一个身份标签判断。先读每条的身份路径，再行动。

翻译使用机器辅助，并对标题和专项术语作编辑修订。关键身份来源于 **2026-10-09** 核对；未重新核验原版全部医疗、法律与财务论述，也不是个人资格评估。原版审阅日期仍保留供对照。币种 A$ 为澳元。

本次以 GitHub 可直接阅读的 Markdown 和结构化中文数据交付。原英文[在线阅读器](https://gerrygao1995-coder.github.io/live-better-australia/)仅作为来源版本参考。

<a id="the-full-playbook"></a>

## 全部章节

| 章 | 主题 | 行动数 |
| --- | --- | --- |
| 01 | [紧急情况](book/01-emergencies.md) | 18 |
| 02 | [日常健康](book/02-everyday-health.md) | 18 |
| 03 | [医疗服务与药品](book/03-healthcare-and-medicines.md) | 18 |
| 04 | [心理健康与精力](book/04-mental-health-and-energy.md) | 18 |
| 05 | [日常开支](book/05-everyday-costs.md) | 18 |
| 06 | [租房与买房](book/06-renting-and-buying-a-home.md) | 18 |
| 07 | [银行账户与债务](book/07-banking-and-debt.md) | 18 |
| 08 | [养老金、税务与保险](book/08-super-tax-and-insurance.md) | 18 |
| 09 | [经济困难援助与残障支持](book/09-money-help-and-disability-support.md) | 18 |
| 10 | [劳动权益](book/10-work-rights.md) | 18 |
| 11 | [教育与职业发展](book/11-education-and-career.md) | 18 |
| 12 | [亲密关系与子女](book/12-relationships-and-children.md) | 18 |
| 13 | [老龄照护与丧亲事务](book/13-ageing-and-bereavement.md) | 18 |
| 14 | [消费者权益与法律权利](book/14-consumer-and-legal-rights.md) | 18 |
| 15 | [账户与设备安全](book/15-digital-security.md) | 18 |
| 16 | [创办小企业](book/16-small-business.md) | 18 |
| 17 | [旅行与户外安全](book/17-travel-outdoors.md) | 18 |
| 18 | [时间、注意力与生活事务](book/18-time-attention.md) | 18 |
| 19 | [慢性病管理](book/19-chronic-conditions.md) | 18 |
| 20 | [怀孕与分娩](book/20-pregnancy-and-birth.md) | 18 |
| 21 | [婴儿与幼儿期](book/21-babies-and-early-childhood.md) | 18 |
| 22 | [学龄儿童与青少年](book/22-school-age-and-teenagers.md) | 18 |
| 23 | [残障人士的健康与无障碍服务](book/23-disability-health-and-access.md) | 18 |
| 24 | [外貌、牙科与治疗选择](book/24-appearance-dental-and-treatment-choices.md) | 18 |
| 25 | [交通与养车](book/25-transport-and-car-ownership.md) | 18 |
| 26 | [气候、灾害与抗灾住房](book/26-climate-disasters-and-resilient-homes.md) | 18 |
| 27 | [食品与家庭用品的性价比](book/27-food-and-household-value.md) | 18 |
| 28 | [退休过渡](book/28-retirement-transitions.md) | 18 |
| 29 | [偏远地区生活](book/29-regional-and-remote-living.md) | 18 |
| 30 | [分居与家庭法](book/30-separation-and-family-law.md) | 18 |
| 31 | [日常法律风险与接触警方](book/31-everyday-legal-risks-and-police-contact.md) | 18 |
| 32 | [零工、承包与自雇权益](book/32-gig-work-contracting-and-self-employment-rights.md) | 18 |
| 33 | [年满18岁与选择人生道路](book/33-turning-18-and-choosing-a-path.md) | 18 |
| 34 | [明智消费与避坑](book/34-buying-wisely-and-avoiding-traps.md) | 18 |
| 35 | [人工智能、隐私与数字判断](book/35-ai-privacy.md) | 18 |
| 36 | [搬家与迁居](book/36-moving-home.md) | 18 |
| 37 | [海外工作与留学](book/37-overseas-work-study.md) | 18 |
| 38 | [网站、应用与线上项目](book/38-online-projects.md) | 18 |
| 39 | [人际关系、社区与休闲](book/39-relationships-community.md) | 18 |
| 40 | [应对人生重大变化](book/40-major-life-changes.md) | 18 |

## 阅读附件

- [开始使用](START-HERE.md)与[16 种生活情境](SCENARIOS.md)
- [编辑政策](EDITORIAL-POLICY.md)与[原作主题对应表](SOURCE-MAP.md)
- [来源目录](SOURCES.md)、[贡献说明](CONTRIBUTING.md)、[分享说明](SHARE.md)与[原版更新记录](CHANGELOG.md)
- [中文结构化数据](guide.zh-CN.json)与[翻译完整性报告](TRANSLATION-REPORT.md)

## 原作、署名与许可

原始指南《高性价比人生指南 / HowToLiveBetter》由 eternity4719 及贡献者创作，仓库为 [eternity4719/HowToLiveBetter](https://github.com/eternity4719/HowToLiveBetter)。澳洲版由 Live Better Australia 贡献者独立改写并扩充，本中文版在澳洲版基础上全文翻译并按中国读者身份改编，已作修改。双方署名、修改关系及第三方权利声明见[署名说明中文翻译](ATTRIBUTION.md)与[未经修改的原署名](ORIGIN/ATTRIBUTION.md)。

内容依 [CC BY 4.0](LICENSE) 开放；引用、再分发或改编时请保留原作者和澳洲版署名、提供许可链接并注明修改。原项目代码许可为 [MIT](LICENSE-CODE)。许可证英文原文完整保留，链接的第三方网页不因被引用而重新授权。
