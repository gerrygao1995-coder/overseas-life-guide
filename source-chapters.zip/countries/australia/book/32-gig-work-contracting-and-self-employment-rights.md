# 32. 零工、承包与自雇权益

承包商的每小时报价只是安排的一部分。在决定这项工作是否值得之前，先确定您的地位、责任、实际成本和争议选项。

面向华人澳洲公民、中国籍永久居民、临时签证者及中国游客。每条身份路径须与行动正文一起阅读。

[身份与落地路径](../CHINESE-READERS.md) · [全部章节](../README.md#the-full-playbook) · [从这里开始](../START-HERE.md) · [依据标签](../EDITORIAL-POLICY.md)

- [按实际工作关系判断身份，不只看名称](#au-0559)
- [质疑强制转向承包](#au-0560)
- [单独核查承包人员的养老金缴纳义务](#au-0561)
- [平台停用后立即采取行动](#au-0562)
- [询问有争议的合同条款](#au-0563)
- [为没有人直接支付报酬的工作时间计价](#au-0564)
- [在报价之前写下可交付成果](#au-0565)
- [同意变更的批准方式](#au-0566)
- [使用可以检查的里程碑](#au-0567)
- [确认有权批准工作的人员](#au-0568)
- [尽早阅读取消和终止条款](#au-0569)
- [检查您实际从事的工作的保险](#au-0570)
- [区分客户代垫费用与你收取的服务费](#au-0571)
- [保留交货和验收记录](#au-0572)
- [设置逾期发票处理流程](#au-0573)
- [将安全工作期望纳入预订的一部分](#au-0574)
- [检查是否允许分包](#au-0575)
- [审查该安排是否仍然有效](#au-0576)

---

<a id="au-0559"></a>

## AU-0559 · 按实际工作关系判断身份，不只看名称

**适用标签：受雇权益与签证工作权限分开**

在接受您是承包商的声明之前，请阅读合同并描述工作的实际运作方式。 Fair Work 解释说，根据业务和情况，可以适用不同的法律测试；单独的 ABN 或发票并不是完整的答案。如果书面标签与实际排列相冲突，请寻求建议。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 官方信息免费；量身定制的建议可能需要额外费用。 |
| 潜在价值 | 检查适用权利的更清晰基础。 |
| 具体情境 | 工人和雇主；状态测试取决于相关法律和情况。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：独立承包商](https://www.fairwork.gov.au/find-help-for/independent-contractors)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0560"></a>

## AU-0560 · 质疑强制转向承包

**适用标签：受雇权益与签证工作权限分开**

如果要求离职并为同一工作开具发票，请保留该提议并在同意之前征求建议。公平工作禁止特定的虚假承包行为，包括用于聘请某人作为承包商的某些虚假陈述和解雇威胁。安排是否违法取决于事实；仅改变文书工作并不能解决问题。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费官方信息；咨询费用各不相同。 |
| 潜在价值 | 帮助确定拟议的员工权利损失。 |
| 具体情境 | 工人面临着从雇佣到合同的拟议变更。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：虚假承包](https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0561"></a>

## AU-0561 · 单独核查承包人员的养老金缴纳义务

**适用标签：有澳洲养老金权益者**

询问即使您以其他方式签订合同，该约定是否会产生退休金义务。政府指导意见称，当付款主要是针对您的劳动和技能并且您亲自完成工作时，雇主可能需要支付退休金。结构和其他条件很重要，因此请使用 ATO 指导或建议，而不是假设 ABN 消除该义务。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 有养老金账户时可采用；提取须满足法定释放条件，离境本身不等于可领取。 |
| 中国籍永久居民（PR） | 有账户时可采用；PR 与临时居民离境提取（DASP）不是同一路径。 |
| 中国籍工作／学生等临时签证者 | 符合劳动养老金缴纳条件时核对入账；永久离境后另按 DASP 资格与扣税规则处理。 |
| 中国游客／短期探亲者 | 单纯旅游不会自动产生养老金账户或权益；若过去在澳工作有账户，应单独查询。 |

**不适用时的替代行动：** 无澳洲养老金账户可跳过；曾以临时签证工作者离境后向 ATO 核对 DASP，不能直接把正常退休提取流程套到自己身上。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 官方信息免费；建议可能需要额外费用。 |
| 潜在价值 | 在合同讨论中保留退休金缴款。 |
| 具体情境 | 承包商和租用者；养老金测试与其他一些就业测试不同。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [Business.gov.au：影响合同的法律](https://business.gov.au/people/contractors/laws-affecting-contracts)

**身份边界核对（2026-10-09）：** [临时居民与养老金](https://www.ato.gov.au/individuals-and-families/super-for-individuals-and-families/super/temporary-residents-and-superannuation) · [ATO 对 DASP 条件的说明](https://community.ato.gov.au/s/question/a0JRF000004UuP32AK/p00409356)

---

<a id="au-0562"></a>

## AU-0562 · 平台停用后立即采取行动

**适用标签：受雇权益与签证工作权限分开**

保存停用通知、原因和相关平台消息，然后查看 Fair Work 的员工式工人指南。符合资格的工人可以通过公平工作委员会寻求不公平的停用补救措施，通常在 21 天内；资格和停用的类型。不要假设内部平台上诉会延长外部期限。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 信息免费；可能需要支付申请或咨询费用。 |
| 潜在价值 | 保留寻求正确补救措施的机会。 |
| 具体情境 | 符合资格的类似员工的数字平台工作人员；条件适用。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：像雇员一样的工人](https://www.fairwork.gov.au/find-help-for/regulated-workers/employee-like-workers)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0563"></a>

## AU-0563 · 询问有争议的合同条款

**适用标签：受雇权益与签证工作权限分开**

如果服务合同看起来是片面的，请在寻求建议之前确定确切的措辞、实际效果并进行您想要的更改。官方指南描述了通过争议解决、公平工作委员会或法院的不同审查途径，并附有资格要求。不要因为感觉不公平而简单地忽略某个术语；询问实际适用的法律和补救措施。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 初始信息是免费的；建议和诉讼可能需要额外费用。 |
| 潜在价值 | 合同建议的重点问题。 |
| 具体情境 | 承包商；相关合同、收益和管辖权条件各不相同。 |
| 原条目依据 | 官方／专业指导 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [Business.gov.au：承包商权利和保护](https://business.gov.au/people/contractors/contractor-rights-and-protections)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0564"></a>

## AU-0564 · 为没有人直接支付报酬的工作时间计价

**适用标签：受雇权益与签证工作权限分开**

跟踪代表性的一周，包括找工作、等待、旅行、管理和实际付费任务。在将结果与其他工作进行比较之前减去您确定的工作成本，将税收和个人情况分开以获得适当的建议。使用您自己记录的数据，而不是将其他工人的最佳班次视为典型的收入率。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 对工作选择进行更诚实的比较。 |
| 具体情境 | 零工和独立承包商。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0565"></a>

## AU-0565 · 在报价之前写下可交付成果

**适用标签：受雇权益与签证工作权限分开**

描述您将提供的内容、所需的投入、截止日期以及如何评估完成情况。在接受报价之前，请客户确认假设和排除情况，尤其是在“一些更改”可能意味着工作量截然不同的情况下。将最终商定的版本与合同保留在一起。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 减少付费项目的范围模糊性。 |
| 具体情境 | 自由职业者和承包商引用项目工作。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0566"></a>

## AU-0566 · 同意变更的批准方式

**适用标签：受雇权益与签证工作权限分开**

针对超出商定范围的请求制定流程，包括谁可以批准额外费用以及对时间的任何影响。当变化到来时，描述它并在执行大量额外工作之前获得确认。保持礼貌的关系，同时让双方都能轻松了解其中包含的内容和更改的内容。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 关于无价额外工作的争议减少。 |
| 具体情境 | 处理不断发展的项目的承包商。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0567"></a>

## AU-0567 · 使用可以检查的里程碑

**适用标签：受雇权益与签证工作权限分开**

对于一项较大的工作，提出具有明确产出、审查点和付款日期的阶段，而不是一个模糊的最终期限。确认客户必须提供什么以及如果反馈延迟会发生什么。分阶段的计划并不能保证付款，但它使进展和新出现的问题在积累太多工作之前更容易讨论。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 更早地了解交付和付款问题。 |
| 具体情境 | 规划重大任务的承包商。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0568"></a>

## AU-0568 · 确认有权批准工作的人员

**适用标签：受雇权益与签证工作权限分开**

询问谁可以批准报价、变更和最终接受，并为客户获取正确的法律和账单详细信息。遵循该人或商定渠道的指示，而不是依赖附近某人的随意请求。在继续重大新任务之前，请澄清联系方式的任何变化。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 减少授权和发票方面的混乱。 |
| 具体情境 | 与组织或多个客户联系人合作的承包商。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0569"></a>

## AU-0569 · 尽早阅读取消和终止条款

**适用标签：受雇权益与签证工作权限分开**

在接受工作之前，请检查任何一方如何结束安排、需要什么通知以及已完成的工作、押金和费用会发生什么情况。要求解释不明确的条款，并就不成比例或高风险的义务获取建议。为中断做好计划，而不是将预期的项目持续时间视为有保证的收入。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 对下行风险有更清晰的认识。 |
| 具体情境 | 人们接受独立承包商的聘用。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0570"></a>

## AU-0570 · 检查您实际从事的工作的保险

**适用标签：受雇权益与签证工作权限分开**

向保险公司或顾问描述实际任务、车辆使用、地点、客户和分包安排，然后要求确认相关承保范围和除外情况。不要假设个人政策或平台摘要涵盖了所有事件。将当前保单和续订日期与您的工作记录一起保留。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 对保险缺口有更明智的看法。 |
| 具体情境 | 使用资产或提供服务的零工工人和承包商。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0571"></a>

## AU-0571 · 区分客户代垫费用与你收取的服务费

**适用标签：受雇权益与签证工作权限分开**

商定客户将报销哪些旅行、材料、预订或其他费用以及需要哪些批准或收据。消费前确认限额，并在发票上清楚注明可报销的项目。如果客户更改任务，请重新访问费用协议，而不是假设原始许可涵盖所有新费用。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 关于自付费用的分歧较少。 |
| 具体情境 | 承包商为客户产生费用。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0572"></a>

## AU-0572 · 保留交货和验收记录

**适用标签：受雇权益与签证工作权限分开**

使用商定的渠道记录交付的内容、时间、对象以及任何响应。保存相关版本并审批，不保留超出授权需要的客户信息。如果出现投诉，请针对实际范围和证据做出回应，而不是试图从分散的消息中重建整个项目。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 用于发票和争议讨论的可用记录。 |
| 具体情境 | 承包商交付货物、任务或项目文件。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0573"></a>

## AU-0573 · 设置逾期发票处理流程

**适用标签：受雇权益与签证工作权限分开**

在发送附有发票的事实提醒之前，请检查截止日期、正确的收件人以及任何缺失的批准。商定您的下一个后续日期，并在威胁、追债或采取法律行动之前获取建议。在接受进一步的工作时检查模式，以便未解决的发票不会成为不被注意的日益增长的风险。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 付款后续行动更加一致。 |
| 具体情境 | 承包商管理应收账款。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0574"></a>

## AU-0574 · 将安全工作期望纳入预订的一部分

**适用标签：受雇权益与签证工作权限分开**

在前往现场或送货之前，请询问有关通道、危险、设备的信息，以及如果情况与预订不同时应联系谁。保留相关的安全说明，并通过适当的流程提出问题。当工作无法安全执行时，请寻求适用的监管机构或专业指导，而不是超出您的能力范围即兴发挥。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 为工作的身体条件做好更好的准备。 |
| 具体情境 | 承包商和零工工人前往不熟悉的地点。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0575"></a>

## AU-0575 · 检查是否允许分包

**适用标签：受雇权益与签证工作权限分开**

在要求其他人执行部分工作之前，请审查客户合同、保密义务、所需资格和保险安排。以书面形式同意责任和付款，并就您可能产生的任何就业或其他义务获取建议。如果没有人检查的话，有益的非正式移交仍然可能导致重要的责任悬而未决。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 委派工作时责任更明确。 |
| 具体情境 | 承包商考虑雇用另一名工人。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0576"></a>

## AU-0576 · 审查该安排是否仍然有效

**适用标签：受雇权益与签证工作权限分开**

按照商定的时间间隔，将实际收入、工作量、客户集中度、逾期付款和福利与报价背后的假设进行比较。使用您自己的记录决定是否更改定价、范围、可用性或您接受的工作类型。在结束合同之前讨论合同通知要求，并制定切实可行的过渡计划。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费准备；专业建议可能需要额外费用。 |
| 潜在价值 | 关于继续工作的深思熟虑的决定。 |
| 具体情境 | 自营职业者审查他们当前的承诺。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)
