# 10. 劳动权益

有效的加薪可以从收到你已经欠下的钱开始。确定您的雇佣制度，保留自己的记录，并在出现问题时及时采取行动。

面向华人澳洲公民、中国籍永久居民、临时签证者及中国游客。每条身份路径须与行动正文一起阅读。

[身份与落地路径](../CHINESE-READERS.md) · [全部章节](../README.md#the-full-playbook) · [从这里开始](../START-HERE.md) · [依据标签](../EDITORIAL-POLICY.md)

- [了解哪些薪酬规则适用于您的工作](#au-0163)
- [保留您控制的工资单记录](#au-0164)
- [利用休假来应对家庭暴力](#au-0165)
- [把解雇争议的申请截止日期当作紧急事项](#au-0166)
- [向正确的地点报告工作场所危险](#au-0167)
- [明确双方对“下班时间”的理解](#au-0168)
- [用普通一周的工作安排检验工作邀约](#au-0169)
- [获得重要的书面招聘承诺](#au-0170)
- [参加前检查无偿试用](#au-0171)
- [质疑不明原因的工资扣除](#au-0172)
- [将弹性工作要求纳入可行的提案中](#au-0173)
- [核对薪酬保密规定，不凭猜测](#au-0174)
- [写下一次艰难会议的结果](#au-0175)
- [核算雇主承诺的培训价值与费用](#au-0176)
- [休假前准备有用的工作交接](#au-0177)
- [工作变动时重新检查条件](#au-0178)
- [准备一份离职清单](#au-0179)
- [在问题恶化之前选择工作场所支持](#au-0180)

---

<a id="au-0163"></a>

## AU-0163 · 了解哪些薪酬规则适用于您的工作

**适用标签：受雇权益与签证工作权限分开**

查明适用的行业劳动标准（award）或企业协议、岗位等级和雇佣类型，再把实际职责与排班安排同现行薪酬标准比较。Fair Work 的工具涵盖全国劳动关系体系中的 award。先核对是否适用：许多州公共部门和地方议会雇员，以及西澳（WA）的部分企业（包括个体经营者）适用州制度；根据适用范围指南联系相应机构。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；最初允许 30 分钟。 |
| 潜在价值 | 找出可能的少付工资，并根据其完整条件评估工作机会。 |
| 具体情境 | 雇员;承保范围取决于雇主和司法管辖区。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作制度](https://www.fairwork.gov.au/about-us/workplace-laws/fair-work-system) · [薪酬和条件工具](https://calculate.fairwork.gov.au/)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0164"></a>

## AU-0164 · 保留您控制的工资单记录

**适用标签：受雇权益与签证工作权限分开**

将合同、花名册和工资单保存在工作帐户之外，并记录实际工作时间和休息时间。根据联邦工作场所规则，雇主必须在付款后的一个工作日内提供工资单，并将员工记录保存七年。员工和前员工可以索取他们的记录；提出日期和数字的差异。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；每个发薪日几分钟。 |
| 潜在价值 | 使工资更正和以后的建议变得更容易。 |
| 具体情境 | 受相关联邦记录保存规则管辖的员工；国家系统义务需要单独检查。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [记录保存和工资单](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/record-keeping-pay-slips)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0165"></a>

## AU-0165 · 利用休假来应对家庭暴力

**适用标签：受雇权益与签证工作权限分开**

在动用年假或放弃工作之前，先核对家庭与家内暴力假。按全国就业标准（National Employment Standards），全职、兼职和 casual 雇员每年可用十天带薪假，可立即享有，在受雇周年日重新获得年度额度，未用额度不累积。询问请假、通知、证明和安全处理记录的要求。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 无需申请费；请假需要满足适用的条件。 |
| 潜在价值 | 用于满足安全和实际需求的时间和收入。 |
| 具体情境 | 根据相关法律享有的雇员权利；检查承保范围以及任何其他州或工作场所规定。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [家庭和家庭暴力假](https://www.fairwork.gov.au/leave/family-and-domestic-violence-leave)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0166"></a>

## AU-0166 · 把解雇争议的申请截止日期当作紧急事项

**适用标签：受雇权益与签证工作权限分开**

在可能不公平解雇后立即联系公平工作委员会、您的工会或法律服务机构：国家申请截止日期通常是解雇生效后的 21 天。资格包括六个月的服务，或小企业员工十二个月的服务，以及其他承保范围和行业劳动标准（award）、协议或收入条件。还要检查其他可用的索赔。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 初始信息是免费的；可能需要支付申请费和咨询费。 |
| 潜在价值 | 保留寻求补救的机会。 |
| 具体情境 | 雇员;国家系统声明和其他声明类型都有自己的规则。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：不公平解雇](https://www.fairwork.gov.au/ending-employment/help-with-termination/unfair-dismissal) · [法律援助 NSW：选择驳回索赔](https://www.legalaid.nsw.gov.au/my-problem-is-about/my-job/termination-of-employment/how-do-i-choose)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0167"></a>

## AU-0167 · 向正确的地点报告工作场所危险

**适用标签：受雇权益与签证工作权限分开**

记录危险并在安全的情况下通过工作场所安全流程提出。使用澳大利亚安全工作目录查找您所在司法管辖区的监管机构或赔偿机构；澳大利亚安全工作局制定政策而不是执行个案。受伤后，寻求护理并检查索赔流程，而不是假设工资报告就可以完成索赔流程。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 官方信息免费；治疗和索赔安排各不相同。 |
| 潜在价值 | 提供更安全的工作和伤害支持的更清晰途径。 |
| 具体情境 | 工人；监管机构和补偿计划取决于司法管辖区、雇主和行业。 |
| 原条目依据 | 官方／专业指导 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [WHS 监管机构和工人赔偿当局](https://www.safeworkaustralia.gov.au/law-and-regulation/whs-regulators-and-workers-compensation-authorities-contact-information)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0168"></a>

## AU-0168 · 明确双方对“下班时间”的理解

**适用标签：受雇权益与签证工作权限分开**

以书面约定正常可联系时段、紧急联络与待命安排。全国劳动关系体系内的雇员，包括自 2025 年 8 月起的小企业雇员，可以拒绝非工作时间的工作联系，除非拒绝属于不合理情况。理由、干扰程度、报酬、岗位和个人情况都要考虑；规则并不禁止雇主发送消息。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；简短的对话和书面跟进。 |
| 潜在价值 | 保护恢复时间，同时阐明合法的可用性要求。 |
| 具体情境 | 受全国体系的离线权（right to disconnect）保护的员工；其他安排可能会提供额外的权利。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [断开连接的权利](https://www.fairwork.gov.au/employment-conditions/right-to-disconnect)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0169"></a>

## AU-0169 · 用普通一周的工作安排检验工作邀约

**适用标签：受雇权益与签证工作权限分开**

勾画出该工作所需的实际周数：花名册、旅行、未支付的空缺、关怀承诺和恢复时间。询问哪些时间是有保证的，哪些取决于需求，然后将整个安排与您目前的工作进行比较。当时间表不确定时，更高的广告价格可能仍然不适合个人。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 基于您实际一周的工作比较。 |
| 具体情境 | 求职者比较就业机会。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0170"></a>

## AU-0170 · 获得重要的书面招聘承诺

**适用标签：受雇权益与签证工作权限分开**

在其他地方辞职之前，询问书面报价中承诺的薪水、就业类型、地点、开始日期和任何条件。标记广告、采访讨论和合同之间的差异，并在接受之前要求澄清。保留注明日期的副本，以便以后的对话可以参考相同的商定条款。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 工作过渡期间减少歧义。 |
| 具体情境 | 考虑就业机会的人。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0171"></a>

## AU-0171 · 参加前检查无偿试用

**适用标签：受雇权益与签证工作权限分开**

询问你将展示什么技能、谁将监督以及需要多长时间。公平工作组织表示，无偿试用必须仅限于在直接监督下展示相关技能的合理需要；超出此范围的生产性工作可能需要付费。没有普遍的自由轮班津贴。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费官方指导。 |
| 潜在价值 | 有助于区分技能展示和无偿劳动。 |
| 具体情境 | 国家工作场所系统的申请人。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：无偿试用](https://www.fairwork.gov.au/starting-employment/unpaid-work/unpaid-trials)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0172"></a>

## AU-0172 · 质疑不明原因的工资扣除

**适用标签：受雇权益与签证工作权限分开**

在接受破损、短柜或设备扣除之前，请询问工资单以确定金额、用途和法律依据。根据国家规定，扣除需要有授权依据，并且即使签署了文件，也可能适用额外的限制。保留工资单并根据您的情况寻求公平工作指导。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费信息；咨询费用各不相同。 |
| 潜在价值 | 可以防止不当扣除成为惯例。 |
| 具体情境 | 国家系统员工；国家规定需要单独检查。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：扣除工资](https://www.fairwork.gov.au/pay-and-wages/deductions-and-related-issues/deducting-pay)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0173"></a>

## AU-0173 · 将弹性工作要求纳入可行的提案中

**适用标签：受雇权益与签证工作权限分开**

描述所寻求的变革、为什么需要变革以及移交或客户覆盖如何运作。某些满足服务和情况要求的员工拥有请求灵活性的法定权利；这并不是自动获得确切安排的权利。提交前请检查 Fair Work 的流程、书面回复规则和争议选项。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费索取；安排可能会影响收益。 |
| 潜在价值 | 使请求具体且更易于评估。 |
| 具体情境 | 雇员;法定资格和行业覆盖范围很重要。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：灵活的工作安排](https://www.fairwork.gov.au/employment-conditions/flexibility-in-the-workplace/flexible-working-arrangements)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0174"></a>

## AU-0174 · 核对薪酬保密规定，不凭猜测

**适用标签：受雇权益与签证工作权限分开**

若有人称你不能讨论薪酬，先读适用合同与 Fair Work 指引再回应。分享或拒绝分享薪酬信息的权利包含过渡规定：2022 年 12 月 7 日前签订、包含保密条款且此后未变更的某些合同可能被区别处理。不要逼同事透露工资。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费官方信息。 |
| 潜在价值 | 不依赖工作场所民间传说来阐明权利。 |
| 具体情境 | 相关公平工作条款涵盖的员工。 |
| 原条目依据 | 官方规则 |
| 原版编辑审阅 | 2026-10-09 |

**原条目来源：** [公平工作：薪酬保密](https://www.fairwork.gov.au/pay-and-wages/pay-secrecy)

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0175"></a>

## AU-0175 · 写下一次艰难会议的结果

**适用标签：受雇权益与签证工作权限分开**

在绩效或行为会议之后，记录提出的问题、提供的示例、商定的行动和审查日期。要求用可观察的例子来解释不明确的期望，并发送冷静的总结以供纠正。保留您自己的合法记录，并在出现解雇或其他严重后果时立即获取建议。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 关于预期改进或响应的共享参考。 |
| 具体情境 | 处理绩效或行为流程的员工。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0176"></a>

## AU-0176 · 核算雇主承诺的培训价值与费用

**适用标签：受雇权益与签证工作权限分开**

询问雇主资助的学习是否包括课程费用、材料、旅行、休假以及离开时的任何还款条件。将书面安排与课程如何适合您的工作和关怀承诺进行比较，并在签署前就不清楚的还款条款获取建议。确认谁拥有或接收生成的证书。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 更清晰地了解利益和承诺。 |
| 具体情境 | 员工考虑雇主资助的培训。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0177"></a>

## AU-0177 · 休假前准备有用的工作交接

**适用标签：受雇权益与签证工作权限分开**

列出当前任务、截止日期、联系人以及授权同事可以在哪里找到必要的文件。就您不在时谁可以做出决定以及真正需要升级的事项达成一致，而无需共享个人密码。与接收人核实交接情况，这样您就不是唯一理解这一情况的人。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 休假更顺畅，可避免的干扰更少。 |
| 具体情境 | 员工准备计划休假。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0178"></a>

## AU-0178 · 工作变动时重新检查条件

**适用标签：受雇权益与签证工作权限分开**

当职责、工作地点或花名册发生变化时，将新的安排与现有的书面条款进行比较。询问等级、津贴、设备或旅行期望是否也需要审查，并记录同意的内容。如果对变更有争议，请寻求行业建议，而不是假设新的职位可以解决问题。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 使条件与实际执行的工作保持一致。 |
| 具体情境 | 员工调动角色或承担额外职责。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0179"></a>

## AU-0179 · 准备一份离职清单

**适用标签：受雇权益与签证工作权限分开**

在最后一天之前，列出最终工资问题、休假记录、您可以合法保留的个人档案、要归还的设备以及参考联系人。退回贵重设备时索要收据，并确认最终工资单将发送到何处。将雇主机密材料保留在您的个人档案之外，并遵循商定的移交要求。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 访问工作系统结束后，遗留问题更少。 |
| 具体情境 | 员工辞职、退休或以其他方式离开职位。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

---

<a id="au-0180"></a>

## AU-0180 · 在问题恶化之前选择工作场所支持

**适用标签：受雇权益与签证工作权限分开**

在困难的工作场所流程升级之前，确定值得信赖的支持人员、工会联系人或适当的法律服务。检查会员资格或服务范围、预约可用性以及他们需要什么文件，而不假设代表是自动的。准备一个简短的时间表和你想要的结果，这样初步对话是有用的。

| 身份 | 该怎么用这条行动 |
| --- | --- |
| 华人澳洲公民 | 按实际雇佣制度、岗位与合同维护权益。 |
| 中国籍永久居民（PR） | 在澳受雇时按实际工资、工时与岗位留证；PR 不改变最低标准的核对方法。 |
| 中国籍工作／学生等临时签证者 | 工作权限看 VEVO；获准工作后仍享有适用劳动保护，不能因签证被要求接受低于标准的待遇。 |
| 中国游客／短期探亲者 | 不要据此指南开始无工作权限的劳动；已经遇到欠薪或剥削时仍可向 Fair Work 求助。 |

**不适用时的替代行动：** 无工作权限者先使用职业信息和学习部分；需就业时先确认可工作的签证及其限制，不能靠取得 ABN 绕过限制。

**本条边界：** 签证工作权限与最低劳动待遇是两个问题；学生通常有学期中工时限制，具体以本人 VEVO 条件为准。

| 速览 | 详情 |
| --- | --- |
| 成本／精力 | 免费；进行有重点的规划会议。 |
| 潜在价值 | 在时间紧迫时更快地获取相关帮助。 |
| 具体情境 | 需要工作场所问题支持的工人。 |
| 原条目依据 | 实用建议 |
| 原版编辑审阅 | 2026-10-09 |

*原条目属于编辑建议，不宣称具有外部证据支持。*

**身份边界核对（2026-10-09）：** [签证条件查询 VEVO](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/) · [签证持有人与移民劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements) · [学生签证（500）](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)
