# 从34原创主题到40澳洲章节
> 中文适配说明：本附件保留原澳洲版的内容结构。中国读者请先看[身份与落地路径](CHINESE-READERS.md)，并使用各行动的身份表及替代行动；原项目的构建／发布说明仅作来源背景。


原文：**高人生人生指南 / HowToLiveBetter**，eternity4719 和贡献者，[源存储库](https://github.com/eternity4719/HowToLiveBetter)。此映射使用 [commit a18ee40519ed34562ac12a8dc88e053a9c8a9973](https://github.com/eternity4719/HowToLiveBetter/tree/a18ee40519ed34562ac12a8dc88e053a9c8a9973)。下面的原始主题名称是描述性的英文翻译。

这是一个主题改编：每个原始章节都有一个目的地，但个别建议已被选择、重写、拆分、合并或省略。映射的主题并不要求再现每个原始细节。澳大利亚机构、州差异和适用的官方消息来源取代了中国大陆的特定规则。

|原创章节|原创主题|澳大利亚报道 |
| --- | --- | --- |
| 1 |避免过早死亡| [紧急情况](book/01-emergencies.md) · [日常健康](book/02-everyday-health.md) · [旅行与户外安全](book/17-travel-outdoors.md) · [交通与养车](book/25-transport-and-car-ownership.md) · [气候、灾害与抗灾住房](book/26-climate-disasters-and-resilient-homes.md) |
| 2 |避免长期健康恶化 | [日常健康](book/02-everyday-health.md) · [慢性病管理](book/19-chronic-conditions.md) · [外貌、牙科与治疗选择](book/24-appearance-dental-and-treatment-choices.md) |
| 3 |保护你的能量 | [心理健康与精力](book/04-mental-health-and-energy.md)·[时间、注意力与生活事务](book/18-time-attention.md) |
| 4 |好好利用你的时间 | [时间、注意力与生活事务](book/18-time-attention.md)·[人工智能、隐私与数字判断](book/35-ai-privacy.md) |
| 5 |避免浪费钱 | [日常开支](book/05-everyday-costs.md) · [银行账户与债务](book/07-banking-and-debt.md) · [养老金、税务与保险](book/08-super-tax-and-insurance.md) · [食品与家庭用品的性价比](book/27-food-and-household-value.md) · [明智消费与避坑](book/34-buying-wisely-and-avoiding-traps.md) |
| 6 |应避免的事情 | [消费者权益与法律权利](book/14-consumer-and-legal-rights.md) · [外貌、牙科与治疗选择](book/24-appearance-dental-and-treatment-choices.md) · [日常法律风险与接触警方](book/31-everyday-legal-risks-and-police-contact.md) · [明智消费与避坑](book/34-buying-wisely-and-avoiding-traps.md) |
| 7 |花很少的钱过日子 | [经济困难援助与残障支持](book/09-money-help-and-disability-support.md) · [日常开支](book/05-everyday-costs.md) · [偏远地区生活](book/29-regional-and-remote-living.md) |
| 8 |法律和财产安全 | [消费者权益与法律权利](book/14-consumer-and-legal-rights.md) · [租房与买房](book/06-renting-and-buying-a-home.md) · [分居与家庭法](book/30-separation-and-family-law.md) |
| 9 |日常法律界限| [日常法律风险与接触警方](book/31-everyday-legal-risks-and-police-contact.md)·[消费者权益与法律权利](book/14-consumer-and-legal-rights.md) |
| 10 |人际关系与婚姻| [亲密关系与子女](book/12-relationships-and-children.md) · [分居与家庭法](book/30-separation-and-family-law.md) · [人际关系、社区与休闲](book/39-relationships-community.md) |
| 11 |技术工作的法律风险| [账户与设备安全](book/15-digital-security.md) · [人工智能、隐私与数字判断](book/35-ai-privacy.md) · [网站、应用与线上项目](book/38-online-projects.md) |
| 12 |创办和经营企业 | [创办小企业](book/16-small-business.md) · [零工、承包与自雇权益](book/32-gig-work-contracting-and-self-employment-rights.md) |
| 13 |遇到紧急情况怎么办 | [紧急情况](book/01-emergencies.md) · [气候、灾害与抗灾住房](book/26-climate-disasters-and-resilient-homes.md) |
| 14 |账户与信息安全 | [账户与设备安全](book/15-digital-security.md) · [人工智能、隐私与数字判断](book/35-ai-privacy.md) |
| 15 |租房和买房 | [租房与买房](book/06-renting-and-buying-a-home.md) · [搬家与迁居](book/36-moving-home.md) |
| 16 |患有慢性疾病| [慢性病管理](book/19-chronic-conditions.md)·[医疗服务与药品](book/03-healthcare-and-medicines.md) |
| 17 |赡养年长亲戚| [老龄照护与丧亲事务](book/13-ageing-and-bereavement.md)·[退休过渡](book/28-retirement-transitions.md) |
| 18 |抚养孩子和家庭决定| [亲密关系与子女](book/12-relationships-and-children.md)·[婴儿与幼儿期](book/21-babies-and-early-childhood.md)]·[学龄儿童与青少年](book/22-school-age-and-teenagers.md)|
| 19 |就业、离职和工伤 | [劳动权益](book/10-work-rights.md) · [零工、承包与自雇权益](book/32-gig-work-contracting-and-self-employment-rights.md) |
| 20 |照顾新生儿 | [婴儿与幼儿期](book/21-babies-and-early-childhood.md) |
| 21 |出国旅行和安全| [旅行与户外安全](book/17-travel-outdoors.md)·[海外工作与留学](book/37-overseas-work-study.md) |
| 22 |休闲与减压| [人际关系、社区与休闲](book/39-relationships-community.md) · [心理健康与精力](book/04-mental-health-and-energy.md) |
| 23 |选择有用的技能| [教育与职业发展](book/11-education-and-career.md)·[年满18岁与选择人生道路](book/33-turning-18-and-choosing-a-path.md)·[人工智能、隐私与数字判断](book/35-ai-privacy.md) |
| 24 |医疗保健导航 | [医疗服务与药品](book/03-healthcare-and-medicines.md) · [外貌、牙科与治疗选择](book/24-appearance-dental-and-treatment-choices.md) |
| 25 |死亡后的管理| [老龄照护与丧亲事务](book/13-ageing-and-bereavement.md)·[应对人生重大变化](book/40-major-life-changes.md) |
| 26 |建立网站或平台 | [网站、应用与线上项目](book/38-online-projects.md) · [创办小企业](book/16-small-business.md) |
| 27 |怀孕和分娩 | [怀孕与分娩](book/20-pregnancy-and-birth.md) |
| 28 |外观无可避免的伤害| [外貌、牙科与治疗选择](book/24-appearance-dental-and-treatment-choices.md) |
| 29 |重大挫折后| [应对人生重大变化](book/40-major-life-changes.md)·[心理健康与精力](book/04-mental-health-and-energy.md) |
| 30 |学龄儿童| [学龄儿童与青少年](book/22-school-age-and-teenagers.md) |
| 31 |十八岁后的路 | [年满18岁与选择人生道路](book/33-turning-18-and-choosing-a-path.md)·[教育与职业发展](book/11-education-and-career.md) |
| 32 |海外留学| [海外工作与留学](book/37-overseas-work-study.md) · [教育与职业发展](book/11-education-and-career.md) |
| 33 |残疾生活 | [残障人士的健康与无障碍服务](book/23-disability-health-and-access.md) · [经济困难援助与残障支持](book/09-money-help-and-disability-support.md) · [偏远地区生活](book/29-regional-and-remote-living.md) |
| 34 |在家安全用药| [医疗服务与药品](book/03-healthcare-and-medicines.md) · [慢性病管理](book/19-chronic-conditions.md) · [婴儿与幼儿期](book/21-babies-and-early-childhood.md) |

## 刻意的改变

- 澳大利亚的医疗保健途径和当前的计划指南取代了中国的筛查时间表、保险途径和紧急联系人。毯式治疗和剂量说明不会延续。
- 联邦和州或地区的区别取代了单一国家租赁、运输、法律或资格规则的假设。
- 工作权利、养老金、HELP、澳大利亚商业义务和本地支持服务取代了原来的特定国家系统。
- 交通所有权、备灾、区域准入、退休过渡、AI 判断和搬家得到明确的覆盖。
- 每个行动都有适用性、努力程度、潜在价值和基础标签。该项目还添加了基于情况的路线和可搜索的离线阅读器。

有关许可和修改通知，请参阅[ATTRIBUTION.md](ATTRIBUTION.md)。
