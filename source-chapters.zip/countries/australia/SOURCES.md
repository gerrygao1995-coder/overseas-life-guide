# 来源目录

全书使用 337 个不同来源网址，来源于政府、监管机构、专业组织或服务提供方；列出来源并不代表这些机构为本项目背书。来源支持条目中相关的具体内容，成本与潜在价值属于编辑判断。请打开现行官方页面核对规则、资格与地区差异。

原版编辑审阅日期：2026-10-09。本日期是原版审阅记录，不是本译本重新核验所有规则的日期，也不保证链接永久有效。

## Healthdirect：拨打澳洲紧急电话 Triple Zero

原文标题：Healthdirect: calling triple zero

[打开来源](https://www.healthdirect.gov.au/calling-triple-zero)

用于：[AU-0001](book/01-emergencies.md#au-0001) · [AU-0002](book/01-emergencies.md#au-0002)

## ANZCOR：指南 8 — 心肺复苏

原文标题：ANZCOR: Guideline 8 — Cardiopulmonary Resuscitation

[打开来源](https://www.anzcor.org/home/basic-life-support/guideline-8-cardiopulmonary-resuscitation-cpr)

用于：[AU-0003](book/01-emergencies.md#au-0003) · [AU-0004](book/01-emergencies.md#au-0004)

## 澳大利亚复苏委员会：CPR 和溺水常见问题解答

原文标题：Australian Resuscitation Council: CPR and drowning FAQs

[打开来源](https://www.resus.org.au/training-and-education/faq)

用于：[AU-0003](book/01-emergencies.md#au-0003)

## Healthdirect：吞咽物质

原文标题：Healthdirect: swallowed substances

[打开来源](https://www.healthdirect.gov.au/swallowed-substances)

用于：[AU-0005](book/01-emergencies.md#au-0005)

## 澳大利亚红十字会：为紧急情况做好准备

原文标题：Australian Red Cross: Prepare for emergencies

[打开来源](https://www.redcross.org.au/prepare/)

用于：[AU-0006](book/01-emergencies.md#au-0006) · [AU-0007](book/01-emergencies.md#au-0007)

## NSW SES：洪水期间

原文标题：NSW SES: During a flood

[打开来源](https://www.ses.nsw.gov.au/during-emergency/during-flood)

用于：[AU-0008](book/01-emergencies.md#au-0008)

## Healthdirect：中暑

原文标题：Healthdirect: heatstroke

[打开来源](https://www.healthdirect.gov.au/heatstroke)

用于：[AU-0009](book/01-emergencies.md#au-0009)

## 冲浪救生 NSW：在海滩保持安全

原文标题：Surf Life Saving NSW: Staying safe at the beach

[打开来源](https://beachsafetyhub.org.au/learn-&-play/learn-play-in-your-language/staying-safe-at-the-beach/)

用于：[AU-0010](book/01-emergencies.md#au-0010)

## Healthdirect：窒息

原文标题：Healthdirect: choking

[打开来源](https://www.healthdirect.gov.au/choking)

用于：[AU-0011](book/01-emergencies.md#au-0011) · [AU-0376](book/21-babies-and-early-childhood.md#au-0376)

## Healthdirect：烧伤和烫伤

原文标题：Healthdirect: burns and scalds

[打开来源](https://www.healthdirect.gov.au/burns-and-scalds)

用于：[AU-0012](book/01-emergencies.md#au-0012)

## 健康直接：中风

原文标题：Healthdirect: stroke

[打开来源](https://www.healthdirect.gov.au/stroke)

用于：[AU-0013](book/01-emergencies.md#au-0013)

## Healthdirect：心脏病发作

原文标题：Healthdirect: heart attack

[打开来源](https://www.healthdirect.gov.au/heart-attack)

用于：[AU-0014](book/01-emergencies.md#au-0014)

## Healthdirect：过敏反应

原文标题：Healthdirect: anaphylaxis

[打开来源](https://www.healthdirect.gov.au/anaphylaxis)

用于：[AU-0015](book/01-emergencies.md#au-0015)

## Healthdirect：蛇咬伤

原文标题：Healthdirect: snake bites

[打开来源](https://www.healthdirect.gov.au/snake-bites)

用于：[AU-0016](book/01-emergencies.md#au-0016)

## Healthdirect：癫痫发作

原文标题：Healthdirect: seizures

[打开来源](https://www.healthdirect.gov.au/seizures)

用于：[AU-0017](book/01-emergencies.md#au-0017)

## Healthdirect：青少年和成人哮喘

原文标题：Healthdirect: asthma in adolescents and adults

[打开来源](https://www.healthdirect.gov.au/asthma-in-adolescents-and-adults)

用于：[AU-0018](book/01-emergencies.md#au-0018) · [AU-0326](book/19-chronic-conditions.md#au-0326)

## 癌症委员会：防晒霜和防晒安全

原文标题：Cancer Council: Sunscreen and sun safety

[打开来源](https://www.cancer.org.au/cancer-information/causes-and-prevention/sun-safety/sunscreen)

用于：[AU-0019](book/02-everyday-health.md#au-0019)

## 卫生部：针对 18–64 岁成年人的运动建议

原文标题：Department of Health: Movement recommendations for adults aged 18–64

[打开来源](https://www.health.gov.au/topics/physical-activity/24-hour-movement-guidelines-for-all-australians/recommendations-for-adults-18-to-64-years)

用于：[AU-0020](book/02-everyday-health.md#au-0020) · [AU-0021](book/02-everyday-health.md#au-0021)

## 健康饮食：预算内的健康饮食

原文标题：Eat for Health: Healthy eating on a budget

[打开来源](https://www.eatforhealth.gov.au/eating-well/tips-eating-well/healthy-eating-budget)

用于：[AU-0022](book/02-everyday-health.md#au-0022) · [AU-0035](book/02-everyday-health.md#au-0035)

## Healthdirect：牙齿清洁

原文标题：Healthdirect: teeth cleaning

[打开来源](https://www.healthdirect.gov.au/teeth-cleaning)

用于：[AU-0023](book/02-everyday-health.md#au-0023)

## 卫生部：成人免疫接种

原文标题：Department of Health: Immunisation for adults

[打开来源](https://www.health.gov.au/topics/immunisation/when-to-get-vaccinated/immunisation-for-adults)

用于：[AU-0024](book/02-everyday-health.md#au-0024) · [AU-0025](book/02-everyday-health.md#au-0025)

## 卫生部：接种疫苗

原文标题：Department of Health: Getting vaccinated

[打开来源](https://www.health.gov.au/topics/immunisation/getting-vaccinated)

用于：[AU-0024](book/02-everyday-health.md#au-0024) · [AU-0377](book/21-babies-and-early-childhood.md#au-0377)

## 卫生署：癌症筛查

原文标题：Department of Health: Screening for cancer

[打开来源](https://www.health.gov.au/topics/cancer/screening-for-cancer)

用于：[AU-0026](book/02-everyday-health.md#au-0026)

## Healthdirect：听力损失

原文标题：Healthdirect: hearing loss

[打开来源](https://www.healthdirect.gov.au/hearing-loss)

用于：[AU-0027](book/02-everyday-health.md#au-0027)

## Healthdirect：眼睛护理

原文标题：Healthdirect: eye care

[打开来源](https://www.healthdirect.gov.au/eye-care)

用于：[AU-0028](book/02-everyday-health.md#au-0028)

## Healthdirect：个人卫生

原文标题：Healthdirect: personal hygiene

[打开来源](https://www.healthdirect.gov.au/personal-hygiene)

用于：[AU-0029](book/02-everyday-health.md#au-0029)

## 健康指导：食品安全

原文标题：Healthdirect: food safety

[打开来源](https://www.healthdirect.gov.au/food-safety)

用于：[AU-0030](book/02-everyday-health.md#au-0030) · [AU-0035](book/02-everyday-health.md#au-0035)

## Healthdirect：脱水

原文标题：Healthdirect: dehydration

[打开来源](https://www.healthdirect.gov.au/dehydration)

用于：[AU-0031](book/02-everyday-health.md#au-0031)

## Healthdirect：跌倒

原文标题：Healthdirect: falls

[打开来源](https://www.healthdirect.gov.au/falls)

用于：[AU-0032](book/02-everyday-health.md#au-0032)

## Healthdirect：戒烟

原文标题：Healthdirect: quit smoking vaping

[打开来源](https://www.healthdirect.gov.au/quit-smoking-vaping)

用于：[AU-0033](book/02-everyday-health.md#au-0033)

## Healthdirect：性健康

原文标题：Healthdirect: sexual health

[打开来源](https://www.healthdirect.gov.au/sexual-health)

用于：[AU-0034](book/02-everyday-health.md#au-0034)

## Healthdirect：询问医生的问题

原文标题：Healthdirect: questions to ask your doctor

[打开来源](https://www.healthdirect.gov.au/questions-to-ask-your-doctor)

用于：[AU-0036](book/02-everyday-health.md#au-0036) · [AU-0048](book/03-healthcare-and-medicines.md#au-0048) · [AU-0049](book/03-healthcare-and-medicines.md#au-0049)

## 澳洲服务局（Services Australia）：Medicare 直接结算（bulk billing）

原文标题：Services Australia: Bulk billing

[打开来源](https://www.servicesaustralia.gov.au/bulk-billing?context=60092)

用于：[AU-0037](book/03-healthcare-and-medicines.md#au-0037)

## 澳洲服务局（Services Australia）：注册医疗保险安全网

原文标题：Services Australia: Register for Medicare Safety Nets

[打开来源](https://www.servicesaustralia.gov.au/how-to-register-for-medicare-safety-nets?context=22001)

用于：[AU-0038](book/03-healthcare-and-medicines.md#au-0038)

## 澳洲服务局（Services Australia）：当您在 PBS 药品上花费大量费用时

原文标题：Services Australia: When you spend a lot on PBS medicines

[打开来源](https://www.servicesaustralia.gov.au/when-you-spend-lot-pbs-medicines?context=22016)

用于：[AU-0039](book/03-healthcare-and-medicines.md#au-0039)

## TGA：非专利处方药

原文标题：TGA: Generic prescription medicines

[打开来源](https://www.tga.gov.au/news/news-articles/generic-prescription-medicines-fact-sheet)

用于：[AU-0040](book/03-healthcare-and-medicines.md#au-0040)

## 卫生部：60 天处方的资格

原文标题：Department of Health: Eligibility for 60-day prescriptions

[打开来源](https://www.health.gov.au/cheaper-medicines/60-day-prescriptions)

用于：[AU-0041](book/03-healthcare-and-medicines.md#au-0041)

## Healthdirect：充分发挥药剂师的作用

原文标题：Healthdirect: getting the most out of your pharmacist

[打开来源](https://www.healthdirect.gov.au/getting-the-most-out-of-your-pharmacist)

用于：[AU-0042](book/03-healthcare-and-medicines.md#au-0042) · [AU-0050](book/03-healthcare-and-medicines.md#au-0050) · [AU-0403](book/23-disability-health-and-access.md#au-0403)

## Healthdirect：过期药物

原文标题：Healthdirect: out of date medicines

[打开来源](https://www.healthdirect.gov.au/out-of-date-medicines)

用于：[AU-0043](book/03-healthcare-and-medicines.md#au-0043)

## PrivateHealth.gov.au：救护车保险

原文标题：PrivateHealth.gov.au: Ambulance cover

[打开来源](https://privatehealth.gov.au/health_insurance/what_is_covered/ambulance.htm)

用于：[AU-0044](book/03-healthcare-and-medicines.md#au-0044) · [AU-0132](book/08-super-tax-and-insurance.md#au-0132)

## Healthdirect：问题生成器

原文标题：Healthdirect: question builder

[打开来源](https://www.healthdirect.gov.au/question-builder)

用于：[AU-0045](book/03-healthcare-and-medicines.md#au-0045)

## Healthdirect：如何找到合适的健康专家

原文标题：Healthdirect: how to find the right health professional

[打开来源](https://www.healthdirect.gov.au/how-to-find-the-right-health-professional)

用于：[AU-0046](book/03-healthcare-and-medicines.md#au-0046)

## 卫生部：查找 Medicare 紧急护理诊所

原文标题：Department of Health: Find a Medicare Urgent Care Clinic

[打开来源](https://www.health.gov.au/find-a-medicare-ucc)

用于：[AU-0047](book/03-healthcare-and-medicines.md#au-0047)

## Healthdirect：您的医疗保健权利

原文标题：Healthdirect: your healthcare rights

[打开来源](https://www.healthdirect.gov.au/your-healthcare-rights)

用于：[AU-0051](book/03-healthcare-and-medicines.md#au-0051) · [AU-0052](book/03-healthcare-and-medicines.md#au-0052)

## 澳大利亚医疗保健安全和质量委员会：了解您的医疗保健权利

原文标题：Australian Commission on Safety and Quality in Health Care: Understanding your healthcare rights

[打开来源](https://www.safetyandquality.gov.au/your-rights/understanding-your-healthcare-rights)

用于：[AU-0053](book/03-healthcare-and-medicines.md#au-0053) · [AU-0054](book/03-healthcare-and-medicines.md#au-0054) · [AU-0399](book/23-disability-health-and-access.md#au-0399)

## 生命线：危机支持

原文标题：Lifeline: Crisis Support

[打开来源](https://www.lifeline.org.au/get-help/national-services/lifeline-crisis-support)

用于：[AU-0055](book/04-mental-health-and-energy.md#au-0055) · [AU-0056](book/04-mental-health-and-energy.md#au-0056)

## 医疗保险心理健康：中心

原文标题：Medicare Mental Health: Centres

[打开来源](https://www.medicarementalhealth.gov.au/medicare-mental-health-centres)

用于：[AU-0057](book/04-mental-health-and-energy.md#au-0057)

## 澳洲服务局（Services Australia）：心理保健和医疗保险

原文标题：Services Australia: Mental health care and Medicare

[打开来源](https://www.servicesaustralia.gov.au/mental-health-care-and-medicare?context=60092)

用于：[AU-0058](book/04-mental-health-and-energy.md#au-0058) · [AU-0071](book/04-mental-health-and-energy.md#au-0071)

## 健康指导：失眠

原文标题：Healthdirect: insomnia

[打开来源](https://www.healthdirect.gov.au/insomnia)

用于：[AU-0059](book/04-mental-health-and-energy.md#au-0059) · [AU-0060](book/04-mental-health-and-energy.md#au-0060)

## Healthdirect：孤独隔离心理健康

原文标题：Healthdirect: loneliness isolation mental health

[打开来源](https://www.healthdirect.gov.au/loneliness-isolation-mental-health)

用于：[AU-0061](book/04-mental-health-and-energy.md#au-0061)

## 澳大利亚安全工作：心理社会危害

原文标题：Safe Work Australia: Psychosocial hazards

[打开来源](https://www.safeworkaustralia.gov.au/safety-topic/managing-health-and-safety/mental-health/psychosocial-hazards)

用于：[AU-0062](book/04-mental-health-and-energy.md#au-0062)

## 卫生部：减少或戒酒

原文标题：Department of Health: Reducing or quitting alcohol

[打开来源](https://www.health.gov.au/topics/alcohol/about-alcohol/how-can-you-reduce-or-quit-alcohol)

用于：[AU-0063](book/04-mental-health-and-energy.md#au-0063)

## 健康直达：焦虑

原文标题：Healthdirect: anxiety

[打开来源](https://www.healthdirect.gov.au/anxiety)

用于：[AU-0064](book/04-mental-health-and-energy.md#au-0064) · [AU-0071](book/04-mental-health-and-energy.md#au-0071)

## 健康直达：抑郁症

原文标题：Healthdirect: depression

[打开来源](https://www.healthdirect.gov.au/depression)

用于：[AU-0065](book/04-mental-health-and-energy.md#au-0065) · [AU-0072](book/04-mental-health-and-energy.md#au-0072)

## Healthdirect：悲伤损失

原文标题：Healthdirect: grief loss

[打开来源](https://www.healthdirect.gov.au/grief-loss)

用于：[AU-0066](book/04-mental-health-and-energy.md#au-0066)

## Healthdirect：赌博成瘾

原文标题：Healthdirect: gambling addiction

[打开来源](https://www.healthdirect.gov.au/gambling-addiction)

用于：[AU-0067](book/04-mental-health-and-energy.md#au-0067)

## Healthdirect：疲劳

原文标题：Healthdirect: fatigue

[打开来源](https://www.healthdirect.gov.au/fatigue)

用于：[AU-0068](book/04-mental-health-and-energy.md#au-0068)

## 13YARN：原住民和托雷斯海峡岛民危机支持

原文标题：13YARN: Aboriginal and Torres Strait Islander crisis support

[打开来源](https://www.13yarn.org.au/)

用于：[AU-0069](book/04-mental-health-and-energy.md#au-0069)

## Headspace：青少年心理健康支持

原文标题：headspace: Youth mental health support

[打开来源](https://headspace.org.au/)

用于：[AU-0070](book/04-mental-health-and-energy.md#au-0070)

## ACCC：杂货单价

原文标题：ACCC: Unit prices for groceries

[打开来源](https://www.accc.gov.au/consumers/pricing/unit-prices-for-groceries)

用于：[AU-0073](book/05-everyday-costs.md#au-0073)

## Moneysmart：节省食物和燃料的方法

原文标题：Moneysmart: Ways to save on food and fuel

[打开来源](https://moneysmart.gov.au/budgeting/ways-to-save-on-food-and-fuel)

用于：[AU-0074](book/05-everyday-costs.md#au-0074)

## 能源变得简单：常见问题

原文标题：Energy Made Easy: Frequently asked questions

[打开来源](https://www.energymadeeasy.gov.au/frequently-asked-questions)

用于：[AU-0075](book/05-everyday-costs.md#au-0075)

## 澳大利亚政府：转向储蓄

原文标题：Australian Government: Switch to save

[打开来源](https://www.energy.gov.au/households/find-the-best-energy-deal)

用于：[AU-0075](book/05-everyday-costs.md#au-0075)

## 维多利亚能源比较

原文标题：Victorian Energy Compare

[打开来源](https://compare.energy.vic.gov.au/)

用于：[AU-0075](book/05-everyday-costs.md#au-0075)

## ACMA：了解您的电话或互联网合同

原文标题：ACMA: Understand your phone or internet contract

[打开来源](https://www.acma.gov.au/understand-your-telco-contract)

用于：[AU-0076](book/05-everyday-costs.md#au-0076) · [AU-0086](book/05-everyday-costs.md#au-0086) · [AU-0087](book/05-everyday-costs.md#au-0087) · [AU-0506](book/29-regional-and-remote-living.md#au-0506)

## NSW 州立图书馆：图书馆法和条例

原文标题：State Library of NSW: Library Act and Regulation

[打开来源](https://pls.sl.nsw.gov.au/about/library-act-and-regulation)

用于：[AU-0077](book/05-everyday-costs.md#au-0077)

## ACCC：您购买的产品或服务存在问题

原文标题：ACCC: Problem with a product or service you bought

[打开来源](https://www.accc.gov.au/consumers/problem-with-a-product-or-service-you-bought)

用于：[AU-0078](book/05-everyday-costs.md#au-0078)

## Moneysmart：直接借记

原文标题：Moneysmart: Direct debits

[打开来源](https://moneysmart.gov.au/banking/direct-debits)

用于：[AU-0079](book/05-everyday-costs.md#au-0079) · [AU-0081](book/05-everyday-costs.md#au-0081) · [AU-0088](book/05-everyday-costs.md#au-0088) · [AU-0126](book/07-banking-and-debt.md#au-0126)

## Moneysmart：如何制定预算

原文标题：Moneysmart: How to do a budget

[打开来源](https://moneysmart.gov.au/budgeting/how-to-do-a-budget)

用于：[AU-0080](book/05-everyday-costs.md#au-0080) · [AU-0083](book/05-everyday-costs.md#au-0083) · [AU-0084](book/05-everyday-costs.md#au-0084) · [AU-0123](book/07-banking-and-debt.md#au-0123)

## Moneysmart：管理临时收入

原文标题：Moneysmart: Managing on a casual income

[打开来源](https://moneysmart.gov.au/budgeting/managing-on-a-casual-income)

用于：[AU-0082](book/05-everyday-costs.md#au-0082) · [AU-0122](book/07-banking-and-debt.md#au-0122)

## ACCC：消费者权利和保证

原文标题：ACCC: Consumer rights and guarantees

[打开来源](https://www.accc.gov.au/consumers/buying-products-and-services/consumer-rights-and-guarantees)

用于：[AU-0085](book/05-everyday-costs.md#au-0085) · [AU-0089](book/05-everyday-costs.md#au-0089) · [AU-0108](book/06-renting-and-buying-a-home.md#au-0108) · [AU-0520](book/29-regional-and-remote-living.md#au-0520)

## Moneysmart：交易账户和借记卡

原文标题：Moneysmart: Transaction accounts and debit cards

[打开来源](https://moneysmart.gov.au/banking/transaction-accounts-and-debit-cards)

用于：[AU-0090](book/05-everyday-costs.md#au-0090) · [AU-0115](book/07-banking-and-debt.md#au-0115) · [AU-0116](book/07-banking-and-debt.md#au-0116)

## Moneysmart：租赁债券和租赁

原文标题：Moneysmart: Rental bonds and leases

[打开来源](https://moneysmart.gov.au/student-life-and-money/rental-bonds-and-leases)

用于：[AU-0091](book/06-renting-and-buying-a-home.md#au-0091) · [AU-0092](book/06-renting-and-buying-a-home.md#au-0092)

## myGov：签署租赁租约和州租赁链接

原文标题：myGov: Signing a rental lease and state tenancy links

[打开来源](https://my.gov.au/en/services/living-arrangements/finding-renting-and-buying-a-home/renting-a-home/signing-a-rental-lease)

用于：[AU-0093](book/06-renting-and-buying-a-home.md#au-0093) · [AU-0099](book/06-renting-and-buying-a-home.md#au-0099) · [AU-0101](book/06-renting-and-buying-a-home.md#au-0101) · [AU-0465](book/26-climate-disasters-and-resilient-homes.md#au-0465)

## NSW 政府：为租户处理押金纠纷

原文标题：NSW Government: Dealing with bond disputes for tenants

[打开来源](https://www.nsw.gov.au/housing-and-construction/renting-a-place-to-live/residential-rental-bonds/dealing-bond-disputes-for-tenants)

用于：[AU-0094](book/06-renting-and-buying-a-home.md#au-0094)

## 精明理财：买房

原文标题：Moneysmart: Buying a house

[打开来源](https://moneysmart.gov.au/home-loans/buying-a-house)

用于：[AU-0095](book/06-renting-and-buying-a-home.md#au-0095) · [AU-0103](book/06-renting-and-buying-a-home.md#au-0103) · [AU-0106](book/06-renting-and-buying-a-home.md#au-0106)

## Moneysmart：选择住房贷款

原文标题：Moneysmart: Choosing a home loan

[打开来源](https://moneysmart.gov.au/home-loans/choosing-a-home-loan)

用于：[AU-0096](book/06-renting-and-buying-a-home.md#au-0096) · [AU-0105](book/06-renting-and-buying-a-home.md#au-0105)

## Moneysmart：转换住房贷款

原文标题：Moneysmart: Switching home loans

[打开来源](https://moneysmart.gov.au/home-loans/switching-home-loans)

用于：[AU-0096](book/06-renting-and-buying-a-home.md#au-0096)

## NSW 公平交易 — 共享住宅租赁物业（NSW 示例）

原文标题：NSW Fair Trading — sharing a residential rental property (NSW example)

[打开来源](https://www.nsw.gov.au/housing-and-construction/rules/sharing-a-residential-rental-property)

用于：[AU-0097](book/06-renting-and-buying-a-home.md#au-0097)

## NSW 的交通：旅行规划器

原文标题：Transport for NSW: Trip planner

[打开来源](https://transportnsw.info/trip)

用于：[AU-0098](book/06-renting-and-buying-a-home.md#au-0098) · [AU-0443](book/25-transport-and-car-ownership.md#au-0443) · [AU-0444](book/25-transport-and-car-ownership.md#au-0444)

## 澳大利亚能源监管机构 — 嵌入式网络客户

原文标题：Australian Energy Regulator — embedded networks customers

[打开来源](https://www.aer.gov.au/consumers/understanding-energy/embedded-networks-customers)

用于：[AU-0100](book/06-renting-and-buying-a-home.md#au-0100)

## Moneysmart：财物保险

原文标题：Moneysmart: Contents insurance

[打开来源](https://moneysmart.gov.au/home-insurance/contents-insurance)

用于：[AU-0102](book/06-renting-and-buying-a-home.md#au-0102) · [AU-0139](book/08-super-tax-and-insurance.md#au-0139) · [AU-0144](book/08-super-tax-and-insurance.md#au-0144)

## Moneysmart：选择家庭保险

原文标题：Moneysmart: Choosing home insurance

[打开来源](https://moneysmart.gov.au/home-insurance/choosing-home-insurance)

用于：[AU-0104](book/06-renting-and-buying-a-home.md#au-0104) · [AU-0107](book/06-renting-and-buying-a-home.md#au-0107) · [AU-0138](book/08-super-tax-and-insurance.md#au-0138)

## Moneysmart：储蓄账户

原文标题：Moneysmart: Savings accounts

[打开来源](https://moneysmart.gov.au/banking/savings-accounts)

用于：[AU-0109](book/07-banking-and-debt.md#au-0109)

## Moneysmart：存下应急基金

原文标题：Moneysmart: Save for an emergency fund

[打开来源](https://moneysmart.gov.au/saving/save-for-an-emergency-fund)

用于：[AU-0110](book/07-banking-and-debt.md#au-0110)

## Moneysmart：还清您的信用卡

原文标题：Moneysmart: Pay off your credit card

[打开来源](https://moneysmart.gov.au/credit-cards/pay-off-your-credit-card)

用于：[AU-0111](book/07-banking-and-debt.md#au-0111)

## Moneysmart：财务困难

原文标题：Moneysmart: Financial hardship

[打开来源](https://moneysmart.gov.au/managing-debt/financial-hardship)

用于：[AU-0112](book/07-banking-and-debt.md#au-0112)

## Moneysmart：信用评分和信用报告

原文标题：Moneysmart: Credit scores and credit reports

[打开来源](https://moneysmart.gov.au/managing-debt/credit-scores-and-credit-reports)

用于：[AU-0113](book/07-banking-and-debt.md#au-0113)

## Moneysmart：信用修复

原文标题：Moneysmart: Credit repair

[打开来源](https://moneysmart.gov.au/managing-debt/credit-repair)

用于：[AU-0113](book/07-banking-and-debt.md#au-0113)

## Moneysmart：先买后付服务

原文标题：Moneysmart: Buy now pay later services

[打开来源](https://moneysmart.gov.au/other-ways-to-borrow/buy-now-pay-later-services)

用于：[AU-0114](book/07-banking-and-debt.md#au-0114)

## Moneysmart：联名账户

原文标题：Moneysmart: Joint accounts

[打开来源](https://moneysmart.gov.au/banking/joint-accounts)

用于：[AU-0117](book/07-banking-and-debt.md#au-0117)

## Moneysmart：债务整合和再融资

原文标题：Moneysmart: Debt consolidation and refinancing

[打开来源](https://moneysmart.gov.au/managing-debt/debt-consolidation-and-refinancing)

用于：[AU-0118](book/07-banking-and-debt.md#au-0118) · [AU-0124](book/07-banking-and-debt.md#au-0124) · [AU-0125](book/07-banking-and-debt.md#au-0125) · [AU-0157](book/09-money-help-and-disability-support.md#au-0157)

## Moneysmart：成为贷款担保人

原文标题：Moneysmart: Going guarantor on a loan

[打开来源](https://moneysmart.gov.au/loans/going-guarantor-on-a-loan)

用于：[AU-0119](book/07-banking-and-debt.md#au-0119)

## Moneysmart：与收债人打交道

原文标题：Moneysmart: Dealing with debt collectors

[打开来源](https://moneysmart.gov.au/managing-debt/dealing-with-debt-collectors)

用于：[AU-0120](book/07-banking-and-debt.md#au-0120) · [AU-0121](book/07-banking-and-debt.md#au-0121) · [AU-0152](book/09-money-help-and-disability-support.md#au-0152)

## Moneysmart：如何检查您的退休金

原文标题：Moneysmart: How to check your super

[打开来源](https://moneysmart.gov.au/grow-your-super/how-to-check-your-super)

用于：[AU-0127](book/08-super-tax-and-insurance.md#au-0127)

## ATO：报告我的雇主未缴纳的养老金缴款

原文标题：ATO: Report unpaid super contributions from my employer

[打开来源](https://www.ato.gov.au/calculators-and-tools/super-report-unpaid-super-contributions-from-my-employer)

用于：[AU-0127](book/08-super-tax-and-insurance.md#au-0127)

## Moneysmart：整合养老金基金

原文标题：Moneysmart: Consolidating super funds

[打开来源](https://moneysmart.gov.au/how-super-works/consolidating-super-funds)

用于：[AU-0128](book/08-super-tax-and-insurance.md#au-0128)

## Moneysmart：找到丢失的养老金

原文标题：Moneysmart: Find lost super

[打开来源](https://moneysmart.gov.au/how-super-works/find-lost-super)

用于：[AU-0129](book/08-super-tax-and-insurance.md#au-0129)

## Moneysmart：提交纳税申报表

原文标题：Moneysmart: Lodging a tax return

[打开来源](https://moneysmart.gov.au/work-and-tax/lodging-a-tax-return)

用于：[AU-0130](book/08-super-tax-and-insurance.md#au-0130) · [AU-0141](book/08-super-tax-and-insurance.md#au-0141) · [AU-0142](book/08-super-tax-and-insurance.md#au-0142)

## 学习协助：HELP 债务和还款常见问题解答

原文标题：Study Assist: HELP debt and repayments FAQs

[打开来源](https://www.studyassist.gov.au/faqs)

用于：[AU-0131](book/08-super-tax-and-insurance.md#au-0131) · [AU-0653](book/37-overseas-work-study.md#au-0653)

## Moneysmart：如果你死了，谁会得到你的退休金

原文标题：Moneysmart: Who gets your super if you die

[打开来源](https://moneysmart.gov.au/how-super-works/who-gets-your-super-if-you-die)

用于：[AU-0133](book/08-super-tax-and-insurance.md#au-0133)

## Moneysmart：通过养老金保险

原文标题：Moneysmart: Insurance through super

[打开来源](https://moneysmart.gov.au/how-life-insurance-works/insurance-through-super)

用于：[AU-0134](book/08-super-tax-and-insurance.md#au-0134)

## Moneysmart：收入保障保险

原文标题：Moneysmart: Income protection insurance

[打开来源](https://moneysmart.gov.au/how-life-insurance-works/income-protection-insurance)

用于：[AU-0135](book/08-super-tax-and-insurance.md#au-0135)

## 明智理财：健康保险

原文标题：Moneysmart: Health insurance

[打开来源](https://moneysmart.gov.au/other-types-of-insurance/health-insurance)

用于：[AU-0136](book/08-super-tax-and-insurance.md#au-0136) · [AU-0137](book/08-super-tax-and-insurance.md#au-0137)

## Moneysmart：选择财务顾问

原文标题：Moneysmart: Choosing a financial adviser

[打开来源](https://moneysmart.gov.au/financial-advice/choosing-a-financial-adviser)

用于：[AU-0140](book/08-super-tax-and-insurance.md#au-0140) · [AU-0143](book/08-super-tax-and-insurance.md#au-0143)

## 澳洲服务局（Services Australia）：支付和服务查找器

原文标题：Services Australia: Payment and Service Finder

[打开来源](https://www.servicesaustralia.gov.au/paymentfinder)

用于：[AU-0145](book/09-money-help-and-disability-support.md#au-0145)

## Moneysmart：低收入管理

原文标题：Moneysmart: Managing on a low income

[打开来源](https://moneysmart.gov.au/budgeting/managing-on-a-low-income)

用于：[AU-0145](book/09-money-help-and-disability-support.md#au-0145) · [AU-0147](book/09-money-help-and-disability-support.md#au-0147)

## 澳洲服务局（Services Australia）：租金援助

原文标题：Services Australia: Rent Assistance

[打开来源](https://www.servicesaustralia.gov.au/rent-assistance)

用于：[AU-0146](book/09-money-help-and-disability-support.md#au-0146)

## Moneysmart：财务咨询

原文标题：Moneysmart: Financial counselling

[打开来源](https://moneysmart.gov.au/managing-debt/financial-counselling)

用于：[AU-0148](book/09-money-help-and-disability-support.md#au-0148) · [AU-0519](book/29-regional-and-remote-living.md#au-0519)

## Moneysmart：紧急金钱帮助

原文标题：Moneysmart: Urgent help with money

[打开来源](https://moneysmart.gov.au/managing-debt/urgent-help-with-money)

用于：[AU-0149](book/09-money-help-and-disability-support.md#au-0149) · [AU-0161](book/09-money-help-and-disability-support.md#au-0161)

## NDIS：资格要求

原文标题：NDIS: Eligibility requirements

[打开来源](https://ndis.gov.au/applying/eligibility-requirements/what-are-ndis-eligibility-requirements)

用于：[AU-0150](book/09-money-help-and-disability-support.md#au-0150) · [AU-0159](book/09-money-help-and-disability-support.md#au-0159)

## 澳洲服务局（Services Australia）：残疾支持养老金

原文标题：Services Australia: Disability Support Pension

[打开来源](https://www.servicesaustralia.gov.au/disability-support-pension)

用于：[AU-0150](book/09-money-help-and-disability-support.md#au-0150) · [AU-0158](book/09-money-help-and-disability-support.md#au-0158) · [AU-0160](book/09-money-help-and-disability-support.md#au-0160)

## Moneysmart：无息贷款

原文标题：Moneysmart: No Interest Loans

[打开来源](https://moneysmart.gov.au/loans/no-interest-loans)

用于：[AU-0151](book/09-money-help-and-disability-support.md#au-0151)

## Moneysmart：支付账单和罚款的问题

原文标题：Moneysmart: Problems paying bills and fines

[打开来源](https://moneysmart.gov.au/managing-debt/problems-paying-your-bills-and-fines)

用于：[AU-0153](book/09-money-help-and-disability-support.md#au-0153) · [AU-0154](book/09-money-help-and-disability-support.md#au-0154)

## 澳洲服务局（Services Australia）：移动服务中心

原文标题：Services Australia: Mobile service centres

[打开来源](https://www.servicesaustralia.gov.au/mobile-service-centres)

用于：[AU-0155](book/09-money-help-and-disability-support.md#au-0155) · [AU-0507](book/29-regional-and-remote-living.md#au-0507)

## Moneysmart：财务滥用

原文标题：Moneysmart: Financial abuse

[打开来源](https://moneysmart.gov.au/family-and-relationships/financial-abuse)

用于：[AU-0156](book/09-money-help-and-disability-support.md#au-0156)

## Services Australia——有人代表您与 Centrelink 或老年护理机构合作

原文标题：Services Australia — someone to act for you with Centrelink or aged care

[打开来源](https://www.servicesaustralia.gov.au/someone-to-act-for-you-with-centrelink-or-aged-care?context=22526)

用于：[AU-0162](book/09-money-help-and-disability-support.md#au-0162)

## 公平工作制度

原文标题：Fair Work system

[打开来源](https://www.fairwork.gov.au/about-us/workplace-laws/fair-work-system)

用于：[AU-0163](book/10-work-rights.md#au-0163)

## 薪酬和条件工具

原文标题：Pay and Conditions Tool

[打开来源](https://calculate.fairwork.gov.au/)

用于：[AU-0163](book/10-work-rights.md#au-0163)

## 记录保存和工资单

原文标题：Record-keeping and pay slips

[打开来源](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/record-keeping-pay-slips)

用于：[AU-0164](book/10-work-rights.md#au-0164)

## 家庭和家庭暴力假

原文标题：Family and domestic violence leave

[打开来源](https://www.fairwork.gov.au/leave/family-and-domestic-violence-leave)

用于：[AU-0165](book/10-work-rights.md#au-0165)

## 公平工作：不公平解雇

原文标题：Fair Work: unfair dismissal

[打开来源](https://www.fairwork.gov.au/ending-employment/help-with-termination/unfair-dismissal)

用于：[AU-0166](book/10-work-rights.md#au-0166)

## 法律援助 NSW：选择驳回索赔

原文标题：Legal Aid NSW: choosing a dismissal claim

[打开来源](https://www.legalaid.nsw.gov.au/my-problem-is-about/my-job/termination-of-employment/how-do-i-choose)

用于：[AU-0166](book/10-work-rights.md#au-0166)

## WHS 监管机构和工人赔偿当局

原文标题：WHS regulators and workers' compensation authorities

[打开来源](https://www.safeworkaustralia.gov.au/law-and-regulation/whs-regulators-and-workers-compensation-authorities-contact-information)

用于：[AU-0167](book/10-work-rights.md#au-0167)

## 断开连接的权利

原文标题：Right to disconnect

[打开来源](https://www.fairwork.gov.au/employment-conditions/right-to-disconnect)

用于：[AU-0168](book/10-work-rights.md#au-0168)

## 公平工作：无偿试用

原文标题：Fair Work: unpaid trials

[打开来源](https://www.fairwork.gov.au/starting-employment/unpaid-work/unpaid-trials)

用于：[AU-0171](book/10-work-rights.md#au-0171)

## 公平工作：扣除工资

原文标题：Fair Work: deducting pay

[打开来源](https://www.fairwork.gov.au/pay-and-wages/deductions-and-related-issues/deducting-pay)

用于：[AU-0172](book/10-work-rights.md#au-0172)

## 公平工作：灵活的工作安排

原文标题：Fair Work: flexible working arrangements

[打开来源](https://www.fairwork.gov.au/employment-conditions/flexibility-in-the-workplace/flexible-working-arrangements)

用于：[AU-0173](book/10-work-rights.md#au-0173)

## 公平工作：薪酬保密

原文标题：Fair Work: pay secrecy

[打开来源](https://www.fairwork.gov.au/pay-and-wages/pay-secrecy)

用于：[AU-0174](book/10-work-rights.md#au-0174)

## 就业和劳资关系部：免费 TAFE

原文标题：Department of Employment and Workplace Relations: Free TAFE

[打开来源](https://www.dewr.gov.au/skills-reform/free-tafe)

用于：[AU-0181](book/11-education-and-career.md#au-0181)

## ASQA：选择课程和提供者

原文标题：ASQA: choose a course and provider

[打开来源](https://www.asqa.gov.au/for-students/choose-a-course-and-provider)

用于：[AU-0182](book/11-education-and-career.md#au-0182)

## ASQA：学分转移和先前学习的认可

原文标题：ASQA: credit transfer and recognition of prior learning

[打开来源](https://www.asqa.gov.au/for-students/credit-transfer-and-recognition-prior-learning)

用于：[AU-0183](book/11-education-and-career.md#au-0183)

## USI VET 成绩单

原文标题：USI VET transcripts

[打开来源](https://www.usi.gov.au/usi-vet-transcripts)

用于：[AU-0184](book/11-education-and-career.md#au-0184)

## 学习协助：HECS-HELP

原文标题：Study Assist: HECS-HELP

[打开来源](https://www.studyassist.gov.au/financial-and-study-support/hecs-help)

用于：[AU-0185](book/11-education-and-career.md#au-0185)

## 公平工作：学徒和实习生工资标准

原文标题：Fair Work: apprentice and trainee pay rates

[打开来源](https://www.fairwork.gov.au/pay-and-wages/minimum-wages/apprentice-and-trainee-pay-rates)

用于：[AU-0186](book/11-education-and-career.md#au-0186)

## Moneysmart：人际关系和金钱

原文标题：Moneysmart: relationships and money

[打开来源](https://moneysmart.gov.au/family-and-relationships/relationships-and-money)

用于：[AU-0199](book/12-relationships-and-children.md#au-0199)

## 联邦巡回法院和家庭法院：事实上的关系

原文标题：Federal Circuit and Family Court: de facto relationships

[打开来源](https://www.fcfcoa.gov.au/fl/pubs/defacto)

用于：[AU-0200](book/12-relationships-and-children.md#au-0200)

## WA家事法庭：事实关系信息

原文标题：Family Court of WA: de facto relationship information

[打开来源](https://www.familycourt.wa.gov.au/D/defacto_relationships.aspx)

用于：[AU-0200](book/12-relationships-and-children.md#au-0200)

## 澳洲服务局（Services Australia）：谁可以获得育儿假工资

原文标题：Services Australia: who can get Parental Leave Pay

[打开来源](https://www.servicesaustralia.gov.au/who-can-get-parental-leave-pay?context=64479)

用于：[AU-0201](book/12-relationships-and-children.md#au-0201)

## 澳洲服务局（Services Australia）：多少育儿假工资

原文标题：Services Australia: how much Parental Leave Pay

[打开来源](https://www.servicesaustralia.gov.au/how-much-parental-leave-pay-you-can-get?context=64479)

用于：[AU-0201](book/12-relationships-and-children.md#au-0201)

## 澳洲服务局（Services Australia）：儿童保育补贴资格

原文标题：Services Australia: Child Care Subsidy eligibility

[打开来源](https://www.servicesaustralia.gov.au/who-can-get-child-care-subsidy?context=41186)

用于：[AU-0202](book/12-relationships-and-children.md#au-0202)

## 澳洲服务局（Services Australia）：2026 儿童保育变更

原文标题：Services Australia: 2026 childcare changes

[打开来源](https://www.servicesaustralia.gov.au/hank-jongens-january-column-1-january-changes-to-child-care)

用于：[AU-0202](book/12-relationships-and-children.md#au-0202)

## 在线家庭关系：家庭调解

原文标题：Family Relationships Online: family mediation

[打开来源](https://www.familyrelationships.gov.au/separation/family-mediation-dispute-res)

用于：[AU-0203](book/12-relationships-and-children.md#au-0203)

## 在线家庭关系：育儿协议

原文标题：Family Relationships Online: parenting agreements

[打开来源](https://www.familyrelationships.gov.au/parenting/parenting-agreements)

用于：[AU-0203](book/12-relationships-and-children.md#au-0203)

## 1800RESPECT：安全规划

原文标题：1800RESPECT: safety planning

[打开来源](https://1800respect.org.au/help-and-support/safety-planning)

用于：[AU-0204](book/12-relationships-and-children.md#au-0204)

## 我的老年护理：家庭支持

原文标题：My Aged Care: Support at Home

[打开来源](https://www.myagedcare.gov.au/support-at-home)

用于：[AU-0217](book/13-ageing-and-bereavement.md#au-0217)

## 我的老年护理：申请评估

原文标题：My Aged Care: apply for an assessment

[打开来源](https://www.myagedcare.gov.au/how-apply-assessment)

用于：[AU-0217](book/13-ageing-and-bereavement.md#au-0217)

## Moneysmart：遗嘱和授权书

原文标题：Moneysmart: wills and powers of attorney

[打开来源](https://moneysmart.gov.au/plan-for-your-retirement/wills-and-powers-of-attorney)

用于：[AU-0218](book/13-ageing-and-bereavement.md#au-0218) · [AU-0219](book/13-ageing-and-bereavement.md#au-0219) · [AU-0501](book/28-retirement-transitions.md#au-0501) · [AU-0502](book/28-retirement-transitions.md#au-0502)

## 卫生部：预先护理指令

原文标题：Department of Health: advance care directive

[打开来源](https://www.health.gov.au/topics/palliative-care/planning-your-palliative-care/advance-care-directive)

用于：[AU-0219](book/13-ageing-and-bereavement.md#au-0219)

## 看护者网关：该计划提供什么

原文标题：Carer Gateway: what the programme offers

[打开来源](https://www.carergateway.gov.au/about-us/what-carer-gateway)

用于：[AU-0220](book/13-ageing-and-bereavement.md#au-0220)

## 我的老年护理：老年护理院费用和费用

原文标题：My Aged Care: aged-care home costs and fees

[打开来源](https://www.myagedcare.gov.au/aged-care-home-costs-and-fees)

用于：[AU-0221](book/13-ageing-and-bereavement.md#au-0221)

## 澳洲服务局（Services Australia）：有人去世后该怎么办

原文标题：Services Australia: what to do when someone dies

[打开来源](https://www.servicesaustralia.gov.au/what-to-do-when-someone-dies?context=60101)

用于：[AU-0222](book/13-ageing-and-bereavement.md#au-0222)

## 我的老年护理：支持指导老年护理

原文标题：My Aged Care: support to navigate aged care

[打开来源](https://www.myagedcare.gov.au/get-started/getting-support-navigate-aged-care)

用于：[AU-0223](book/13-ageing-and-bereavement.md#au-0223)

## 我的老年护理：投诉和评论

原文标题：My Aged Care: complaints and reviews

[打开来源](https://www.myagedcare.gov.au/making-a-complaint)

用于：[AU-0224](book/13-ageing-and-bereavement.md#au-0224) · [AU-0225](book/13-ageing-and-bereavement.md#au-0225)

## Moneysmart：在退休时保护您的金钱

原文标题：Moneysmart: protect your money in retirement

[打开来源](https://moneysmart.gov.au/manage-your-money-in-retirement/protect-your-money-in-retirement)

用于：[AU-0226](book/13-ageing-and-bereavement.md#au-0226) · [AU-0503](book/28-retirement-transitions.md#au-0503)

## ACCC：修理、更换、退款、取消

原文标题：ACCC: repair, replace, refund, cancel

[打开来源](https://www.accc.gov.au/consumers/problem-with-a-product-or-service-you-bought/repair-replace-refund-cancel)

用于：[AU-0235](book/14-consumer-and-legal-rights.md#au-0235)

## PPSR：购买二手车前检查

原文标题：PPSR: check before buying a second-hand car

[打开来源](https://www.ppsr.gov.au/newsroom/parents)

用于：[AU-0236](book/14-consumer-and-legal-rights.md#au-0236)

## ACCC：到哪里寻求消费者帮助

原文标题：ACCC: where to go for consumer help

[打开来源](https://www.accc.gov.au/consumers/problem-with-a-product-or-service-you-bought/where-to-go-for-consumer-help)

用于：[AU-0237](book/14-consumer-and-legal-rights.md#au-0237)

## 诈骗观察：如果您被骗了该怎么办

原文标题：Scamwatch: what to do if you have been scammed

[打开来源](https://www.scamwatch.gov.au/stop-check-protect/what-to-do-if-youve-been-scammed)

用于：[AU-0238](book/14-consumer-and-legal-rights.md#au-0238) · [AU-0268](book/15-digital-security.md#au-0268)

## 总检察长部：法律援助服务

原文标题：Attorney-General's Department: legal assistance services

[打开来源](https://www.ag.gov.au/legal-system/legal-assistance-services)

用于：[AU-0239](book/14-consumer-and-legal-rights.md#au-0239)

## OAIC：提出隐私投诉之前

原文标题：OAIC: before lodging a privacy complaint

[打开来源](https://www.oaic.gov.au/privacy/privacy-complaints/lodge-a-privacy-complaint-with-us)

用于：[AU-0240](book/14-consumer-and-legal-rights.md#au-0240)

## OAIC：您可以抱怨什么

原文标题：OAIC: what you can complain about

[打开来源](https://www.oaic.gov.au/privacy/privacy-complaints/what-you-can-complain-about)

用于：[AU-0240](book/14-consumer-and-legal-rights.md#au-0240)

## ACCC：保修

原文标题：ACCC: warranties

[打开来源](https://www.accc.gov.au/consumers/buying-products-and-services/warranties)

用于：[AU-0242](book/14-consumer-and-legal-rights.md#au-0242)

## ACCC：电话营销和上门销售

原文标题：ACCC: telemarketing and door-to-door sales

[打开来源](https://www.accc.gov.au/consumers/buying-products-and-services/telemarketing-and-door-to-door-sales)

用于：[AU-0243](book/14-consumer-and-legal-rights.md#au-0243)

## 产品安全：在线购买二手产品

原文标题：Product Safety: buying second-hand products online

[打开来源](https://www.productsafety.gov.au/consumers/know-your-product-safety-rights/buy-safe-second-hand-products-online)

用于：[AU-0244](book/14-consumer-and-legal-rights.md#au-0244)

## 产品安全：召回和不安全产品

原文标题：Product Safety: recalls and unsafe products

[打开来源](https://www.productsafety.gov.au/consumers/respond-to-recalls-and-unsafe-products)

用于：[AU-0245](book/14-consumer-and-legal-rights.md#au-0245)

## 澳大利亚信号局 — 个人网络安全的第一步

原文标题：Australian Signals Directorate — Personal cyber security first steps

[打开来源](https://www.cyber.gov.au/sites/default/files/2024-05/personal-cyber-security-first-steps-guide.pdf)

用于：[AU-0253](book/15-digital-security.md#au-0253) · [AU-0255](book/15-digital-security.md#au-0255) · [AU-0256](book/15-digital-security.md#au-0256) · [AU-0259](book/15-digital-security.md#au-0259)

## 澳大利亚信号局 — 使用独特且强的密码

原文标题：Australian Signals Directorate — Use unique and strong passwords

[打开来源](https://www.cyber.gov.au/publication/personal-cyber-security-handbook/use-unique-and-strong-passwords)

用于：[AU-0254](book/15-digital-security.md#au-0254)

## 澳大利亚信号局 - 社交媒体和消息安全

原文标题：Australian Signals Directorate — Social media and messaging security

[打开来源](https://www.cyber.gov.au/sites/default/files/2026-04/Security%20tips%20for%20social%20media%20and%20messaging%20services%20%28April%202026%29.pdf)

用于：[AU-0263](book/15-digital-security.md#au-0263) · [AU-0264](book/15-digital-security.md#au-0264)

## OAIC — 响应数据泄露通知

原文标题：OAIC — Respond to a data breach notification

[打开来源](https://www.oaic.gov.au/privacy/your-privacy-rights/data-breaches/respond-to-a-data-breach-notification)

用于：[AU-0268](book/15-digital-security.md#au-0268)

## Business.gov.au — 进行市场调查

原文标题：business.gov.au — Do market research

[打开来源](https://business.gov.au/marketing-and-advertising/do-market-research)

用于：[AU-0271](book/16-small-business.md#au-0271)

## business.gov.au — 计算启动成本

原文标题：business.gov.au — Calculate start-up costs

[打开来源](https://business.gov.au/planning/new-businesses/calculate-the-start-up-costs-of-your-business)

用于：[AU-0273](book/16-small-business.md#au-0273)

## business.gov.au — 注册 ABN

原文标题：business.gov.au — Register for an ABN

[打开来源](https://business.gov.au/registrations/register-for-an-australian-business-number-abn)

用于：[AU-0274](book/16-small-business.md#au-0274)

## business.gov.au — 注册执照和许可证

原文标题：business.gov.au — Register licences and permits

[打开来源](https://business.gov.au/registrations/register-licences-and-permits)

用于：[AU-0275](book/16-small-business.md#au-0275)

## business.gov.au — 创业指南

原文标题：business.gov.au — Guide to starting a business

[打开来源](https://business.gov.au/guide/starting)

用于：[AU-0276](book/16-small-business.md#au-0276)

## Business.gov.au — 现金流

原文标题：business.gov.au — Cash flow

[打开来源](https://business.gov.au/finance/cash-flow)

用于：[AU-0277](book/16-small-business.md#au-0277)

## OAIC — 小型企业隐私义务

原文标题：OAIC — Small business privacy obligations

[打开来源](https://www.oaic.gov.au/privacy/privacy-guidance-for-organisations-and-government-agencies/organisations/small-business)

用于：[AU-0285](book/16-small-business.md#au-0285) · [AU-0669](book/38-online-projects.md#au-0669)

## ACMA — 避免发送垃圾邮件

原文标题：ACMA — Avoid sending spam

[打开来源](https://www.acma.gov.au/avoid-sending-spam)

用于：[AU-0286](book/16-small-business.md#au-0286) · [AU-0673](book/38-online-projects.md#au-0673)

## Business.gov.au — 知识产权

原文标题：business.gov.au — Intellectual property

[打开来源](https://business.gov.au/planning/protect-your-brand-idea-or-creation/intellectual-property)

用于：[AU-0287](book/16-small-business.md#au-0287) · [AU-0621](book/35-ai-privacy.md#au-0621) · [AU-0680](book/38-online-projects.md#au-0680)

## ASIC Moneysmart — 旅行保险

原文标题：ASIC Moneysmart — Travel insurance

[打开来源](https://moneysmart.gov.au/other-types-of-insurance/travel-insurance)

用于：[AU-0289](book/17-travel-outdoors.md#au-0289)

## Smartraveller — 护照服务

原文标题：Smartraveller — Passport services

[打开来源](https://www.smartraveller.gov.au/passports)

用于：[AU-0290](book/17-travel-outdoors.md#au-0290)

## Smartraveller——遵守海外法律

原文标题：Smartraveller — Following the law overseas

[打开来源](https://www.smartraveller.gov.au/travel-essentials/following-law)

用于：[AU-0291](book/17-travel-outdoors.md#au-0291)

## NSW 国家公园 — 三思而后行 TREK

原文标题：NSW National Parks — Think Before You TREK

[打开来源](https://www.nationalparks.nsw.gov.au/safety/bushwalking-safety/think-before-you-trek)

用于：[AU-0292](book/17-travel-outdoors.md#au-0292) · [AU-0293](book/17-travel-outdoors.md#au-0293)

## NSW SES — 防洪准备

原文标题：NSW SES — Prepare for a flood

[打开来源](https://www.ses.nsw.gov.au/plan-and-prepare/flood)

用于：[AU-0294](book/17-travel-outdoors.md#au-0294)

## 澳洲服务局（Services Australia）：GP 慢性病管理计划

原文标题：Services Australia: GP chronic condition management plan

[打开来源](https://www.servicesaustralia.gov.au/gp-chronic-condition-management-plan?context=20)

用于：[AU-0325](book/19-chronic-conditions.md#au-0325)

## 健康直达：糖尿病

原文标题：Healthdirect: diabetes

[打开来源](https://www.healthdirect.gov.au/diabetes)

用于：[AU-0327](book/19-chronic-conditions.md#au-0327) · [AU-0328](book/19-chronic-conditions.md#au-0328)

## Healthdirect：高血压 高血压

原文标题：Healthdirect: high blood pressure hypertension

[打开来源](https://www.healthdirect.gov.au/high-blood-pressure-hypertension)

用于：[AU-0329](book/19-chronic-conditions.md#au-0329)

## 健康直达：胆固醇

原文标题：Healthdirect: cholesterol

[打开来源](https://www.healthdirect.gov.au/cholesterol)

用于：[AU-0330](book/19-chronic-conditions.md#au-0330)

## 健康指导：关节炎

原文标题：Healthdirect: arthritis

[打开来源](https://www.healthdirect.gov.au/arthritis)

用于：[AU-0331](book/19-chronic-conditions.md#au-0331)

## Healthdirect：慢性疼痛

原文标题：Healthdirect: chronic pain

[打开来源](https://www.healthdirect.gov.au/chronic-pain)

用于：[AU-0332](book/19-chronic-conditions.md#au-0332) · [AU-0333](book/19-chronic-conditions.md#au-0333)

## 健康直达：慢性阻塞性肺病

原文标题：Healthdirect: copd

[打开来源](https://www.healthdirect.gov.au/copd)

用于：[AU-0334](book/19-chronic-conditions.md#au-0334)

## Healthdirect：长期新冠疫情

原文标题：Healthdirect: long covid

[打开来源](https://www.healthdirect.gov.au/long-covid)

用于：[AU-0335](book/19-chronic-conditions.md#au-0335)

## Healthdirect：慢性肾脏病

原文标题：Healthdirect: chronic kidney disease

[打开来源](https://www.healthdirect.gov.au/chronic-kidney-disease)

用于：[AU-0336](book/19-chronic-conditions.md#au-0336)

## Healthdirect：偏头痛

原文标题：Healthdirect: migraine

[打开来源](https://www.healthdirect.gov.au/migraine)

用于：[AU-0337](book/19-chronic-conditions.md#au-0337)

## Healthdirect：子宫内膜异位症

原文标题：Healthdirect: endometriosis

[打开来源](https://www.healthdirect.gov.au/endometriosis)

用于：[AU-0338](book/19-chronic-conditions.md#au-0338)

## Healthdirect：更年期

原文标题：Healthdirect: menopause

[打开来源](https://www.healthdirect.gov.au/menopause)

用于：[AU-0339](book/19-chronic-conditions.md#au-0339)

## 健康指导：骨质疏松症

原文标题：Healthdirect: osteoporosis

[打开来源](https://www.healthdirect.gov.au/osteoporosis)

用于：[AU-0340](book/19-chronic-conditions.md#au-0340)

## 健康直达：癫痫

原文标题：Healthdirect: epilepsy

[打开来源](https://www.healthdirect.gov.au/epilepsy)

用于：[AU-0341](book/19-chronic-conditions.md#au-0341)

## Healthdirect：肠易激综合症

原文标题：Healthdirect: irritable bowel syndrome ibs

[打开来源](https://www.healthdirect.gov.au/irritable-bowel-syndrome-ibs)

用于：[AU-0342](book/19-chronic-conditions.md#au-0342)

## Healthdirect：规划您的怀孕

原文标题：Healthdirect: Planning for your pregnancy

[打开来源](https://www.healthdirect.gov.au/planning-for-your-pregnancy)

用于：[AU-0343](book/20-pregnancy-and-birth.md#au-0343)

## NSW 健康：怀孕护理选择

原文标题：NSW Health: Pregnancy care options

[打开来源](https://www.health.nsw.gov.au/kidsfamilies/MCFhealth/pregnancy/Pages/healthcare-options.aspx)

用于：[AU-0344](book/20-pregnancy-and-birth.md#au-0344)

## Better Health Channel：支付怀孕、分娩和新生儿护理费用

原文标题：Better Health Channel: Paying for pregnancy, birth and newborn care

[打开来源](https://www.betterhealth.vic.gov.au/health/servicesandsupport/paying-for-pregnancy-birth-and-newborn-care)

用于：[AU-0345](book/20-pregnancy-and-birth.md#au-0345)

## NSW 健康：怀孕选择

原文标题：NSW Health: Pregnancy choices

[打开来源](https://www.health.nsw.gov.au/pregnancyoptions)

用于：[AU-0346](book/20-pregnancy-and-birth.md#au-0346)

## 更好健康频道：怀孕与饮食

原文标题：Better Health Channel: Pregnancy and diet

[打开来源](https://www.betterhealth.vic.gov.au/health/healthyliving/pregnancy-and-diet)

用于：[AU-0347](book/20-pregnancy-and-birth.md#au-0347) · [AU-0348](book/20-pregnancy-and-birth.md#au-0348)

## 更健康频道：怀孕——药物、毒品和酒精

原文标题：Better Health Channel: Pregnancy — medication, drugs and alcohol

[打开来源](https://www.betterhealth.vic.gov.au/health/healthyliving/pregnancy-medication-drugs-and-alcohol)

用于：[AU-0349](book/20-pregnancy-and-birth.md#au-0349) · [AU-0350](book/20-pregnancy-and-birth.md#au-0350)

## NSW 健康：怀孕

原文标题：NSW Health: Pregnancy

[打开来源](https://www.health.nsw.gov.au/kidsfamilies/MCFhealth/pregnancy/Pages/default.aspx)

用于：[AU-0351](book/20-pregnancy-and-birth.md#au-0351)

## Healthdirect：先兆子痫

原文标题：Healthdirect: Pre-eclampsia

[打开来源](https://www.healthdirect.gov.au/pre-eclampsia)

用于：[AU-0352](book/20-pregnancy-and-birth.md#au-0352)

## NSW 健康：怀孕和生育的同意要求

原文标题：NSW Health: Consent requirements for pregnancy and birth

[打开来源](https://www.health.nsw.gov.au/kidsfamilies/MCFhealth/maternity/Pages/consent-req-pregnancy-birth.aspx)

用于：[AU-0353](book/20-pregnancy-and-birth.md#au-0353) · [AU-0354](book/20-pregnancy-and-birth.md#au-0354)

## 更好的健康频道：怀孕和分娩护理选择

原文标题：Better Health Channel: Pregnancy and birth care options

[打开来源](https://www.betterhealth.vic.gov.au/health/servicesandsupport/pregnancy-and-birth-care-options)

用于：[AU-0355](book/20-pregnancy-and-birth.md#au-0355)

## 更健康频道：出生后的第一天

原文标题：Better Health Channel: First days after birth

[打开来源](https://www.betterhealth.vic.gov.au/health/servicesandsupport/first-days-after-birth)

用于：[AU-0356](book/20-pregnancy-and-birth.md#au-0356) · [AU-0357](book/20-pregnancy-and-birth.md#au-0357) · [AU-0358](book/20-pregnancy-and-birth.md#au-0358)

## Healthdirect：产后抑郁症

原文标题：Healthdirect: postnatal depression

[打开来源](https://www.healthdirect.gov.au/postnatal-depression)

用于：[AU-0359](book/20-pregnancy-and-birth.md#au-0359)

## Healthdirect：流产

原文标题：Healthdirect: miscarriage

[打开来源](https://www.healthdirect.gov.au/miscarriage)

用于：[AU-0360](book/20-pregnancy-and-birth.md#au-0360)

## 红鼻子：六项安全睡眠建议

原文标题：Red Nose: Six safe sleep recommendations

[打开来源](https://rednose.org.au/safe-sleep-and-safer-pregnancy/pregnancy-to-birth/six-safe-sleep-recommendations/)

用于：[AU-0361](book/21-babies-and-early-childhood.md#au-0361) · [AU-0362](book/21-babies-and-early-childhood.md#au-0362)

## 皇家儿童医院：母乳喂养

原文标题：Royal Children's Hospital: Breastfeeding

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Breastfeeding/)

用于：[AU-0363](book/21-babies-and-early-childhood.md#au-0363)

## 皇家儿童医院：奶瓶喂养

原文标题：Royal Children's Hospital: Bottle feeding

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Bottle_feeding/)

用于：[AU-0364](book/21-babies-and-early-childhood.md#au-0364)

## 皇家儿童医院：营养 — 婴儿和幼儿

原文标题：Royal Children's Hospital: Nutrition — babies and toddlers

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Nutrition_%E2%80%93_babies_and_toddlers/)

用于：[AU-0365](book/21-babies-and-early-childhood.md#au-0365) · [AU-0366](book/21-babies-and-early-childhood.md#au-0366) · [AU-0367](book/21-babies-and-early-childhood.md#au-0367)

## 皇家儿童医院：儿童发烧

原文标题：Royal Children's Hospital: Fever in children

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/fever_in_children/)

用于：[AU-0368](book/21-babies-and-early-childhood.md#au-0368)

## 皇家儿童医院：婴儿和儿童脱水

原文标题：Royal Children's Hospital: Dehydration in babies and children

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Dehydration/)

用于：[AU-0369](book/21-babies-and-early-childhood.md#au-0369)

## 皇家儿童医院：哭泣和不安的婴儿

原文标题：Royal Children's Hospital: Crying and unsettled babies

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Crying_and_unsettled_babies/)

用于：[AU-0370](book/21-babies-and-early-childhood.md#au-0370)

## 皇家儿童医院：了解行为——幼儿和幼儿

原文标题：Royal Children's Hospital: Understanding behaviour — toddlers and young children

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Challenging_behaviour_toddlers_and_young_children/)

用于：[AU-0371](book/21-babies-and-early-childhood.md#au-0371)

## 皇家儿童医院：便秘

原文标题：Royal Children's Hospital: Constipation

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Constipation/)

用于：[AU-0372](book/21-babies-and-early-childhood.md#au-0372)

## 皇家儿童医院：汽车座椅安全

原文标题：Royal Children's Hospital: Car seat safety

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Safety_Child_car_seats/)

用于：[AU-0373](book/21-babies-and-early-childhood.md#au-0373)

## 皇家儿童医院：神经发育和残疾：家庭

原文标题：Royal Children's Hospital: Neurodevelopment and disability: Families

[打开来源](https://www.rch.org.au/neurodevelopment-and-disability/familes/)

用于：[AU-0374](book/21-babies-and-early-childhood.md#au-0374)

## NSW 健康：儿童健康与发展

原文标题：NSW Health: Child health and development

[打开来源](https://www.health.nsw.gov.au/kidsfamilies/MCFhealth/child/Pages/development.aspx)

用于：[AU-0375](book/21-babies-and-early-childhood.md#au-0375)

## 皇家儿童医院：用水安全

原文标题：Royal Children's Hospital: Water safety

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Water_safety/)

用于：[AU-0378](book/21-babies-and-early-childhood.md#au-0378)

## RCH：睡眠问题 - 儿童和青少年

原文标题：RCH: Sleep problems – children and teens

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Bedtime_problems/)

用于：[AU-0379](book/22-school-age-and-teenagers.md#au-0379)

## RCH：心理健康——青少年

原文标题：RCH: Mental health – adolescents

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Mentalhealthadolescents/)

用于：[AU-0380](book/22-school-age-and-teenagers.md#au-0380) · [AU-0394](book/22-school-age-and-teenagers.md#au-0394)

## RCH：欺凌

原文标题：RCH: Bullying

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Bullying/)

用于：[AU-0381](book/22-school-age-and-teenagers.md#au-0381)

## RCH：理解行为——青少年和年轻人

原文标题：RCH: Understanding behaviour – teens and young people

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Challenging_behaviour_teenagers/)

用于：[AU-0382](book/22-school-age-and-teenagers.md#au-0382) · [AU-0395](book/22-school-age-and-teenagers.md#au-0395)

## RCH：期间

原文标题：RCH: Periods

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Periods/)

用于：[AU-0383](book/22-school-age-and-teenagers.md#au-0383) · [AU-0384](book/22-school-age-and-teenagers.md#au-0384)

## RCH：食物过敏

原文标题：RCH: Food allergies

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Food_allergies/)

用于：[AU-0385](book/22-school-age-and-teenagers.md#au-0385) · [AU-0386](book/22-school-age-and-teenagers.md#au-0386)

## RCH：头部受伤

原文标题：RCH: Head injury

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/head_injury/)

用于：[AU-0387](book/22-school-age-and-teenagers.md#au-0387)

## RCH：头部受伤 – 重返学校和运动

原文标题：RCH: Head injury – return to school and sport

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/Head_injury_return_to_school_and_sport/)

用于：[AU-0388](book/22-school-age-and-teenagers.md#au-0388) · [AU-0389](book/22-school-age-and-teenagers.md#au-0389)

## 澳大利亚牙科协会：牙齿外伤

原文标题：Australian Dental Association: Dental trauma

[打开来源](https://teeth.org.au/dental-trauma)

用于：[AU-0390](book/22-school-age-and-teenagers.md#au-0390) · [AU-0424](book/24-appearance-dental-and-treatment-choices.md#au-0424)

## RCH：电子烟和电子烟

原文标题：RCH: Vaping and e-cigarettes

[打开来源](https://www.rch.org.au/kidsinfo/fact_sheets/E-cigarettes_and_teens/)

用于：[AU-0391](book/22-school-age-and-teenagers.md#au-0391)

## 顶空：治疗的期望

原文标题：headspace: What to expect from therapy

[打开来源](https://headspace.org.au/explore-topics/for-young-people/what-to-expect-from-therapy/)

用于：[AU-0392](book/22-school-age-and-teenagers.md#au-0392)

## Healthdirect：学习障碍

原文标题：Healthdirect: Learning disabilities

[打开来源](https://www.healthdirect.gov.au/learning-disabilities)

用于：[AU-0393](book/22-school-age-and-teenagers.md#au-0393)

## 顶空：顶空如何提供帮助

原文标题：headspace: How headspace can help

[打开来源](https://headspace.org.au/explore-topics/for-young-people/headspace-can-help/)

用于：[AU-0396](book/22-school-age-and-teenagers.md#au-0396)

## 澳大利亚委员会：智力障碍和包容性医疗保健

原文标题：Australian Commission: Intellectual disability and inclusive health care

[打开来源](https://www.safetyandquality.gov.au/clinical-topics/intellectual-disability-and-inclusive-health-care)

用于：[AU-0397](book/23-disability-health-and-access.md#au-0397) · [AU-0400](book/23-disability-health-and-access.md#au-0400)

## NSW 健康：支持残疾人

原文标题：NSW Health: Supporting people with disability

[打开来源](https://www.health.nsw.gov.au/disability/Pages/supporting-people-with-disability.aspx)

用于：[AU-0398](book/23-disability-health-and-access.md#au-0398) · [AU-0401](book/23-disability-health-and-access.md#au-0401)

## 澳大利亚委员会：护理过渡

原文标题：Australian Commission: Transitions of care

[打开来源](https://www.safetyandquality.gov.au/clinical-topics/transitions-care)

用于：[AU-0402](book/23-disability-health-and-access.md#au-0402)

## NDIS：与残疾相关的健康支持

原文标题：NDIS: Disability-related health supports

[打开来源](https://ndis.gov.au/participants/using-your-funding/other-types-support/what-disability-related-health-support)

用于：[AU-0404](book/23-disability-health-and-access.md#au-0404) · [AU-0405](book/23-disability-health-and-access.md#au-0405)

## 残疾网关：辅助工具和设备

原文标题：Disability Gateway: Aids and equipment

[打开来源](https://www.disabilitygateway.gov.au/aids-equipment)

用于：[AU-0406](book/23-disability-health-and-access.md#au-0406) · [AU-0407](book/23-disability-health-and-access.md#au-0407)

## Healthdirect：职业治疗

原文标题：Healthdirect: Occupational therapy

[打开来源](https://www.healthdirect.gov.au/occupational-therapy)

用于：[AU-0408](book/23-disability-health-and-access.md#au-0408)

## Healthdirect：物理治疗

原文标题：Healthdirect: Physiotherapy

[打开来源](https://www.healthdirect.gov.au/physiotherapy)

用于：[AU-0409](book/23-disability-health-and-access.md#au-0409)

## Healthdirect：言语病理学

原文标题：Healthdirect: Speech pathology

[打开来源](https://www.healthdirect.gov.au/speech-pathology)

用于：[AU-0410](book/23-disability-health-and-access.md#au-0410)

## 卫生部：听力服务计划资格

原文标题：Department of Health: Hearing Services Program eligibility

[打开来源](https://www.health.gov.au/our-work/hearing-services-program/accessing/eligibility)

用于：[AU-0411](book/23-disability-health-and-access.md#au-0411)

## 卫生部：提供助听器

原文标题：Department of Health: Hearing devices available

[打开来源](https://www.health.gov.au/our-work/hearing-services-program/accessing/devices-available)

用于：[AU-0412](book/23-disability-health-and-access.md#au-0412)

## 残疾门户：健康与福祉

原文标题：Disability Gateway: Health and wellbeing

[打开来源](https://www.disabilitygateway.gov.au/health-wellbeing)

用于：[AU-0413](book/23-disability-health-and-access.md#au-0413)

## Healthdirect：失禁

原文标题：Healthdirect: Incontinence

[打开来源](https://www.healthdirect.gov.au/incontinence)

用于：[AU-0414](book/23-disability-health-and-access.md#au-0414)

## 健康指导：痤疮

原文标题：Healthdirect: acne

[打开来源](https://www.healthdirect.gov.au/acne)

用于：[AU-0415](book/24-appearance-dental-and-treatment-choices.md#au-0415) · [AU-0416](book/24-appearance-dental-and-treatment-choices.md#au-0416)

## 健康指导：湿疹

原文标题：Healthdirect: eczema

[打开来源](https://www.healthdirect.gov.au/eczema)

用于：[AU-0417](book/24-appearance-dental-and-treatment-choices.md#au-0417)

## 健康指导：头皮屑

原文标题：Healthdirect: dandruff

[打开来源](https://www.healthdirect.gov.au/dandruff)

用于：[AU-0418](book/24-appearance-dental-and-treatment-choices.md#au-0418)

## Healthdirect：脱发

原文标题：Healthdirect: alopecia

[打开来源](https://www.healthdirect.gov.au/alopecia)

用于：[AU-0419](book/24-appearance-dental-and-treatment-choices.md#au-0419)

## Healthdirect：牙齿美白

原文标题：Healthdirect: teeth whitening

[打开来源](https://www.healthdirect.gov.au/teeth-whitening)

用于：[AU-0420](book/24-appearance-dental-and-treatment-choices.md#au-0420)

## Healthdirect：正牙医生

原文标题：Healthdirect: orthodontist

[打开来源](https://www.healthdirect.gov.au/orthodontist)

用于：[AU-0421](book/24-appearance-dental-and-treatment-choices.md#au-0421)

## Healthdirect：牙龈疾病

原文标题：Healthdirect: gum disease

[打开来源](https://www.healthdirect.gov.au/gum-disease)

用于：[AU-0422](book/24-appearance-dental-and-treatment-choices.md#au-0422)

## 澳大利亚牙科协会：口干

原文标题：Australian Dental Association: Dry mouth

[打开来源](https://teeth.org.au/dry-mouth)

用于：[AU-0423](book/24-appearance-dental-and-treatment-choices.md#au-0423)

## NSW 健康：整容手术

原文标题：NSW Health: Cosmetic procedures

[打开来源](https://www.health.nsw.gov.au/patients/cosmetic/Pages/default.aspx)

用于：[AU-0425](book/24-appearance-dental-and-treatment-choices.md#au-0425)

## Healthdirect：整容手术指南

原文标题：Healthdirect: guide to cosmetic surgery

[打开来源](https://www.healthdirect.gov.au/guide-to-cosmetic-surgery)

用于：[AU-0426](book/24-appearance-dental-and-treatment-choices.md#au-0426) · [AU-0427](book/24-appearance-dental-and-treatment-choices.md#au-0427)

## TGA：化妆品注射检查表

原文标题：TGA: Cosmetic injections checklist

[打开来源](https://www.tga.gov.au/resources/explore-topic/cosmetics/cosmetic-injections/cosmetic-injections-checklist)

用于：[AU-0428](book/24-appearance-dental-and-treatment-choices.md#au-0428)

## Healthdirect：我应该检查是否患有皮肤癌？

原文标题：Healthdirect: Should I be checked for skin cancer?

[打开来源](https://www.healthdirect.gov.au/should-I-be-checked-for-skin-cancer)

用于：[AU-0429](book/24-appearance-dental-and-treatment-choices.md#au-0429)

## NSW 健康：人体艺术和纹身业务

原文标题：NSW Health: Body art and tattooing businesses

[打开来源](https://www.health.nsw.gov.au/environment/factsheets/Pages/tattooing.aspx)

用于：[AU-0430](book/24-appearance-dental-and-treatment-choices.md#au-0430)

## Healthdirect：牙科护理费用

原文标题：Healthdirect: Cost of dental care

[打开来源](https://www.healthdirect.gov.au/cost-of-dental-care)

用于：[AU-0431](book/24-appearance-dental-and-treatment-choices.md#au-0431)

## Healthdirect：牙科手术指南

原文标题：Healthdirect: Guide to dental procedures

[打开来源](https://www.healthdirect.gov.au/guide-to-dental-procedures)

用于：[AU-0432](book/24-appearance-dental-and-treatment-choices.md#au-0432)

## Moneysmart：购买和运行汽车

原文标题：Moneysmart: Buying and running a car

[打开来源](https://moneysmart.gov.au/student-life-and-money/buying-and-running-a-car)

用于：[AU-0433](book/25-transport-and-car-ownership.md#au-0433) · [AU-0434](book/25-transport-and-car-ownership.md#au-0434) · [AU-0445](book/25-transport-and-car-ownership.md#au-0445)

## 澳大利亚政府：动产证券登记册

原文标题：Australian Government: Personal Property Securities Register

[打开来源](https://www.ppsr.gov.au/)

用于：[AU-0435](book/25-transport-and-car-ownership.md#au-0435) · [AU-0450](book/25-transport-and-car-ownership.md#au-0450)

## 澳大利亚政府：车辆召回

原文标题：Australian Government: Vehicle recalls

[打开来源](https://www.vehiclerecalls.gov.au/recalls)

用于：[AU-0436](book/25-transport-and-car-ownership.md#au-0436)

## Moneysmart：选择汽车保险

原文标题：Moneysmart: Choosing car insurance

[打开来源](https://moneysmart.gov.au/car-insurance/choosing-car-insurance)

用于：[AU-0437](book/25-transport-and-car-ownership.md#au-0437) · [AU-0448](book/25-transport-and-car-ownership.md#au-0448) · [AU-0449](book/25-transport-and-car-ownership.md#au-0449)

## Moneysmart：汽车贷款

原文标题：Moneysmart: Car loans

[打开来源](https://moneysmart.gov.au/loans/car-loans)

用于：[AU-0438](book/25-transport-and-car-ownership.md#au-0438) · [AU-0447](book/25-transport-and-car-ownership.md#au-0447)

## ACCC: 汽油和燃料

原文标题：ACCC: Petrol and fuel

[打开来源](https://www.accc.gov.au/consumers/petrol-and-fuel)

用于：[AU-0439](book/25-transport-and-car-ownership.md#au-0439)

## 昆士兰州政府：长途旅行的道路安全和车辆维护

原文标题：Queensland Government: Road safety and vehicle maintenance for long trips

[打开来源](https://www.qld.gov.au/transport/safety/holiday-travel/long-trips)

用于：[AU-0440](book/25-transport-and-car-ownership.md#au-0440) · [AU-0441](book/25-transport-and-car-ownership.md#au-0441) · [AU-0515](book/29-regional-and-remote-living.md#au-0515) · [AU-0516](book/29-regional-and-remote-living.md#au-0516)

## 昆士兰州政府：疲劳驾驶

原文标题：Queensland Government: Driving tired

[打开来源](https://www.qld.gov.au/transport/safety/road-safety/driving-safely/driving-tired)

用于：[AU-0442](book/25-transport-and-car-ownership.md#au-0442)

## 澳大利亚政府：电气化

原文标题：Australian Government: Electrification

[打开来源](https://www.energy.gov.au/households/electrification)

用于：[AU-0446](book/25-transport-and-car-ownership.md#au-0446) · [AU-0462](book/26-climate-disasters-and-resilient-homes.md#au-0462) · [AU-0463](book/26-climate-disasters-and-resilient-homes.md#au-0463)

## Moneysmart：为自然灾害做好准备

原文标题：Moneysmart: Prepare for a natural disaster

[打开来源](https://moneysmart.gov.au/dealing-with-natural-disasters/how-to-prepare-for-a-natural-disaster)

用于：[AU-0451](book/26-climate-disasters-and-resilient-homes.md#au-0451) · [AU-0455](book/26-climate-disasters-and-resilient-homes.md#au-0455) · [AU-0458](book/26-climate-disasters-and-resilient-homes.md#au-0458)

## 气象局：警告和警报

原文标题：Bureau of Meteorology: Warnings and alerts

[打开来源](https://www.bom.gov.au/weather-and-climate/warnings-and-alerts)

用于：[AU-0452](book/26-climate-disasters-and-resilient-homes.md#au-0452) · [AU-0517](book/29-regional-and-remote-living.md#au-0517) · [AU-0521](book/29-regional-and-remote-living.md#au-0521)

## NSW 农村消防局：计划和准备

原文标题：NSW Rural Fire Service: Plan and prepare

[打开来源](https://www.rfs.nsw.gov.au/plan-and-prepare)

用于：[AU-0453](book/26-climate-disasters-and-resilient-homes.md#au-0453)

## NSW 国家紧急服务中心

原文标题：NSW State Emergency Service

[打开来源](https://www.ses.nsw.gov.au/)

用于：[AU-0454](book/26-climate-disasters-and-resilient-homes.md#au-0454) · [AU-0466](book/26-climate-disasters-and-resilient-homes.md#au-0466) · [AU-0467](book/26-climate-disasters-and-resilient-homes.md#au-0467)

## Moneysmart：风暴、洪水和火灾保险

原文标题：Moneysmart: Storm, flood and fire insurance

[打开来源](https://moneysmart.gov.au/home-insurance/storm-flood-and-fire-insurance)

用于：[AU-0456](book/26-climate-disasters-and-resilient-homes.md#au-0456) · [AU-0457](book/26-climate-disasters-and-resilient-homes.md#au-0457) · [AU-0468](book/26-climate-disasters-and-resilient-homes.md#au-0468)

## 澳大利亚政府：绝缘和防风

原文标题：Australian Government: Insulation and draught proofing

[打开来源](https://www.energy.gov.au/households/insulation-and-draught-proofing)

用于：[AU-0459](book/26-climate-disasters-and-resilient-homes.md#au-0459) · [AU-0460](book/26-climate-disasters-and-resilient-homes.md#au-0460)

## 澳大利亚政府：Windows

原文标题：Australian Government: Windows

[打开来源](https://www.energy.gov.au/households/windows)

用于：[AU-0461](book/26-climate-disasters-and-resilient-homes.md#au-0461)

## 能源变得简单：使用生命维持设备的客户

原文标题：Energy Made Easy: Customers using life support equipment

[打开来源](https://www.energymadeeasy.gov.au/article/customers-using-life-support-equipment)

用于：[AU-0464](book/26-climate-disasters-and-resilient-homes.md#au-0464)

## FSANZ：保质期和最佳食用日期

原文标题：FSANZ: Use-by and best-before dates

[打开来源](https://www.foodstandards.gov.au/consumer/labelling/dates)

用于：[AU-0469](book/27-food-and-household-value.md#au-0469) · [AU-0470](book/27-food-and-household-value.md#au-0470)

## FSANZ：食品安全基础知识

原文标题：FSANZ: Food safety basics

[打开来源](https://www.foodstandards.gov.au/consumer/prevention-of-foodborne-illness/food-safety-basics)

用于：[AU-0471](book/27-food-and-household-value.md#au-0471) · [AU-0472](book/27-food-and-household-value.md#au-0472) · [AU-0473](book/27-food-and-household-value.md#au-0473) · [AU-0475](book/27-food-and-household-value.md#au-0475)

## FSANZ：罐头食品，采购和储存

原文标题：FSANZ: Canned foods, purchasing and storing

[打开来源](https://www.foodstandards.gov.au/consumer/prevention-of-foodborne-illness/cannedfoods)

用于：[AU-0474](book/27-food-and-household-value.md#au-0474) · [AU-0476](book/27-food-and-household-value.md#au-0476)

## 澳大利亚政府：电器

原文标题：Australian Government: Appliances

[打开来源](https://www.energy.gov.au/households/appliances)

用于：[AU-0477](book/27-food-and-household-value.md#au-0477) · [AU-0478](book/27-food-and-household-value.md#au-0478) · [AU-0481](book/27-food-and-household-value.md#au-0481) · [AU-0485](book/27-food-and-household-value.md#au-0485)

## 澳大利亚政府：水评级

原文标题：Australian Government: Water Rating

[打开来源](https://www.waterrating.gov.au/)

用于：[AU-0479](book/27-food-and-household-value.md#au-0479) · [AU-0480](book/27-food-and-household-value.md#au-0480)

## 澳大利亚政府：节约能源速效

原文标题：Australian Government: Quick wins to save energy

[打开来源](https://www.energy.gov.au/households/quick-wins)

用于：[AU-0482](book/27-food-and-household-value.md#au-0482)

## ACCC 产品安全

原文标题：ACCC Product Safety

[打开来源](https://www.productsafety.gov.au/)

用于：[AU-0483](book/27-food-and-household-value.md#au-0483) · [AU-0484](book/27-food-and-household-value.md#au-0484) · [AU-0486](book/27-food-and-household-value.md#au-0486)

## Moneysmart：制定退休计划

原文标题：Moneysmart: Make a retirement plan

[打开来源](https://moneysmart.gov.au/plan-for-your-retirement/make-a-retirement-plan)

用于：[AU-0487](book/28-retirement-transitions.md#au-0487) · [AU-0488](book/28-retirement-transitions.md#au-0488) · [AU-0492](book/28-retirement-transitions.md#au-0492) · [AU-0493](book/28-retirement-transitions.md#au-0493)

## Moneysmart：获取您的退休金

原文标题：Moneysmart: Getting your super

[打开来源](https://moneysmart.gov.au/how-super-works/getting-your-super)

用于：[AU-0489](book/28-retirement-transitions.md#au-0489) · [AU-0494](book/28-retirement-transitions.md#au-0494)

## 澳洲服务局（Services Australia）：金融信息服务

原文标题：Services Australia: Financial Information Service

[打开来源](https://www.servicesaustralia.gov.au/financial-information-service)

用于：[AU-0490](book/28-retirement-transitions.md#au-0490) · [AU-0504](book/28-retirement-transitions.md#au-0504)

## Moneysmart：养老金和政府福利

原文标题：Moneysmart: Age Pension and government benefits

[打开来源](https://moneysmart.gov.au/retirement-income-sources/age-pension-and-government-benefits)

用于：[AU-0491](book/28-retirement-transitions.md#au-0491)

## Moneysmart：您的退休之家

原文标题：Moneysmart: Your home in retirement

[打开来源](https://moneysmart.gov.au/plan-for-your-retirement/your-home-in-retirement)

用于：[AU-0495](book/28-retirement-transitions.md#au-0495) · [AU-0497](book/28-retirement-transitions.md#au-0497)

## Moneysmart：退休后缩减规模

原文标题：Moneysmart: Downsizing in retirement

[打开来源](https://moneysmart.gov.au/manage-your-money-in-retirement/downsizing-in-retirement)

用于：[AU-0496](book/28-retirement-transitions.md#au-0496)

## Moneysmart：反向抵押贷款和房屋净值发布

原文标题：Moneysmart: Reverse mortgage and home equity release

[打开来源](https://moneysmart.gov.au/retirement-income-sources/reverse-mortgage-and-home-equity-release)

用于：[AU-0498](book/28-retirement-transitions.md#au-0498)

## Moneysmart：老年护理

原文标题：Moneysmart: Aged care

[打开来源](https://moneysmart.gov.au/manage-your-money-in-retirement/aged-care)

用于：[AU-0499](book/28-retirement-transitions.md#au-0499) · [AU-0500](book/28-retirement-transitions.md#au-0500)

## 澳大利亚政府：区域技术中心

原文标题：Australian Government: Regional Tech Hub

[打开来源](https://www.infrastructure.gov.au/department/media/news/regional-tech-hub-set-continue-tender-outcome-announced)

用于：[AU-0505](book/29-regional-and-remote-living.md#au-0505)

## 澳洲服务局（Services Australia）：代理和接入点

原文标题：Services Australia: Agents and Access Points

[打开来源](https://www.servicesaustralia.gov.au/agents-and-access-points)

用于：[AU-0508](book/29-regional-and-remote-living.md#au-0508) · [AU-0522](book/29-regional-and-remote-living.md#au-0522)

## 卫生部：远程医疗

原文标题：Department of Health: Telehealth

[打开来源](https://www.health.gov.au/topics/health-technologies-and-digital-health/about/telehealth)

用于：[AU-0509](book/29-regional-and-remote-living.md#au-0509) · [AU-0513](book/29-regional-and-remote-living.md#au-0513)

## healthdirect：农村和偏远地区的健康

原文标题：healthdirect: Rural and remote health

[打开来源](https://www.healthdirect.gov.au/rural-and-remote-health)

用于：[AU-0510](book/29-regional-and-remote-living.md#au-0510) · [AU-0511](book/29-regional-and-remote-living.md#au-0511)

## 澳洲服务局（Services Australia）：为农村和偏远澳大利亚人提供医疗保险服务

原文标题：Services Australia: Medicare services for rural and remote Australians

[打开来源](https://www.servicesaustralia.gov.au/medicare-services-for-rural-and-remote-australians?context=60092)

用于：[AU-0512](book/29-regional-and-remote-living.md#au-0512)

## 教育部：地区大学学习中心

原文标题：Department of Education: Regional University Study Hubs

[打开来源](https://www.education.gov.au/regional-university-study-hubs)

用于：[AU-0514](book/29-regional-and-remote-living.md#au-0514)

## 农业部：农村金融咨询服务

原文标题：Department of Agriculture: Rural Financial Counselling Service

[打开来源](https://www.agriculture.gov.au/ag-farm-food/drought/assistance/rural-financial-counselling-service)

用于：[AU-0518](book/29-regional-and-remote-living.md#au-0518)

## 联邦巡回法院和家庭法院：离婚概述

原文标题：Federal Circuit and Family Court: divorce overview

[打开来源](https://www.fcfcoa.gov.au/pjt/node/594)

用于：[AU-0523](book/30-separation-and-family-law.md#au-0523)

## 联邦巡回法院和家庭法院：披露承诺

原文标题：Federal Circuit and Family Court: disclosure undertaking

[打开来源](https://www.fcfcoa.gov.au/fl/forms/undertaking-disclosure)

用于：[AU-0524](book/30-separation-and-family-law.md#au-0524)

## 联邦巡回法院和家庭法院：同意令

原文标题：Federal Circuit and Family Court: consent orders

[打开来源](https://www.fcfcoa.gov.au/hdi/apply-consent-orders)

用于：[AU-0525](book/30-separation-and-family-law.md#au-0525)

## 澳洲服务局（Services Australia）：子女抚养费评估

原文标题：Services Australia: child support assessment

[打开来源](https://www.servicesaustralia.gov.au/child-support-assessment)

用于：[AU-0526](book/30-separation-and-family-law.md#au-0526)

## 澳洲服务局（Services Australia）：改变护理安排

原文标题：Services Australia: changing care arrangements

[打开来源](https://www.servicesaustralia.gov.au/changing-your-childs-care-arrangements?context=21911)

用于：[AU-0527](book/30-separation-and-family-law.md#au-0527)

## 澳洲服务局（Services Australia）：更新关系状态

原文标题：Services Australia: updating relationship status

[打开来源](https://www.servicesaustralia.gov.au/updating-your-relationship-status?context=60029)

用于：[AU-0528](book/30-separation-and-family-law.md#au-0528)

## 联邦巡回法院和家庭法院：搬迁和旅行

原文标题：Federal Circuit and Family Court: relocation and travel

[打开来源](https://www.fcfcoa.gov.au/fl/children/relocation-travel)

用于：[AU-0529](book/30-separation-and-family-law.md#au-0529)

## 总检察长部：养老金分割

原文标题：Attorney-General's Department: superannuation splitting

[打开来源](https://www.ag.gov.au/families-and-marriage/dividing-property-finances-and-superannuation-after-separation/superannuation-splitting)

用于：[AU-0530](book/30-separation-and-family-law.md#au-0530)

## 法律援助 NSW：警察权力

原文标题：Legal Aid NSW: police powers

[打开来源](https://www.legalaid.nsw.gov.au/ways-to-get-help/publications-and-resources/police-powers)

用于：[AU-0541](book/31-everyday-legal-risks-and-police-contact.md#au-0541) · [AU-0543](book/31-everyday-legal-risks-and-police-contact.md#au-0543)

## 法律援助NSW：警察和我的权利

原文标题：Legal Aid NSW: police and my rights

[打开来源](https://www.legalaid.nsw.gov.au/my-problem-is-about/a-criminal-charge/police-and-my-rights)

用于：[AU-0542](book/31-everyday-legal-risks-and-police-contact.md#au-0542)

## 总检察长部：法定声明

原文标题：Attorney-General's Department: statutory declarations

[打开来源](https://www.ag.gov.au/legal-system/statutory-declarations)

用于：[AU-0551](book/31-everyday-legal-risks-and-police-contact.md#au-0551)

## 公平工作：独立承包商

原文标题：Fair Work: independent contractors

[打开来源](https://www.fairwork.gov.au/find-help-for/independent-contractors)

用于：[AU-0559](book/32-gig-work-contracting-and-self-employment-rights.md#au-0559)

## 公平工作：虚假承包

原文标题：Fair Work: sham contracting

[打开来源](https://www.fairwork.gov.au/find-help-for/independent-contractors/sham-contracting)

用于：[AU-0560](book/32-gig-work-contracting-and-self-employment-rights.md#au-0560)

## Business.gov.au：影响合同的法律

原文标题：business.gov.au: laws affecting contracts

[打开来源](https://business.gov.au/people/contractors/laws-affecting-contracts)

用于：[AU-0561](book/32-gig-work-contracting-and-self-employment-rights.md#au-0561)

## 公平工作：像雇员一样的工人

原文标题：Fair Work: employee-like workers

[打开来源](https://www.fairwork.gov.au/find-help-for/regulated-workers/employee-like-workers)

用于：[AU-0562](book/32-gig-work-contracting-and-self-employment-rights.md#au-0562)

## Business.gov.au：承包商权利和保护

原文标题：business.gov.au: contractor rights and protections

[打开来源](https://business.gov.au/people/contractors/contractor-rights-and-protections)

用于：[AU-0563](book/32-gig-work-contracting-and-self-employment-rights.md#au-0563)

## AEC：入学问题

原文标题：AEC: enrolment questions

[打开来源](https://www.aec.gov.au/FAQs/Enrolment.htm)

用于：[AU-0577](book/33-turning-18-and-choosing-a-path.md#au-0577)

## AEC：谁需要注册

原文标题：AEC: who needs to enrol

[打开来源](https://www.aec.gov.au/community/criteria.htm)

用于：[AU-0577](book/33-turning-18-and-choosing-a-path.md#au-0577)

## 澳洲服务局（Services Australia）：您自己的医疗保险卡

原文标题：Services Australia: your own Medicare card

[打开来源](https://www.servicesaustralia.gov.au/have-your-own-medicare-card-and-number-if-youre-15-or-older-and-enrolled-medicare?context=21796)

用于：[AU-0578](book/33-turning-18-and-choosing-a-path.md#au-0578)

## myGov：获取或找到您的 TFN

原文标题：myGov: get or find your TFN

[打开来源](https://my.gov.au/en/services/work/currently-employed/tax-when-you-work/getting-a-tax-file-number)

用于：[AU-0579](book/33-turning-18-and-choosing-a-path.md#au-0579)

## 澳洲服务局（Services Australia）：学生和学徒的永久独立

原文标题：Services Australia: permanent independence for students and apprentices

[打开来源](https://www.servicesaustralia.gov.au/permanent-independence-for-youth-allowance-for-students-and-australian-apprentices?context=43916)

用于：[AU-0580](book/33-turning-18-and-choosing-a-path.md#au-0580)

## OAIC — 隐私和商用 AI 产品

原文标题：OAIC — Privacy and commercially available AI products

[打开来源](https://www.oaic.gov.au/privacy/privacy-guidance-for-organisations-and-government-agencies/guidance-on-privacy-and-the-use-of-commercially-available-ai-products)

用于：[AU-0613](book/35-ai-privacy.md#au-0613)

## 电子安全——Deepfakes

原文标题：eSafety — Deepfakes

[打开来源](https://www.esafety.gov.au/industry/tech-trends-and-challenges/deepfakes)

用于：[AU-0618](book/35-ai-privacy.md#au-0618) · [AU-0629](book/35-ai-privacy.md#au-0629)

## myGov — 搬家

原文标题：myGov — Moving house

[打开来源](https://my.gov.au/en/services/living-arrangements/finding-renting-and-buying-a-home/owning-a-home/moving-house)

用于：[AU-0637](book/36-moving-home.md#au-0637)

## 澳洲服务局（Services Australia） — 搬家

原文标题：Services Australia — Moving house

[打开来源](https://www.servicesaustralia.gov.au/moving-house?context=60023)

用于：[AU-0638](book/36-moving-home.md#au-0638)

## 澳洲服务局（Services Australia） — 海外医疗保健规划

原文标题：Services Australia — Health care planning overseas

[打开来源](https://www.servicesaustralia.gov.au/health-care-planning-when-going-overseas?context=60040)

用于：[AU-0655](book/37-overseas-work-study.md#au-0655)

## 药物管制办公室 — 携带药物旅行

原文标题：Office of Drug Control — Travel with medicines

[打开来源](https://www.odc.gov.au/travellers/travelling-or-australia-medicines-and-medical-devices)

用于：[AU-0656](book/37-overseas-work-study.md#au-0656)

## 澳洲服务局（Services Australia） — 在澳大利亚境外付款

原文标题：Services Australia — Payments while outside Australia

[打开来源](https://www.servicesaustralia.gov.au/payments-while-outside-australia?context=51411)

用于：[AU-0657](book/37-overseas-work-study.md#au-0657)

## 教育部 — 偿还 HELP 贷款和海外征费

原文标题：Department of Education — Repaying HELP loans and overseas levy

[打开来源](https://www.education.gov.au/higher-education-publications/higher-education-administrative-information-providers-october-2021/35-repaying-help-loans-and-indexation-arrangements)

用于：[AU-0659](book/37-overseas-work-study.md#au-0659)

## 澳大利亚选举委员会 — 海外招生

原文标题：Australian Electoral Commission — Overseas enrolment

[打开来源](https://www.aec.gov.au/overseas/enrolment.htm)

用于：[AU-0660](book/37-overseas-work-study.md#au-0660)

## ACCC — 价格显示

原文标题：ACCC — Price displays

[打开来源](https://www.accc.gov.au/business/pricing/price-displays)

用于：[AU-0671](book/38-online-projects.md#au-0671)

## ACCC — 小型企业的权利和责任

原文标题：ACCC — Small business rights and responsibilities

[打开来源](https://www.accc.gov.au/business/small-business/small-business-toolkit/rights-and-responsibilities-of-your-small-business/small-business-rights-and-responsibilities)

用于：[AU-0672](book/38-online-projects.md#au-0672)

## eSafety — 安全设计

原文标题：eSafety — Safety by Design

[打开来源](https://www.esafety.gov.au/industry/safety-by-design/faq)

用于：[AU-0681](book/38-online-projects.md#au-0681)

