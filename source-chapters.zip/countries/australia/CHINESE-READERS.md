# 中国读者身份与落地路径

这份澳洲指南服务三种生活场景：定居、持签证工作或学习、旅游与短期探亲。定居者再区分为华人澳洲公民和仍持中国国籍的永久居民（PR）。“华人”是文化背景，“中国籍”是国籍；两者不能互换，PR 也不等于公民。

**本附录所列关键身份政策于 2026-10-09 核对官方信息。**它帮助你选择正确入口，不替机构决定个人资格，也不表示原书全部医疗、法律与财务内容经过新一轮复核。正文每条都附有身份路径和不适用时的替代行动。

## 先分清四种经常混淆的身份

| 事项 | 判断依据 | 不能据此推定 |
| --- | --- | --- |
| 国籍与护照 | 本人实际持有的有效旅行证件和国籍 | 华人背景不等于中国籍；住在澳洲不等于澳洲公民 |
| 入境、工作与学习权限 | 签证类别、获批信和当前 VEVO 条件 | ABN、学校录取、雇主口头承诺不等于合法工作许可 |
| Medicare、福利、NDIS、学习资助 | 各项目单独规定的身份、居住和其他条件 | PR 不意味着所有项目都能用；有一个福利账户不意味着其他项目获批 |
| 税务居民 | 税法及实际居住、工作等事实 | 不单靠国籍、PR 或学生签证标签决定 |

签证持有人先保存[VEVO 当前条件](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/)，同时查看获批信。PR 的返澳旅行权限也应检查；长期居留权和签证旅行权限的日期不是同一个概念。[Home Affairs：理解 VEVO 信息](https://immi.homeaffairs.gov.au/visas/already-have-a-visa/check-visa-details-and-conditions/check-conditions-online/visa-holders)

## 三条落地路线

| 你的场景 | 先做的事 | 优先阅读 |
| --- | --- | --- |
| 华人公民／中国籍 PR 定居 | 确认医疗登记，核对租房与水电账户，梳理劳动／养老金资料，再逐项核对福利和学习资助 | [医疗](book/03-healthcare-and-medicines.md)、[住房](book/06-renting-and-buying-a-home.md)、[养老金税务](book/08-super-tax-and-insurance.md)、[工作](book/10-work-rights.md) |
| 中国籍工作／学生等临时签证 | 保存签证条件，确认 OSHC／OVHC、住房合同与学校／雇主联系人，安排离境或换号后的账户恢复 | [账户安全](book/15-digital-security.md)、[学习职业](book/11-education-and-career.md)、[劳动权益](book/10-work-rights.md)、[零工](book/32-gig-work-contracting-and-self-employment-rights.md) |
| 中国游客／短期探亲 | 保存住宿英文地址、000、保险协助电话与返程安排；入境前查申报、药品、驾驶与支付条件 | [紧急情况](book/01-emergencies.md)、[出行](book/17-travel-outdoors.md)、[交通](book/25-transport-and-car-ownership.md)、[消费](book/34-buying-wisely-and-avoiding-traps.md) |

## 医疗：先确认谁付钱，再预约；紧急情况先求救

Medicare 有自己的登记条件：在澳居住的公民、永久居民，以及某些永居申请者和部长令覆盖的临时居民可按相应路径核对。持有中国护照或普通学生／工作签证，本身不建立 Medicare 资格。[Services Australia：登记 Medicare](https://www.servicesaustralia.gov.au/enrolling-medicare)

中国不在澳洲互惠医疗协议国家名单内；普通中国游客不能据此享受互惠医保。国际学生先核对 OSHC，其他临时居民核对 OVHC 或符合本人条件的保险，游客核对旅行保险。居民私保、海外访客保单及其税务待遇不能混为一谈。[澳洲政府：海外学生与访客医疗保障](https://www.privatehealth.gov.au/health_insurance/overseas/index.htm)、[OVHC 说明](https://www.privatehealth.gov.au/health_insurance/overseas/overseas_visitors_health_cover.htm)

实际操作：打电话给诊所时问清总费用、是否 Medicare 直接结算（bulk billing）、你的身份是否适用、保险能报多少、当天付多少；需要转诊或长期用药时带上中文病历的必要英文说明和药物通用名。没有补助资格也可以询问自费服务，而不是把不适用的补助当成预计折扣。危及生命先拨 000；电话免费不等于救护车或治疗免费。

也有不要求 Medicare 卡的公共服务：Medicare Mental Health Centres 向在澳需要支持的人提供免费帮助，无需公民身份、转诊或预约，临时签证者与游客也可使用；转介后的其他服务费用另行核对。它不是紧急危机服务。[Services Australia 官方说明](https://www.servicesaustralia.gov.au/mental-health-care-and-medicare)

## 工作：签证允许做什么，与雇主必须给什么待遇分开

核对 VEVO 的工作条件后再接受工作。学生签证在课程进行期间通常有每两周 48 小时的上限，部分研究型课程等存在不同规则；以本人签证条件和官方当前说明为准。[学生签证 500](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500)

签证持有人和移民雇员享有适用的最低工资与劳动保护。雇主不能因为你是中国学生或临时签证者而自行降低标准，也不能自行取消你的签证。保存合同、排班、工资单和自己的工时记录。[Fair Work：签证持有人的劳动权益](https://www.fairwork.gov.au/tools-and-resources/fact-sheets/rights-and-obligations/visa-holders-and-migrant-workers-workplace-rights-and-entitlements)

旅游或商务访问许可不能简单当作在澳工作许可；商务会议与实际在澳提供劳务可能属于不同活动。办理 ABN 不会赋予你签证未允许的工作或自雇权限。[Home Affairs：临时访问与商务活动](https://www.homeaffairs.gov.au/research-and-statistics/statistics/country-profiles/temporary-migration)

## 福利、残障与照护：不要把项目放在同一个篮子里

- **Centrelink：**具体补助有自己的居住、收入、资产或其他条件；新到居民可能面临等待期，项目、起算日和豁免要分别查询。[新到居民等待期](https://www.servicesaustralia.gov.au/newly-arrived-residents-waiting-period)
- **NDIS：**普通中国工作／学生签证与游客不具备通常所需的居住身份。公民或 PR 还要满足在澳居住、申请年龄及残障／早期干预要求；申请时须未满 65 岁。[居住条件](https://ndis.gov.au/applying/eligibility-requirements/what-are-residence-requirements)、[完整资格步骤](https://ndis.gov.au/applying/eligibility-requirements/how-check-your-eligibility)
- **托儿补助 CCS：**可依据申请人或伴侣的身份，某些临时签证或特殊情况另有路径，不能把所有临时居民一概算作可领取或不可领取。未确认前按全额托儿费预算。[CCS 居住规则](https://www.servicesaustralia.gov.au/residence-rules-for-child-care-subsidy)
- **育儿假补助：**工作、收入、照护与居住要求分别核对，不因孩子在澳出生自动获批。政府补助和雇主提供的假期也要分清。[Parental Leave Pay 资格](https://www.servicesaustralia.gov.au/who-can-get-parental-leave-pay)
- **养老服务：**不要直接把 Age Pension、Medicare 和养老照护评估当作同一项目。某些养老院服务对非澳洲居民也有收费评估规则，应根据需要和具体服务询问，而不是笼统宣称“游客绝对不能用”。[申请评估](https://www.myagedcare.gov.au/should-i-apply)、[养老院条件与费用](https://www.myagedcare.gov.au/aged-care-programs/aged-care-homes)

无资格或仍在等待时，向服务方、保险方、学校或社区机构询问实际可接受的援助、自费方案和临时安排；不要在申请尚未获批时把款项列为确定收入。

## 学习：本地学费、补贴学位与 HELP 贷款不是一回事

普通 PR 不能只因是“本地学生”就预设能拿 HECS-HELP。该贷款有具体国籍／签证类别、居住、课程与其他条件；一些特殊类别另有规则。由学校用本人材料正式核对 CSP 与贷款各自资格。普通国际生可改查学校奖学金、助学金及完整学费，不把政府居民贷款当作默认融资来源。[HECS-HELP](https://www.studyassist.gov.au/financial-and-study-support/hecs-help)、[Study Assist 资格工具](https://www.studyassist.gov.au/eligibility-tool)

## 税务与养老金：跨境生活多核一层

澳洲税务居民身份与移民身份不同，公民、PR 或临时签证标签都不足以单独下结论。把中澳收入、资产、出入境日期和配偶情况整理清楚，复杂情况请注册税务代理核对。[ATO：判断税务居民身份](https://community.ato.gov.au/s/article/a07RF00000GjNz8YAF/how-to-work-out-your-tax-residency)

临时签证工作者也应核对符合条件的养老金缴款。有余额不代表可以随时取出；DASP 是符合条件的前临时居民离澳后申请的专门路径，涉及签证是否失效、是否仍持其他有效签证、当前国籍／PR 状态及扣税。公民和 PR 不能把“离开澳洲”本身当作 DASP 资格。[临时居民与养老金](https://www.ato.gov.au/individuals-and-families/super-for-individuals-and-families/super/temporary-residents-and-superannuation)、[ATO 对 DASP 条件的答复](https://community.ato.gov.au/s/question/a0JRF000004UuP32AK/p00409356)

## 买房：先查能不能买，再算贷不贷款

截至本附录核对日，澳洲政策规定 **2025-04-01 至 2027-03-31，外国人一般不得购买现有住宅，有限例外除外**。外国投资住宅还可能需要事先批准。临时居民不应先签约再查政策；可申请的新房、空地等类别也需要核对。PR 与公民则仍应让过户律师确认本人在具体外资规则和州税规则下的待遇。[外国投资住宅合规](https://foreigninvestment.gov.au/guidance/conditions-and-reporting/residential-compliance)、[ATO 外国人购房申请](https://www.ato.gov.au/individuals-and-families/investments-and-assets/foreign-resident-investments/foreign-investment-in-australia/residential-property-application-for-foreign-investors)

短住或尚不具购买条件时，[租房](book/06-renting-and-buying-a-home.md)通常是本指南相关行动的替代路线，而不是设法绕过审批。

## 选举：在澳居住不等于选民资格

通常达到法定年龄的澳洲公民须按规定登记；中国籍 PR、一般临时签证与游客不因在澳住址获得联邦投票权。华人公民适用公民规则，未入籍中国读者则跳过选民登记行动。特殊历史类别应向 AEC 核对。[AEC：谁需要登记](https://www.aec.gov.au/community/criteria.htm)

## 所有人入境前都值得做的三件事

1. **核查食品、动植物物品和户外装备申报。**不要因为是“自用”“家人带的”或“中药食材”就省略核对。按旅客申报表如实申报风险物品，不清楚时主动询问；申报不保证物品一定准入。[澳洲农业部入境指引](https://www.agriculture.gov.au/travelling/to-australia)
2. **按药品规则准备，而不是只按行李额度。**旅行者豁免下许多个人药品可以携带，但须符合本人／同行直系亲属使用、原包装、处方或医生信及通常不超过 3 个月用量等条件；特殊管制药品另查。不要替别人批量带药。[TGA 携药旅行指引](https://www.tga.gov.au/resources/consumer-information-and-resources/travelling-medicines-and-medical-devices)
3. **保存英语求助资料。**住宿地址、药物通用名、保险编号和紧急联系人做离线备份。不要把这些私人资料提交到公开 GitHub。

## 普通话支持与中国领事渠道

在澳可拨 **131 450** 联系 TIS National，即时口译为全天候服务；说出所需语言，如 Mandarin。大多数情况下由接收服务的机构承担口译费用，但电话资费和机构是否接受服务要确认，不应把所有场景都写成免费。[TIS 服务说明](https://www.tisnational.gov.au/Non-English-speakers/Interpreting-services)

中国公民遇领事保护问题，按所在州／领地查中国驻澳使领馆的最新领区与联系方式；也可查看 **+86-10-12308** 与备用 **+86-10-65612308** 的官方指引。驻澳使馆页面同时提示部分固定电话因技术升级暂停，故本书不把旧领区电话表当作永久有效。当地生命危险仍先拨 000。[中国驻澳使馆领保指南与最新联系方式](https://au.china-embassy.gov.cn/lsfw/zggmlsxz/lasc/)

[返回澳洲指南](README.md) · [完整 40 章导航](README.md#the-full-playbook) · [翻译与适配报告](TRANSLATION-REPORT.md)
